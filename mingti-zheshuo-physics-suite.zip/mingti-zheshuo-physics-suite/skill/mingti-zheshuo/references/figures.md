# 配图手册：figkit（纯 Python，零依赖）+ 渲染自检

> 目的：试题**有图就必须画出来**，并且图要**精确、与题设一致、可印刷**。`scripts/figkit` 输出 SVG（可内联进 HTML、转 PNG/PDF/Word）。
> 环境：Python 3.9+（只用标准库）；渲染自检需要本机 Chrome 或 Edge（`scripts/render_svg.py`）；转 Word 需要 pandoc（`export_docx.py`）。

## 1. 快速上手

```python
import sys; sys.path.insert(0, '<skill>/scripts')
from figkit import *
from htmlkit import *

s = Svg(480, 300)                          # 画布（像素），默认白底
ax = Axes(s, left=60, top=45, width=360, height=200, xlim=(-3, 3), ylim=(-2, 4))   # top ≥ 45，给 y 轴名留空间
ax.draw_axes(xlabel='x', ylabel='y')
ax.plot(lambda x: x*x - 1, sw=2.2)
ax.point(0, -1, 'A', dx=8, dy=18)
s.caption('图 1', 288)
s.save('fig1.svg')                         # 单独文件
html_fragment = figure(s)                  # htmlkit：内联进页面
```
**画完一定渲染看一眼**：`python3 scripts/render_svg.py fig1.svg` → fig1.png（再用图片查看工具打开）。HTML 整页：`python3 scripts/render_svg.py page.html page.png --size 1000x4000`。

坐标约定：画布 y 向下；`Axes` 用数据坐标（y 向上）；`arc/polar/force` 的角度是**数学角度**（逆时针为正，0° 指向右）。文字标记：`x_0`、`v^{2}`、`E_{k}`（下标/上标），希腊字母直接写（θ α β）。`italic=True` 默认用于变量；单位、汉字用 `s.label(...)` 或 `italic=False`。

## 2. API 速查

### 2.1 核心 `Svg`（core.py）
`line, arrow(both=), polyline, polygon, rect, circle, dot, ellipse, path, arc(a0,a1,arrow_end=), text, label, hatch(地面/墙面斜线), right_angle, angle_mark, dim(尺寸标注), caption, save, inline, to_string`；工具 `polar(cx,cy,r,deg)`。

### 2.2 数学（math_.py）
- `Axes(svg,left,top,w,h,xlim,ylim)`：`draw_axes(xticks=,yticks=,xtick_labels={值:'π'},cross=(0,0),grid=,box=)`；`plot(f,a,b,jump=,label=)`（自动处理渐近线断点与越界裁剪）、`parametric`、`implicit(F)`（隐函数曲线，圆锥曲线/含绝对值曲线）、`polyline_data(pts,markers=)`、`fill_between/fill_polygon`、`point(x,y,label,hollow=)`、`hline/vline/drop_lines`、`segment/arrow_data`。
- 立体几何 `Solid3D(svg,ox,oy,unit,depth,angle)`：斜二测；`v(名,x,y,z)`、`edge(a,b,hidden=True 虚线)`、`edges`、`face`、`label(名,dx,dy)`、`point`、`axes()`；`Solid3D.box(s3,a,b,c)` 长方体。棱锥/棱柱：自己 `v()` 定义顶点后 `edge()`，**被遮挡的棱必须手动标 hidden=True**。
- 平面几何：`polygon_labeled(s,pts,'ABC')`、`label_vertices`、`midpoint`、`foot_of_perpendicular`、`mark_equal`；`s.right_angle / angle_mark / dim`。
- 常见做法：函数图 → `Axes.plot`；解析几何 → `implicit`；三角函数 → `xtick_labels={π/2:'π/2'}`；统计图 → `charts.bar_chart/line_chart`；数列散点 → `polyline_data(markers=True)` 或 `ax.point`。

### 2.3 物理（physics.py）
- 力学：`ground, wall, block, ball, incline, block_on_incline, force(origin,angle,length,label), spring, pulley, rope, pendulum_support`。
- 电路：`wire, junction, resistor, battery(n=,plus_at_p1=), switch(closed=), meter(label='A'/'V'), bulb, rheostat(slider=), capacitor, inductor, ac_source, diode`；元件两端点 `p1→p2` 任意方向（横/竖/斜）。**接线原则**：先画导线骨架（`wire`），再叠元件，节点处 `junction`。
- 场：`field_marks(kind='cross'|'dot')`（磁场 ×/·）、`efield_lines`、`charge`、`plates`。粒子轨迹用 `s.arc(cx,cy,r,a0,a1,arrow_end=True)`；**先算清圆心与半径再画**。
- 光学/波：`lens, mirror_plane, ray, slit_screen`；波形图、v-t、x-t、U-I 图：`Axes`。
- 速查：受力分析图需标出对象、各力符号、正方向；图中箭头长度大致反映力的大小关系（平衡时等长对称）。

### 2.4 化学（chem.py）
- 结构式：`Mol`（骨架式）：`ring()` 苯环、`chain(frm,[(角度,标签,键级)])`、`bond(order=1/2/3, kind='wedge'/'dash')`、`render()`；`benzene_ring()`。杂原子/官能团文字写在 `label`（如 'O','OH','NH2' 用 `NH_2` 标记下标）。
- 仪器：`beaker, conical_flask, round_flask, test_tube(angle=), alcohol_lamp, glass_tube(pts), stopper, gas_bottle(invert=True 倒置), trough, funnel_filter, burette, flask_stand`。**装置图需保证导管走向、液面、进出气方向与题设一致**。
- 工艺流程：`process_flow(steps, inputs={idx:[试剂]}, outputs={idx:[滤渣]}, start_label, end_label)`。
- 其他：`energy_profile`（反应能量图）、`cube_cell(Solid3D, atoms)`（立方晶胞）、`galvanic_cell`（双液原电池）、`electrolytic_cell`；曲线（滴定曲线、转化率-温度、浓度-时间）用 `Axes` 或 `charts.line_chart`。

### 2.5 生物（bio.py）
`pedigree`（系谱图：涂黑=患者、半涂=携带者、"?"=待求）、`pathway`（信号通路，'->' 促进，'-|' 抑制）、`gel`（电泳）、`gene_map`（基因结构+引物箭头）、`food_web`、`cell_outline`；数据图用 `charts.bar_chart(误差棒、显著性星号)`、`line_chart`。

### 2.6 统计与通用（charts.py）
`bar_chart, line_chart, pie_chart, flow_boxes(通用框图/关系图), legend`；用于政治（柱状图、产业链图）、英语（图表、日程表、海报版面可用 HTML+CSS）、数学统计（频率分布）。表格直接用 `htmlkit.table`（比 SVG 更适合）。

## 3. 各学科"必须画图"的清单与检查点

| 学科 | 常见需配图 | 画图检查点 |
|---|---|---|
| 数学 | 函数图象、立体几何体（斜二测）、解析几何曲线、统计图表（频率分布直方图、散点图）、数列图示、流程图 | 关键点坐标精确；虚实线（被遮挡棱为虚线）；刻度与题设一致；不得"示意图误导答案"（除非题本意） |
| 物理 | 受力分析、运动轨迹、v-t/x-t/E-x 图、电路图、实物连线、电场磁场、光路、装置示意 | 方向（力、场、电流、粒子电性）与题设一致；元件符号规范；图中标注符号齐全；数值图由数据生成 |
| 化学 | 实验装置、流程图、结构式、晶胞、曲线（平衡/滴定/溶解度）、能量图、电化学装置 | 装置气密性/导管入口出口；极性与电流方向；结构式价键正确；曲线与题给数据一致 |
| 生物 | 系谱图、遗传图解、实验结果柱形/曲线图、电泳图、信号通路/代谢途径、基因结构与引物、生态系统（食物网、能量流动） | 数据满足题设结论；单一变量/对照在图中体现；系谱符号规范；通路箭头方向/抑制符号 |
| 政治 | 统计图表（柱/折/饼）、产业链图、法条/文件节选表、漫画（用文字描述代替）、流程图 | 数据来源标注；图表标题与单位；时政数据可核查或标"虚构" |
| 英语 | 阅读 A 篇的海报/通知/日程表/广告、图表题（如调查结果）、示意图 | 排版真实（标题、时间地点、联系方式为虚构）；文字为英文；版权安全（原创） |

## 4. 印刷与版式规范

- 黑白线稿 + 浅灰填充（`PATTERNS`）；线宽 1.5–2.2；字号 ≥ 15 px；图宽 ≤ 620 px（`figure(svg, max_width=620)`）；每图自带"图 n"题注（`s.caption('图 1', y)`），**不要在 HTML 再重复一次**（`figure(s)` 不传 caption）。
- 选择题选项里含小图时，用 `question(..., extra=figure(...))` 或单独排四个小图（每个 SVG 用 `figure` 放进 `div style="display:grid;grid-template-columns:1fr 1fr"`）。
- 化学式下标用 Unicode（H₂O）或 `ml("H_2O")`（HTML）；SVG 文字用 `x_{2}` 标记。

## 5. 精度与诚信要求

- **数据驱动**：任何有数值含义的图（v-t、统计图、曲线）先写出数据/函数，再由代码画图；答案里引用的数据必须与图一致。
- **不"乱画示意"**：例如曲线 x²+y²=2|x|−2√3|y| 用 `implicit` 画出的是**两片很扁的叶形**（半高仅 2−√3≈0.27），不是圆形大环；手绘感觉容易误导。
- 每张图在**教师卷的"待审校清单"**里列一行："图 n 的方向/数据与题设一致"。
- 渲染后用图片查看工具实际看图，检查：标签遮挡、越界、方向错误、缺失符号。
