# -*- coding: utf-8 -*-
"""figkit 图例画廊：每类学科 2–4 个典型配图，作为"怎么调用"的活样例。运行后打开 figure_gallery.html。"""
import os, sys, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
from figkit import *
from htmlkit import CSS_ANALYSIS, esc

cards = []
def card(title, svg, code):
    cards.append((title, svg.inline(430) if hasattr(svg, "inline") else svg, code))

# ---------------- 数学 ----------------
s = Svg(430, 300)
ax = Axes(s, 50, 50, 330, 200, (-3.4, 3.4), (-1.2, 1.2))
ax.draw_axes(xticks=[-2, 2], yticks=[])
r3 = math.sqrt(3)
ax.implicit(lambda x, y: x*x + y*y - 2*abs(x) + 2*r3*abs(y), n=420, sw=2.2)
ax.point(2, 0, "(2,0)", dx=4, dy=-10, size=15); ax.point(-2, 0, "(−2,0)", dx=-34, dy=-10, size=15)
card("数学｜含绝对值曲线 x²+y²=2|x|−2√3|y|（implicit）", s, "ax.implicit(lambda x,y: x*x+y*y-2*abs(x)+2*r3*abs(y))")

s = Svg(430, 300)
ax = Axes(s, 55, 45, 330, 210, (-4.5, 4.5), (-3.2, 3.2))
ax.draw_axes(xticks=[-3, 3], yticks=[-2, 2])
ax.implicit(lambda x, y: x*x/9 + y*y/4 - 1, sw=2.2)
ax.point(math.sqrt(5), 0, "F₂", dx=2, dy=18, size=16); ax.point(-math.sqrt(5), 0, "F₁", dx=-18, dy=18, size=16)
ax.point(1.5, 2*math.sqrt(1-1.5**2/9), "P", dx=6, dy=-8, size=16)
card("数学｜椭圆与焦点（implicit + point）", s, "ax.implicit(lambda x,y: x*x/9+y*y/4-1)")

s = Svg(430, 300)
s3 = Solid3D(s, 80, 250, unit=100, depth=0.5)
# 四棱锥 P-ABCD
for n, c in {"A": (0, 0, 0), "B": (2, 0, 0), "C": (2, 2, 0), "D": (0, 2, 0), "P": (0, 0, 2.2)}.items():
    s3.v(n, *c)
for a, b in [("A", "B"), ("B", "C"), ("P", "A"), ("P", "B"), ("P", "C")]:
    s3.edge(a, b)
for a, b in [("A", "D"), ("D", "C"), ("P", "D")]:
    s3.edge(a, b, hidden=True)
s3.label("A", -16, 16); s3.label("B", 14, 16); s3.label("C", 16, 4); s3.label("D", -14, 2); s3.label("P", -4, -12)
s3.point("F", 0, 0, 1.1, "F", dx=-14, dy=4)
card("数学｜立体几何：四棱锥（Solid3D，虚线=被遮挡棱）", s, "s3.edge(a,b,hidden=True)")

s = Svg(430, 270)
cat = ["0–1", "1–2", "2–3", "3–4", "4–5"]
bar_chart(s, 76, 40, 320, 160, cat, [[0.08, 0.22, 0.34, 0.24, 0.12]], ymax=0.4, ylabel="频率/组距", bar_w=0.9, xlabel="时间/小时", yticks=[0.1, 0.2, 0.3, 0.4])
card("数学/政治｜统计图（bar_chart）", s, "bar_chart(s,left,top,w,h,categories,[values])")

# ---------------- 物理 ----------------
s = Svg(430, 280)
x0, x1, y0, y1 = 60, 370, 50, 210
xv = 250
wire(s, [(x0, y1), (x0, y0), (140, y0)]); switch(s, (140, y0), (220, y0), label="S")
wire(s, [(220, y0), (x1, y0), (x1, 90)]); wire(s, [(x1, 170), (x1, y1), (x0, y1)])
battery(s, (x0, y1), (x0, y0), n=2, label="E", lab_off=-26)
resistor(s, (x1, 90), (x1, 170), label="R")
wire(s, [(xv, y0), (xv, 124)]); wire(s, [(xv, 156), (xv, y1)])
meter(s, xv, 140, "V", r=16)
junction(s, xv, y0); junction(s, xv, y1)
card("物理｜电路（battery / switch / resistor / meter）", s, "resistor(s,p1,p2,label='R'); battery(s,p1,p2,n=2)")

s = Svg(430, 280)
O, top, foot = incline(s, 40, 240, 340, 35, label_angle="θ")
c = block_on_incline(s, 40, 240, 35, 190, 54, 34, "m")
force(s, c, -90, 62, "mg", off=(16, 0)); force(s, c, 125, 62, "N", off=(-8, -4))
force(s, (c[0]+18*math.cos(math.radians(35)), c[1]-18*math.sin(math.radians(35))), 35, 58, "F", off=(8, -4))
card("物理｜斜面受力（incline / block_on_incline / force）", s, "force(s, center, angle, length, 'mg')")

s = Svg(430, 280)
field_marks(s, 170, 40, 220, 200, "cross", 6, 5, label="B")
s.line(40, 220, 170, 220, 1.8); ball(s, 40, 220, 6, fill="#000"); s.arrow(60, 220, 130, 220, 2.0)
R = 70
s.arc(170, 220 - R, R, -90, 90, 2.2, arrow_end=True)
s.text(60, 205, "v", 18)
card("物理｜磁场中的圆周运动（field_marks + arc）", s, "s.arc(cx,cy,R,-90,90,arrow_end=True)")

s = Svg(430, 260)
ax = Axes(s, 60, 40, 320, 170, (0, 6.5), (0, 5))
ax.draw_axes(xlabel="t/s", ylabel="v/(m·s⁻¹)", xticks=[2, 4, 6], yticks=[4], ylabel_pos=(60, 18))
ax.polyline_data([(0, 0), (2, 4), (4, 4), (6, 0)], sw=2.2); ax.drop_lines(2, 4)
card("物理｜v–t 图（Axes.polyline_data）", s, "ax.polyline_data([(0,0),(2,4),(4,4),(6,0)])")

# ---------------- 化学 ----------------
s = Svg(430, 250)
m = Mol(s, bond=42)
m.ring("r", 110, 110, r=42)
x, y, _ = m.atoms["r3"]
m.atoms["c1"] = [x, y + 42, None]; m.bond("r3", "c1", 1)
m.atoms["o1"] = [x - 36, y + 42 + 21, "O"]; m.bond("c1", "o1", 2)
m.atoms["o2"] = [x + 36, y + 42 + 21, "O"]; m.bond("c1", "o2", 1)
m.chain("o2", [(30, None, 1), (-30, None, 1)])
m.render()
s.text(260, 110, "苯甲酸乙酯", 18, italic=False, anchor="start")
card("化学｜结构式（Mol：苯环、双键、杂原子）", s, "m=Mol(s); m.ring('r',cx,cy); m.chain('r3',[(-90,None,1)]); m.render()")

s = Svg(430, 250)
round_flask(s, 100, 150, 46, 26, 54, liquid=0.35)
alcohol_lamp(s, 100, 238, 56, 48)
stopper(s, 100, 88, 36, 28, 14)
glass_tube(s, [(100, 82), (100, 40), (280, 40), (280, 150)])
trough(s, 190, 232, 210, 76, 0.55)
gas_bottle(s, 280, 232, 70, 110, 30, 12, invert=True)
card("化学｜气体制备与排水集气（round_flask / glass_tube / gas_bottle(invert)）", s, "gas_bottle(s,cx,y,..., invert=True)")

s = Svg(430, 190)
process_flow(s, ["酸溶", "氧化", "沉铁"], 90, 76, 70, 40, 34, inputs={0: ["稀H₂SO₄"], 1: ["NaClO"], 2: ["Na₂CO₃"]}, outputs={0: ["滤渣"], 2: ["黄钠铁矾"]}, start_label="矿石", end_label="富集液", size=16)
card("化学｜工艺流程（process_flow）", s, "process_flow(s, ['酸溶','氧化','沉铁'], inputs={...}, outputs={...})")

s = Svg(430, 290)
galvanic_cell(s, 110, 240, "Zn", "Cu", "ZnSO₄溶液", "CuSO₄溶液", w=110, gap=60, size=16)
card("化学｜双液原电池（galvanic_cell）", s, "galvanic_cell(s, x, y, 'Zn','Cu', ...)")

# ---------------- 生物 ----------------
s = Svg(430, 300)
people = {"Ⅰ1": (110, 50, "M", 0), "Ⅰ2": (200, 50, "F", 1), "Ⅱ1": (70, 140, "F", 0), "Ⅱ2": (155, 140, "M", 1), "Ⅱ3": (240, 140, "F", 2), "Ⅲ1": (112, 230, "M", None)}
pedigree(s, people, [("Ⅰ1", "Ⅰ2"), ("Ⅱ1", "Ⅱ2")], {("Ⅰ1", "Ⅰ2"): ["Ⅱ1", "Ⅱ2", "Ⅱ3"], ("Ⅱ1", "Ⅱ2"): ["Ⅲ1"]}, gen_labels=[(50, "Ⅰ"), (140, "Ⅱ"), (230, "Ⅲ")])
card("生物｜系谱图（pedigree：涂黑患者、半涂携带者、?待求）", s, "pedigree(s, people, couples, children)")

s = Svg(430, 280)
bar_chart(s, 70, 40, 320, 180, ["对照", "处理1", "处理2"], [[1.0, 2.1, 0.9], [1.0, 1.1, 1.0]], ymax=3, ylabel="相对表达量",
          series_names=["实验组", "对照组"], errors=[[0.1, 0.2, 0.1], [0.1, 0.1, 0.1]], stars={(0, 1): "**"})
card("生物｜柱形图 + 误差棒 + 显著性（bar_chart）", s, "bar_chart(..., errors=..., stars={(0,1):'**'})")

s = Svg(430, 230)
pathway(s, {"SL": (60, 55, "SL"), "D14": (170, 55, "D14"), "D3": (280, 55, "D3"), "D53": (380, 55, "D53"), "g": (380, 160, "SL相关基因\n表达")},
        [("SL", "D14", "->"), ("D14", "D3", "->", "结合"), ("D3", "D53", "-|", "降解"), ("D53", "g", "-|")], size=15)
card("生物｜信号通路（pathway：-> 促进，-| 抑制）", s, "pathway(s, nodes, [('A','B','->'),('B','C','-|')])")

s = Svg(430, 270)
gel(s, 40, 36, 190, 200, ["M", "1", "2", "3"], {0: [0.1, 0.3, 0.5, 0.7], 1: [0.3], 2: [0.5], 3: [0.3, 0.5]}, marker_labels={0.1: "2000", 0.3: "1000", 0.5: "500", 0.7: "250"})
gene_map(s, 260, 110, 150, [(1, "启动子", "#ddd"), (3, "基因", "#fff"), (1, "终止子", "#ddd")],
         primers=[(0.0, "F", "right", 0), (1.0, "R", "left", 0)])
card("生物｜电泳图 + 基因结构/引物（gel / gene_map）", s, "gel(...); gene_map(..., primers=[(0,'F','right',0)])")

# ---------------- 通用 ----------------
s = Svg(430, 280)
line_chart(s, 60, 50, 320, 160, [2017, 2018, 2019, 2020, 2021], [[16, 36, 40, 52, 64], [69, 72, 64, 49, 49]], xlabel="年份", ylabel="占比/%",
           series_names=["现磨咖啡", "速溶咖啡"], dashes=[None, "6,4"], xticks=[2017, 2018, 2019, 2020, 2021])
card("政治/数学/英语｜折线图（line_chart）", s, "line_chart(s, ..., xs, [series...], dashes=[None,'6,4'])")

s = Svg(430, 230)
flow_boxes(s, {"a": (80, 60, 120, 44, "居民收入提高"), "b": (250, 60, 120, 44, "消费需求升级"), "c": (250, 170, 120, 44, "企业扩大生产"), "d": (80, 170, 120, 44, "供给质量提升")},
           [("a", "b"), ("b", "c"), ("c", "d"), ("d", "a")], size=15)
card("政治｜传导关系框图（flow_boxes）", s, "flow_boxes(s, nodes, edges)")

# ---------------- 输出 ----------------
css = CSS_ANALYSIS + ".g{display:grid;grid-template-columns:repeat(auto-fill,minmax(460px,1fr));gap:18px}.card{background:#fff;border:1px solid #dfe7f1;border-radius:14px;padding:14px}.card h3{margin:0 0 6px;font-size:16px}.card pre{margin:6px 0 0;background:#f3f6fa;border-radius:8px;padding:8px 10px;font-size:12px;white-space:pre-wrap;color:#33476b}"
body = "".join('<div class="card"><h3>%s</h3>%s<pre>%s</pre></div>' % (esc(t), svg, esc(code)) for t, svg, code in cards)
html = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>figkit 图例画廊</title><style>%s</style></head><body><main class="wrap"><header class="hero"><div class="eyebrow">命题者说 Skill · figkit</div><h1>试题配图图例画廊</h1><p>每张图都由 scripts/figkit 的几行代码生成；示例脚本见 examples/figure_gallery.py。</p></header><div class="g" style="margin-top:18px">%s</div></main></body></html>' % (css, body)
open(os.path.join(HERE, "figure_gallery.html"), "w", encoding="utf-8").write(html)
print("figure_gallery.html", len(cards), "张图")
