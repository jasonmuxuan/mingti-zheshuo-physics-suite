# -*- coding: utf-8 -*-
"""示例：用 figkit + htmlkit 生成"物理试卷节选"（学生卷 + 教师卷：蓝图/答案评分/命题说明）。
运行：python3 demo_exam_mini.py → demo_exam_mini.html ；再用 render_svg.py 转 PDF、export_docx.py 转 Word。
（题目为本 Skill 的原创示例题，仅用于演示输出格式。）"""
import os, sys, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
from figkit import *
from htmlkit import *

# ---------- 图 1：v-t 图 ----------
s1 = Svg(430, 270)
ax = Axes(s1, 70, 45, 300, 170, (0, 6.6), (0, 5))
ax.draw_axes(xlabel="t/s", ylabel="v/(m·s⁻¹)", xticks=[2, 4, 6], yticks=[4], show_origin_label=True, cross=(0, 0),
             ylabel_pos=(70, 22))
ax.polyline_data([(0, 0), (2, 4), (4, 4), (6, 0)], sw=2.2)
ax.drop_lines(2, 4)
s1.caption("图 1", 258)

# ---------- 图 2：质谱仪式装置 ----------
s2 = Svg(520, 300)
# 加速电场（两块竖直板）
xa, xb_plate = 60, 130
yc = 215
s2.line(xa, yc - 40, xa, yc + 40, 3.0)
s2.line(xb_plate, yc - 40, xb_plate, yc - 7, 3.0)
s2.line(xb_plate, yc + 7, xb_plate, yc + 40, 3.0)
s2.text(xa - 14, yc - 44, "+", 20, italic=False)
s2.text(xb_plate + 16, yc - 44, "−", 22, italic=False)
s2.text(95, yc + 64, "U", 20)
ball(s2, xa + 10, yc, 6, fill="#000")
s2.text(xa + 10, yc + 24, "q", 18)
s2.arrow(xa + 14, yc, 205, yc, 2.0)
# 磁场区域（右侧，边界在 x=230）
xbd = 230
field_marks(s2, xbd, 40, 250, 230, "cross", 6, 5, label="B")
s2.line(xbd, 40, xbd, 270, 1.6)
R = 80
s2.arc(xbd, yc - R, R, -90, 90, 2.2, arrow_end=True)
s2.dot(xbd, yc, 3.5); s2.text(xbd - 14, yc + 22, "O", 18)
s2.dot(xbd, yc - 2 * R, 3.5); s2.text(xbd - 16, yc - 2 * R + 6, "P", 18)
s2.arrow(xbd - 34, yc - 2 * R + 4, xbd - 34, yc - 4, 1.4, head=9, both=True)
s2.text(xbd - 48, yc - R + 6, "d", 18)
s2.caption("图 2", 292)

# ---------- 学生卷 ----------
stu = []
stu.append(part("第一部分", "本部分共 1 题，3 分。在每题给出的四个选项中，只有一个选项符合题意。（节选示例）"))
stu.append(question(
    1, "一质点沿直线运动，其 <i>v</i>–<i>t</i> 图像如图 1 所示。下列说法正确的是", 3,
    extra=figure(s1),
    opts=["A. 0～2 s 内，质点的加速度大小为 4 m/s²", "B. 2～4 s 内，质点的位移大小为 8 m",
          "C. 0～6 s 内，质点的位移大小为 14 m", "D. 4～6 s 内与 0～2 s 内，质点的加速度相同"]))
stu.append(part("第二部分", "本部分共 1 题，9 分。解答应写出必要的文字说明、方程式和演算步骤。只写出最后答案的不能得分。"))
stu.append(question(
    2, "质谱仪是分离和检测同位素的重要仪器，其原理可简化为图 2 所示。电荷量为 <i>q</i>、质量为 <i>m</i> 的带正电粒子（初速度可视为零，重力不计）"
       "经电压为 <i>U</i> 的加速电场加速后，从 <i>O</i> 点垂直磁场边界射入磁感应强度为 <i>B</i>、方向垂直纸面向里的匀强磁场，"
       "在磁场中做匀速圆周运动，最后从边界上的 <i>P</i> 点射出。", 9,
    extra=figure(s2) +
    subq("（1）", "求粒子进入磁场时的速度大小 <i>v</i>；", 3) +
    subq("（2）", "求 <i>O</i>、<i>P</i> 两点间的距离 <i>d</i>；", 3) +
    subq("（3）", "求粒子在磁场中运动的时间 <i>t</i>。", 3)))

# ---------- 教师卷 ----------
tea = []
tea.append(part("一、命题蓝图（双向细目表）"))
tea.append(table([
    ["1", "选择", "3", "匀变速直线运动（v-t 图像）", "基础", "B1 分析推理", "科学思维：模型建构、科学推理", "图 1（v-t 图）"],
    ["2(1)", "计算", "3", "动能定理（加速电场）", "基础", "B1 分析推理", "物理观念：能量观念", "图 2（装置图）"],
    ["2(2)", "计算", "3", "洛伦兹力与圆周运动", "中等", "B1→B2", "物理观念：运动与相互作用观念", "同上"],
    ["2(3)", "计算", "3", "匀速圆周运动的周期", "中等", "B2 综合应用", "科学思维：科学推理", "同上"],
], ["题号", "题型", "分值", "必备知识", "难度层", "学科能力", "素养", "配图"]))
tea.append(part("二、参考答案与评分"))
tea.append('<p><b>第 1 题</b>　B（3 分）。解析：A 项加速度 a = Δv/Δt = 4/2 = 2 m/s²；B 项 2～4 s 匀速，x = 4×2 = 8 m；C 项 0～6 s 图线与横轴所围面积 = ½×2×4 + 8 + ½×2×4 = 16 m；D 项 4～6 s 加速度方向与 0～2 s 相反。</p>')
tea.append('<p><b>第 2 题</b>（9 分）</p>')
tea.append(subq("（1）3 分", "由动能定理 <i>qU</i> = ½<i>mv</i>² ………（2 分）<br>得 <i>v</i> = " + sqrt("2<i>qU</i>/<i>m</i>") + " ………（1 分）"))
tea.append(subq("（2）3 分", "洛伦兹力提供向心力 <i>qvB</i> = <i>m</i><i>v</i>²/<i>R</i> ………（1 分）<br>得 <i>R</i> = <i>mv</i>/(<i>qB</i>) = " + frac("1", "<i>B</i>") + sqrt("2<i>mU</i>/<i>q</i>") + " ………（1 分）<br>粒子射出点与射入点相距一个直径：<i>d</i> = 2<i>R</i> = " + frac("2", "<i>B</i>") + sqrt("2<i>mU</i>/<i>q</i>") + " ………（1 分）"))
tea.append(subq("（3）3 分", "周期 <i>T</i> = 2π<i>R</i>/<i>v</i> = 2π<i>m</i>/(<i>qB</i>) ………（2 分）<br>粒子在磁场中运动半个圆周：<i>t</i> = <i>T</i>/2 = π<i>m</i>/(<i>qB</i>) ………（1 分）"))
tea.append(callout("note", "评分说明：只写出结果、不写原始方程，按得分点扣分；第 2（2）问若写 <i>R</i> = <i>mv</i>/(<i>qB</i>) 并正确代入，可不单独要求写出向心力方程的形式，但方程来源须体现。", "采分点："))
tea.append(part("三、命题说明（命题者视角）"))
tea.append(ul([
    "<b>第 1 题（基础性，B1）：</b>四个选项分别考查斜率→加速度、面积→位移、分段求和、方向（符号）。干扰项 C 对应“漏算一段面积/把梯形当三角形”，D 对应“忽略加速度方向（符号）”。",
    "<b>第 2 题（基础性到发展性，B1→B2）：</b>三问递进——能量观点（加速）→ 力与运动（圆周）→ 周期与时间（图形推理：半圆）。第 3 问的台阶在于“半个周期”需要读图，而不是套用周期公式。",
    "<b>配图：</b>图 2 中粒子带正电、B 垂直纸面向里，由左手定则粒子受力向上，轨迹为向上的半圆，P 在 O 的正上方 2R 处，图与题设方向一致。",
]))
tea.append(part("四、待教师审校清单"))
tea.append(ul([
    "☐ 图 2 的方向（B 向里、正电荷、轨迹向上）与文字一致",
    "☐ 题干无多余/缺失条件（重力不计、初速度为零、垂直边界射入）",
    "☐ 答案经两种方法验算：（2）也可由 <i>d</i> = 2<i>mv</i>/(<i>qB</i>) 直接得到",
    "☐ 难度估计仅为命题预估，未经试测",
]))
page = exam_page("示例卷 · 高三物理（节选）", "物理", 12, 15, stu, tea,
                 footer="本卷为演示格式的原创示例题，未经试测，使用前请教师逐题审校。")
out = save(page, os.path.join(HERE, "demo_exam_mini.html"))
print(out)
