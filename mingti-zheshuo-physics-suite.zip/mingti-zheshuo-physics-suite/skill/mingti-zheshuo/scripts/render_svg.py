#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 SVG（或 HTML）渲染为 PNG / PDF，用于"画完图自己看一眼"。依赖本机 Chrome/Edge（headless）。
用法：
  python3 render_svg.py fig.svg [out.png] [--scale 2]
  python3 render_svg.py page.html out.png --size 1000x4000   # 整页长图（检查排版）
  python3 render_svg.py page.html out.pdf          # HTML → PDF（A4，带背景）
"""
import os, re, subprocess, sys, tempfile

CANDIDATES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
]


def find_browser():
    for c in CANDIDATES:
        if os.path.exists(c):
            return c
    raise SystemExit("未找到 Chrome/Edge；请手动用浏览器打开 SVG/HTML 检查。")


def svg_size(path):
    head = open(path, encoding="utf-8").read(2000)
    w = re.search(r'width="([\d.]+)"', head)
    h = re.search(r'height="([\d.]+)"', head)
    return (int(float(w.group(1))), int(float(h.group(1)))) if w and h else (800, 600)


def main():
    argv = sys.argv[1:]
    opts = {}
    for k in ("--scale", "--size"):
        if k in argv:
            i = argv.index(k)
            opts[k] = argv[i + 1]
            del argv[i:i + 2]
    args = [a for a in argv if not a.startswith("--")]
    scale = float(opts.get("--scale", 2.0))
    src = os.path.abspath(args[0])
    out = os.path.abspath(args[1]) if len(args) > 1 else os.path.splitext(src)[0] + ".png"
    br = find_browser()
    base = [br, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-sandbox", "--default-background-color=FFFFFFFF"]
    url = "file://" + src
    if out.lower().endswith(".pdf"):
        cmd = base + ["--no-pdf-header-footer", "--print-to-pdf=" + out, url]
    else:
        if src.lower().endswith(".svg"):
            w, h = svg_size(src)
        else:
            w, h = (int(v) for v in opts.get("--size", "1000x1400").split("x"))
        cmd = base + ["--force-device-scale-factor=%s" % scale, "--screenshot=" + out, "--window-size=%d,%d" % (w, h), url]
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    if not os.path.exists(out):
        sys.stderr.write(r.stderr.decode("utf-8", "ignore")[-800:])
        raise SystemExit("渲染失败")
    print(out)


if __name__ == "__main__":
    main()
