# -*- coding: utf-8 -*-
"""htmlkit —— 把"命题者视角解析"与"试卷"输出成单文件 HTML（图为内联 SVG，可离线打开、可打印、可转 PDF/Word）。

典型用法（写一个生成脚本）：
    import sys; sys.path.insert(0, '<skill>/scripts')
    from figkit import *
    from htmlkit import *
    fig1 = Svg(400, 300); ...                      # 画图
    page = analysis_page(
        title="…", subtitle="…", subject="物理", answer="D",
        question=[p("题干…"), figure(fig1, "图 1"), p("A. …<br>B. …")],
        modules=[("试题解读", "<h3>…</h3><p>…</p>"), ("思路分析", "…"), …])
    save(page, "out.html")

公式：直接写 Unicode（x² √3 π ∑ ∫ ≤ ≥ ≠ ≈ ∈ → ⇒ ∠ ⊥ ∥ ·），上下标可用 ml("a_n^2") 转成 <sub>/<sup>；
分数：frac("a","b")；根号：sqrt("x+1")。
"""
import html as _html
import re
import os
import sys

# --------------------------------------------------------------------------
# 行内数学小工具
# --------------------------------------------------------------------------
_SCRIPT = re.compile(r"(_\{[^}]*\}|\^\{[^}]*\}|_[A-Za-z0-9′'+\-]|\^[A-Za-z0-9′'+\-])")


def ml(s, italic_vars=False):
    """把 x_{n+1} / a^2 之类标记转成 HTML 上下标；其余字符原样（不转义，便于混入 <b> 等标签）。"""
    out = []
    for part in _SCRIPT.split(s):
        if not part:
            continue
        if part[0] in "_^" and _SCRIPT.fullmatch(part):
            body = part[2:-1] if part[1] == "{" else part[1]
            out.append("<%s>%s</%s>" % ("sub" if part[0] == "_" else "sup", body, "sub" if part[0] == "_" else "sup"))
        else:
            out.append(part)
    return "".join(out)


def frac(a, b):
    return '<span class="frac"><span>%s</span><span>%s</span></span>' % (a, b)


def sqrt(x):
    return '<span class="sqrt">√<span class="radicand">%s</span></span>' % x


def esc(s):
    return _html.escape(s)


# --------------------------------------------------------------------------
# 常用 HTML 片段
# --------------------------------------------------------------------------
def p(t):
    return "<p>%s</p>" % t


def h3(t):
    return "<h3>%s</h3>" % t


def ul(items, ordered=False):
    tag = "ol" if ordered else "ul"
    return "<%s>%s</%s>" % (tag, "".join("<li>%s</li>" % i for i in items), tag)


def math_block(t):
    return '<div class="math formula">%s</div>' % t


def callout(kind, t, title=None):
    """kind: highlight（橙）/ warn（红）/ note（蓝）。"""
    head = "<b>%s</b><br>" % title if title else ""
    return '<div class="%s">%s%s</div>' % (kind, head, t)


def table(rows, header=None, cls="table"):
    h = "<thead><tr>%s</tr></thead>" % "".join("<th>%s</th>" % c for c in header) if header else ""
    b = "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % c for c in r) for r in rows)
    return '<table class="%s">%s<tbody>%s</tbody></table>' % (cls, h, b)


def figure(svg, caption=None, max_width=620):
    """svg 可以是 figkit.Svg 对象或 SVG 字符串。"""
    s = svg.inline(max_width) if hasattr(svg, "inline") else svg
    cap = '<div class="figcap">%s</div>' % caption if caption else ""
    return '<figure class="diagram">%s%s</figure>' % (s, cap)


def choice_block(letter, ok, title, body_html):
    """分项解析（选择题选项/小问）：ok=True 显示"正确"，False 显示"错误"，None 不显示标记。"""
    mark = ""
    if ok is True:
        mark = '<span class="mark yes">%s 对</span>' % letter
    elif ok is False:
        mark = '<span class="mark no">%s 错</span>' % letter
    else:
        mark = '<span class="mark">%s</span>' % letter
    return '<div class="choice"><div class="choice-title">%s%s</div>%s</div>' % (mark, title, body_html)


def save(page_html, path):
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(page_html)
    return path


# --------------------------------------------------------------------------
# 样式
# --------------------------------------------------------------------------
_COMMON_CSS = """
.frac{display:inline-flex;flex-direction:column;vertical-align:middle;text-align:center;line-height:1.15;margin:0 2px;font-size:.92em}
.frac>span:first-child{border-bottom:1px solid currentColor;padding:0 3px}
.frac>span:last-child{padding:0 3px}
.sqrt{white-space:nowrap}.radicand{border-top:1px solid currentColor;padding:0 2px;margin-left:1px}
sub,sup{line-height:0}
figure.diagram{margin:14px auto;text-align:center;break-inside:avoid}
figure.diagram svg{max-width:100%;height:auto}
.figcap{font-size:14px;color:#555;margin-top:2px}
"""

CSS_ANALYSIS = """
:root{--ink:#203149;--muted:#617188;--blue:#345b9e;--line:#dfe7f1;--accent:#b76c30}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:#f3f5f8;color:var(--ink);font:16px/1.85 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif}
.wrap{max-width:1000px;margin:auto;padding:32px 20px 72px}
.hero{background:#1d3457;color:#fff;padding:40px;border-radius:18px}
.eyebrow{color:#b8cdea;letter-spacing:.15em;font-size:13px;font-weight:700}
h1{font-size:clamp(28px,4vw,40px);line-height:1.35;margin:10px 0 14px}
.hero p{color:#dce8f7;margin:0}
.ans{display:inline-block;margin-top:17px;padding:5px 15px;background:#f3cb8f;color:#3c2c19;font-weight:800;border-radius:7px}
.tag{display:inline-block;margin:17px 8px 0 0;padding:3px 12px;background:#2f4d7c;color:#cfe0f7;border-radius:7px;font-size:13px}
.toc{display:flex;flex-wrap:wrap;gap:8px;margin:17px 0 0}
.toc a{color:#355889;background:#e9f0fa;padding:5px 12px;border-radius:7px;text-decoration:none;font-size:14px}
.panel{background:white;border:1px solid var(--line);border-radius:16px;padding:30px 34px;margin-top:18px;box-shadow:0 5px 22px #263c5a08}
h2{font-size:24px;line-height:1.4;margin:0 0 18px;display:flex;align-items:center;gap:12px}
h2 .n{display:inline-grid;place-items:center;flex:none;width:34px;height:34px;border-radius:9px;background:#e9f0fb;color:#305a9f;font-size:15px}
h3{font-size:19px;margin:24px 0 8px;color:#2b4266}
p{margin:8px 0 13px}ul,ol{padding-left:23px;margin:8px 0 15px}li{margin:5px 0}
.math{font-family:Georgia,"Times New Roman",serif;font-size:19px;line-height:1.8;background:#f3f6fa;border-radius:9px;padding:12px 17px;overflow-x:auto}
.formula{white-space:nowrap}
.highlight,.warn,.note{border-left:4px solid;padding:12px 16px;margin:16px 0;border-radius:4px}
.highlight{background:#fff7e9;border-color:#d7a45d}.warn{background:#fff1ef;border-color:#db8073}.note{background:#eef5fd;border-color:#799dce}
.muted{color:var(--muted)}
.choice{border-top:1px solid var(--line);padding-top:18px;margin-top:22px}
.choice-title{font-size:19px;font-weight:750}
.mark{display:inline-block;padding:1px 9px;border-radius:5px;font-size:14px;margin-right:7px;background:#eef1f6;color:#44546a}
.yes{background:#e4f5ed;color:#147153}.no{background:#fff0ee;color:#a03f3b}
.table{width:100%;border-collapse:collapse;margin:14px 0}
.table th,.table td{border:1px solid var(--line);padding:10px 12px;text-align:left;vertical-align:top}
.table th{background:#f0f4fa}
.diagram{background:#f6f9fd;border-radius:12px;padding:8px}
.qtext{font-size:17px}
.foot{color:#748198;font-size:13px;text-align:center;margin-top:25px}
@media(max-width:600px){.wrap{padding:14px 10px 45px}.hero,.panel{padding:23px 19px}.math{font-size:16px}h2{font-size:21px}.table{font-size:14px}.table th,.table td{padding:7px}}
@media print{body{background:white}.wrap{max-width:none;padding:0}.hero{background:#e8eff8;color:#1d3457}.hero p,.eyebrow{color:#345b9e}.panel{box-shadow:none;break-inside:avoid}.toc{display:none}}
""" + _COMMON_CSS

CSS_EXAM = """
@page{size:A4;margin:16mm 15mm 18mm 15mm}
*{box-sizing:border-box}
body{margin:0;background:#eceff3;color:#111;font:15px/1.75 "Songti SC","SimSun","STSong","Times New Roman",serif}
.sheet{background:#fff;max-width:820px;margin:18px auto;padding:26px 36px;box-shadow:0 4px 18px #0002}
.sheet.teacher{background:#fffdf8}
h1.exam-title{text-align:center;font-size:24px;margin:4px 0 6px;letter-spacing:.06em}
.exam-sub{text-align:center;color:#333;margin:0 0 10px}
.notice{border:1px solid #111;padding:8px 14px;margin:10px 0 14px;font-size:14px}
.notice b{font-weight:700}
h2.part{font-size:17px;margin:20px 0 6px;font-weight:700;border-bottom:1.5px solid #111;padding-bottom:3px}
.instr{font-size:14px;color:#222;margin:2px 0 10px}
.q{margin:12px 0 16px;break-inside:avoid}
.q .no{font-weight:700;margin-right:4px}
.q .score{color:#444;font-size:13px}
.opts{display:grid;grid-template-columns:1fr;gap:2px;margin:4px 0 0 0;padding-left:1.6em}
.opts.two{grid-template-columns:1fr 1fr}.opts.four{grid-template-columns:repeat(4,1fr)}
.subq{margin:6px 0 6px 1.6em}
.blank{display:inline-block;border-bottom:1px solid #111;min-width:5em;height:1em;vertical-align:baseline}
.math{font-family:"STIX Two Text","Times New Roman",serif;margin:6px 0 6px 1.6em}
.table{border-collapse:collapse;margin:8px auto}
.table th,.table td{border:1px solid #111;padding:4px 10px;text-align:center;font-size:14px}
.table th{background:#f1f1f1}
.table.left td{text-align:left}
.teacher h2.part{border-color:#b76c30;color:#7a3f10}
.teacher .note,.teacher .tip{border-left:4px solid #b76c30;background:#fff3e4;padding:8px 12px;margin:8px 0;font-size:14px}
.ans-line{margin:4px 0}
.pb{break-before:page}
.small{font-size:13px;color:#444}
.foot{font-size:12px;color:#777;text-align:center;margin-top:16px}
@media print{body{background:#fff}.sheet{box-shadow:none;margin:0;max-width:none;padding:0}.sheet+.sheet{break-before:page}}
""" + _COMMON_CSS


# --------------------------------------------------------------------------
# 页面构造
# --------------------------------------------------------------------------
_NUM = "一二三四五六七八九十"


def analysis_page(title, subtitle="", subject="", answer=None, question=None, modules=(), eyebrow=None,
                  tags=(), footer="本页为独立 HTML 文件，可保存、转发并在浏览器中打开。命题意图与构题过程均为依据题面的分析，不代表官方命题说明或真实考生统计。"):
    """生成"命题者视角·六模块解析"页面。
    modules=[(模块名, html)]，会自动加编号一、二、…并生成目录。question 为 html 字符串列表或字符串。"""
    eyebrow = eyebrow or ("命题者视角 · %s · 试题解析" % subject if subject else "命题者视角 · 试题解析")
    toc = ['<a href="#question">原题与答案</a>'] + ['<a href="#m%d">%s、%s</a>' % (i, _NUM[i], t) for i, (t, _) in enumerate(modules)]
    q = "".join(question) if isinstance(question, (list, tuple)) else (question or "")
    parts = ['<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
             '<title>%s</title><style>%s</style></head><body><main class="wrap">' % (esc(title), CSS_ANALYSIS),
             '<header class="hero"><div class="eyebrow">%s</div><h1>%s</h1>%s%s%s</header>' % (
                 esc(eyebrow), title, ("<p>%s</p>" % subtitle) if subtitle else "",
                 "".join('<span class="tag">%s</span>' % t for t in tags),
                 ('<br><span class="ans">参考答案：%s</span>' % answer) if answer else ""),
             '<nav class="toc" aria-label="目录">%s</nav>' % "".join(toc)]
    if q:
        parts.append('<section class="panel" id="question"><h2>原题与参考答案</h2><div class="qtext">%s</div></section>' % q)
    for i, (t, body) in enumerate(modules):
        parts.append('<section class="panel" id="m%d"><h2><span class="n">%s</span>%s</h2>%s</section>' % (i, _NUM[i], t, body))
    parts.append('<div class="foot">%s</div></main></body></html>' % footer)
    return "".join(parts)


def exam_page(title, subject, total, minutes, student_sections, teacher_sections=(), notice=None, school_line=True, footer=""):
    """生成试卷 HTML：学生卷（student_sections）+ 教师卷（teacher_sections：命题说明、蓝图、答案与评分、审校清单）。
    student_sections / teacher_sections = [html, ...]（每个元素是一个已排好的 <h2 class='part'>…</h2> + 题目 的 html 片段）。"""
    notice = notice or ("1. 本试卷共 %s 分，考试时间 %s 分钟。<br>2. 在试卷和答题卡指定位置准确填写学校名称、姓名和考号。<br>3. 试题答案一律填涂或书写在答题卡上，在试卷上作答无效。<br>4. 考试结束后，请将本试卷和答题卡一并交回。" % (total, minutes))
    head = ['<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
            '<title>%s</title><style>%s</style></head><body>' % (esc(title), CSS_EXAM)]
    stu = ['<div class="sheet"><h1 class="exam-title">%s</h1><p class="exam-sub">%s　　　　（满分 %s 分　考试时间 %s 分钟）</p>' % (title, subject, total, minutes)]
    if school_line:
        stu.append('<p class="exam-sub small">学校 ________　班级 ________　姓名 ________　考号 ________</p>')
    stu.append('<div class="notice"><b>考生须知</b><br>%s</div>' % notice)
    stu.extend(student_sections)
    stu.append('<div class="foot">%s</div></div>' % footer)
    out = head + stu
    if teacher_sections:
        out.append('<div class="sheet teacher"><h1 class="exam-title">教师用卷：命题说明 · 蓝图 · 答案与评分</h1><p class="exam-sub small">（本部分不发给考生）</p>')
        out.extend(teacher_sections)
        out.append('</div>')
    out.append('</body></html>')
    return "".join(out)


def part(title, instr=None):
    return '<h2 class="part">%s</h2>%s' % (title, ('<p class="instr">%s</p>' % instr) if instr else "")


def question(no, stem, score=None, opts=None, opts_cols=1, extra=""):
    """一道题。opts=['A. …','B. …']；opts_cols=1/2/4 控制选项列数；extra 放图、子问等。"""
    sc = '<span class="score">（%s分）</span>' % score if score is not None else ""
    o = ""
    if opts:
        cls = {1: "opts", 2: "opts two", 4: "opts four"}[opts_cols]
        o = '<div class="%s">%s</div>' % (cls, "".join("<div>%s</div>" % x for x in opts))
    return '<div class="q"><span class="no">%s.</span>%s%s%s%s</div>' % (no, sc, stem, extra, o)


def subq(label, text, score=None):
    sc = '<span class="score">（%s分）</span>' % score if score is not None else ""
    return '<div class="subq">%s%s %s</div>' % (label, sc, text)


if __name__ == "__main__":
    print("htmlkit 已就绪。")
