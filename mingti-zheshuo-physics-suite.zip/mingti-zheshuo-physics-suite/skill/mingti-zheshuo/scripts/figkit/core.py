# -*- coding: utf-8 -*-
"""figkit.core —— 纯 Python（零依赖）的 SVG 绘图内核，用于高考试题配图。

约定
- 画布坐标：像素，原点在左上，y 向下。数学/物理中"y 向上"的情形请用 Axes（math_.py）做坐标映射。
- 角度：本模块 arc()/polar() 用"数学角度"（度，逆时针为正，0° 指向右）。
- 默认黑白线稿（适合试卷印刷）；颜色参数仅在需要区分曲线时使用。
- 文字 text() 支持轻量标记：  x_0  x_{max}  x^2  v^{-1}  以及希腊字母直接写 α β θ。
  斜体用于物理量/变量（italic=True，默认 True），单位、汉字用 italic=False。
"""
import math
import re
import html

SERIF = "'STIX Two Text','Times New Roman','Songti SC','SimSun',serif"
SANS = "'PingFang SC','Microsoft YaHei','Helvetica Neue',Arial,sans-serif"


def _f(v):
    """数字格式化，控制 SVG 体积。"""
    s = ("%.2f" % v).rstrip("0").rstrip(".")
    return s if s not in ("-0", "") else "0"


def _pts(points):
    return " ".join("%s,%s" % (_f(x), _f(y)) for x, y in points)


_TOKEN = re.compile(r"(_\{[^}]*\}|\^\{[^}]*\}|_[A-Za-z0-9′'\u0370-\u03ff+\-]|\^[A-Za-z0-9′'\u0370-\u03ff+\-])")


def rich(s, size=18, sub_ratio=0.68):
    """把 'v_0^2' 之类的标记转成 <tspan>。返回 SVG 片段（已转义）。"""
    out = []
    shift = size * 0.28
    for part in _TOKEN.split(s):
        if not part:
            continue
        if part[0] in "_^" and _TOKEN.fullmatch(part):
            body = part[2:-1] if part[1] == "{" else part[1]
            dy = shift if part[0] == "_" else -shift * 1.25
            fs = size * sub_ratio
            out.append('<tspan dy="%s" font-size="%s" font-style="normal">%s</tspan>' % (_f(dy), _f(fs), html.escape(body)))
            out.append('<tspan dy="%s">\u200b</tspan>' % _f(-dy))
        else:
            out.append(html.escape(part))
    return "".join(out)


class Svg:
    def __init__(self, w, h, bg="#ffffff", font=SERIF):
        self.w, self.h, self.bg, self.font = w, h, bg, font
        self.body = []
        self._defs = []
        self._marker_ids = {}

    # ---------- 基础 ----------
    def add(self, s):
        self.body.append(s)
        return self

    def defs(self, s):
        self._defs.append(s)

    def _marker(self, color, size):
        key = (color, size)
        if key not in self._marker_ids:
            mid = "ah%d" % len(self._marker_ids)
            self._marker_ids[key] = mid
            self._defs.append(
                '<marker id="%s" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="%s" markerHeight="%s" '
                'markerUnits="userSpaceOnUse" orient="auto-start-reverse"><path d="M0,0.8 L10,5 L0,9.2 Z" fill="%s"/></marker>'
                % (mid, _f(size), _f(size * 0.8), color))
        return self._marker_ids[key]

    @staticmethod
    def _style(stroke="#000", sw=1.5, fill="none", dash=None, cap="round", join="round", opacity=None):
        s = 'stroke="%s" stroke-width="%s" fill="%s" stroke-linecap="%s" stroke-linejoin="%s"' % (stroke, _f(sw), fill, cap, join)
        if dash:
            s += ' stroke-dasharray="%s"' % dash
        if opacity is not None:
            s += ' opacity="%s"' % opacity
        return s

    # ---------- 图元 ----------
    def line(self, x1, y1, x2, y2, sw=1.5, color="#000", dash=None, cap="round"):
        return self.add('<line x1="%s" y1="%s" x2="%s" y2="%s" %s/>' % (_f(x1), _f(y1), _f(x2), _f(y2), self._style(color, sw, "none", dash, cap)))

    def arrow(self, x1, y1, x2, y2, sw=1.8, color="#000", head=11, both=False, dash=None):
        """带箭头线段。head=箭头大小(px)。"""
        mid = self._marker(color, head)
        ends = ' marker-end="url(#%s)"' % mid + (' marker-start="url(#%s)"' % mid if both else "")
        # 让线条在箭头处缩短，避免箭头变钝
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy) or 1
        k = max(0.0, (head * 0.55)) / L
        x2s, y2s = x2 - dx * k, y2 - dy * k
        x1s, y1s = (x1 + dx * k, y1 + dy * k) if both else (x1, y1)
        return self.add('<line x1="%s" y1="%s" x2="%s" y2="%s" %s%s/>' % (_f(x1s), _f(y1s), _f(x2s), _f(y2s), self._style(color, sw, "none", dash, "butt"), ends))

    def polyline(self, pts, sw=1.5, color="#000", dash=None, fill="none"):
        return self.add('<polyline points="%s" %s/>' % (_pts(pts), self._style(color, sw, fill, dash)))

    def polygon(self, pts, sw=1.5, color="#000", fill="none", dash=None, opacity=None):
        return self.add('<polygon points="%s" %s/>' % (_pts(pts), self._style(color, sw, fill, dash, opacity=opacity)))

    def rect(self, x, y, w, h, sw=1.5, color="#000", fill="none", rx=0, dash=None, opacity=None):
        return self.add('<rect x="%s" y="%s" width="%s" height="%s" rx="%s" %s/>' % (_f(x), _f(y), _f(w), _f(h), _f(rx), self._style(color, sw, fill, dash, opacity=opacity)))

    def circle(self, cx, cy, r, sw=1.5, color="#000", fill="none", dash=None):
        return self.add('<circle cx="%s" cy="%s" r="%s" %s/>' % (_f(cx), _f(cy), _f(r), self._style(color, sw, fill, dash)))

    def dot(self, cx, cy, r=3.2, color="#000"):
        return self.add('<circle cx="%s" cy="%s" r="%s" fill="%s"/>' % (_f(cx), _f(cy), _f(r), color))

    def ellipse(self, cx, cy, rx, ry, sw=1.5, color="#000", fill="none", rot=0, dash=None):
        tr = ' transform="rotate(%s %s %s)"' % (_f(rot), _f(cx), _f(cy)) if rot else ""
        return self.add('<ellipse cx="%s" cy="%s" rx="%s" ry="%s" %s%s/>' % (_f(cx), _f(cy), _f(rx), _f(ry), self._style(color, sw, fill, dash), tr))

    def path(self, d, sw=1.5, color="#000", fill="none", dash=None, opacity=None):
        return self.add('<path d="%s" %s/>' % (d, self._style(color, sw, fill, dash, opacity=opacity)))

    def arc(self, cx, cy, r, a0, a1, sw=1.5, color="#000", dash=None, arrow_end=False, head=9):
        """圆弧：a0→a1 为数学角度（度），逆时针为正。"""
        x0, y0 = cx + r * math.cos(math.radians(a0)), cy - r * math.sin(math.radians(a0))
        x1, y1 = cx + r * math.cos(math.radians(a1)), cy - r * math.sin(math.radians(a1))
        large = 1 if abs(a1 - a0) % 360 > 180 else 0
        sweep = 0 if a1 > a0 else 1  # y 向下，逆时针(数学)对应 sweep=0
        mk = ' marker-end="url(#%s)"' % self._marker(color, head) if arrow_end else ""
        return self.add('<path d="M%s,%s A%s,%s 0 %d %d %s,%s" %s%s/>' % (_f(x0), _f(y0), _f(r), _f(r), large, sweep, _f(x1), _f(y1), self._style(color, sw, "none", dash, "butt" if arrow_end else "round"), mk))

    def text(self, x, y, s, size=18, anchor="middle", italic=True, bold=False, color="#000", rotate=None, font=None, baseline="auto", math=True):
        st = "font-style:%s;font-weight:%s" % ("italic" if italic else "normal", "bold" if bold else "normal")
        tr = ' transform="rotate(%s %s %s)"' % (_f(rotate), _f(x), _f(y)) if rotate else ""
        body = rich(s, size) if math else html.escape(s)
        return self.add('<text x="%s" y="%s" font-size="%s" text-anchor="%s" dominant-baseline="%s" fill="%s" font-family="%s" style="%s"%s>%s</text>' % (
            _f(x), _f(y), _f(size), anchor, baseline, color, font or self.font, st, tr, body))

    def label(self, x, y, s, size=18, **kw):
        """正体标注（汉字、单位、选项）。"""
        kw.setdefault("italic", False)
        return self.text(x, y, s, size, **kw)

    def hatch(self, x1, y1, x2, y2, n=12, length=10, angle=-45, sw=1.2, color="#000"):
        """沿线段 (x1,y1)-(x2,y2) 一侧画斜线（地面/墙面/固定端）。angle 为斜线相对线段法向的偏角。"""
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy) or 1
        ux, uy = dx / L, dy / L
        nx, ny = -uy, ux  # 法向（屏幕坐标，顺时针 90°）
        a = math.radians(angle)
        hx = nx * math.cos(a) - ux * math.sin(a)
        hy = ny * math.cos(a) - uy * math.sin(a)
        for i in range(n + 1):
            t = i / n
            px, py = x1 + dx * t, y1 + dy * t
            self.line(px, py, px + hx * length, py + hy * length, sw, color)

    def right_angle(self, x, y, ux, uy, vx, vy, size=10, sw=1.2):
        """在顶点(x,y)处画直角符号，u、v 为两条边的方向向量（屏幕坐标）。"""
        lu = math.hypot(ux, uy) or 1
        lv = math.hypot(vx, vy) or 1
        ux, uy, vx, vy = ux / lu * size, uy / lu * size, vx / lv * size, vy / lv * size
        self.polyline([(x + ux, y + uy), (x + ux + vx, y + uy + vy), (x + vx, y + vy)], sw)

    def angle_mark(self, x, y, a0, a1, r=22, label=None, size=17, sw=1.3, lr=None):
        """在 (x,y) 处标注角度弧（数学角度），可选标签。"""
        self.arc(x, y, r, a0, a1, sw)
        if label:
            am = math.radians((a0 + a1) / 2)
            lr = lr or r + 14
            self.text(x + lr * math.cos(am), y - lr * math.sin(am) + size * 0.35, label, size)

    def dim(self, x1, y1, x2, y2, label, off=14, size=16, sw=1.2):
        """尺寸标注（两端箭头 + 文字），off 为沿法向的偏移。"""
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy) or 1
        nx, ny = -dy / L * off, dx / L * off
        self.line(x1, y1, x1 + nx * 1.25, y1 + ny * 1.25, 0.8)
        self.line(x2, y2, x2 + nx * 1.25, y2 + ny * 1.25, 0.8)
        self.arrow(x1 + nx, y1 + ny, x2 + nx, y2 + ny, sw, head=8, both=True)
        mx, my = (x1 + x2) / 2 + nx * 1.9, (y1 + y2) / 2 + ny * 1.9
        self.text(mx, my + size * 0.35, label, size)

    def caption(self, text, y=None, size=18):
        """图题（如『图 1』），居中放在底部。会在 h 里预留空间时使用。"""
        y = y if y is not None else self.h - 10
        return self.text(self.w / 2, y, text, size, italic=False)

    # ---------- 输出 ----------
    def to_string(self, standalone=True):
        defs = "<defs>%s</defs>" % "".join(self._defs) if self._defs else ""
        bg = '<rect width="100%%" height="100%%" fill="%s"/>' % self.bg if self.bg else ""
        ns = ' xmlns="http://www.w3.org/2000/svg"' if standalone else ""
        return '<svg%s width="%s" height="%s" viewBox="0 0 %s %s" role="img">%s%s%s</svg>' % (
            ns, _f(self.w), _f(self.h), _f(self.w), _f(self.h), defs, bg, "".join(self.body))

    def save(self, path):
        with open(path, "w", encoding="utf-8") as fh:
            fh.write('<?xml version="1.0" encoding="UTF-8"?>\n' + self.to_string())
        return path

    def inline(self, max_width=None):
        """返回可直接嵌入 HTML 的 <svg>（带 style 限宽、自适应）。"""
        s = self.to_string(standalone=False)
        if max_width:
            s = s.replace("<svg ", '<svg style="max-width:%spx;width:100%%;height:auto" ' % _f(max_width), 1)
        return s


def polar(cx, cy, r, deg):
    """数学角度 → 屏幕坐标。"""
    return cx + r * math.cos(math.radians(deg)), cy - r * math.sin(math.radians(deg))


def lerp(a, b, t):
    return a + (b - a) * t


def vec_add(p, v, k=1.0):
    return (p[0] + v[0] * k, p[1] + v[1] * k)


def unit(dx, dy):
    L = math.hypot(dx, dy) or 1
    return dx / L, dy / L
