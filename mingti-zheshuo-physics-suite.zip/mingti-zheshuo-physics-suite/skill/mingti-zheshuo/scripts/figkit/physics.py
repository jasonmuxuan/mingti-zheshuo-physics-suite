# -*- coding: utf-8 -*-
"""figkit.physics —— 力学、电路、场、光学配图元件。所有函数第一个参数是 Svg 对象 s。
坐标均为像素（y 向下）；"角度"一律是数学角度（逆时针为正，0° 向右），与 core.arc 一致。
"""
import math
from .core import Svg, polar, unit, _f

__all__ = [
    "ground", "wall", "block", "incline", "block_on_incline", "force", "spring", "pulley", "rope", "ball", "pendulum_support",
    "wire", "junction", "resistor", "battery", "cell", "switch", "meter", "bulb", "rheostat", "capacitor", "inductor",
    "ac_source", "diode", "lead",
    "field_marks", "efield_lines", "charge", "plates", "lens", "mirror_plane", "ray", "slit_screen",
]


# =============================== 力学 ====================================
def ground(s, x1, x2, y, hatch_n=None, length=10, sw=1.8):
    """水平地面：线 + 下方斜线。"""
    s.line(x1, y, x2, y, sw)
    n = hatch_n or max(3, int((x2 - x1) / 12))
    s.hatch(x1, y, x2, y, n, length, angle=-45 if x2 > x1 else 45, sw=1.1)


def wall(s, x, y1, y2, side="right", n=None, length=10, sw=1.8):
    """竖直墙面。side='right' 表示填充线画在墙的右侧。"""
    s.line(x, y1, x, y2, sw)
    n = n or max(3, int(abs(y2 - y1) / 12))
    if side == "right":
        s.hatch(x, y1, x, y2, n, length, angle=45, sw=1.1)
    else:
        s.hatch(x, y1, x, y2, n, -length, angle=45, sw=1.1)


def block(s, cx, cy, w, h, label=None, size=18, fill="#fff", rot=0, sw=1.8, italic=False):
    tr = ' transform="rotate(%s %s %s)"' % (_f(rot), _f(cx), _f(cy)) if rot else ""
    s.add('<rect x="%s" y="%s" width="%s" height="%s" fill="%s" stroke="#000" stroke-width="%s"%s/>' % (_f(cx - w / 2), _f(cy - h / 2), _f(w), _f(h), fill, _f(sw), tr))
    if label:
        s.text(cx, cy + size * 0.35, label, size, italic=italic)
    return (cx, cy)


def ball(s, cx, cy, r=14, fill="#fff", label=None, size=18, sw=1.8):
    s.circle(cx, cy, r, sw, "#000", fill)
    if label:
        s.text(cx, cy + size * 0.35, label, size)
    return (cx, cy)


def incline(s, x0, y0, length, angle_deg, hatch=True, label_angle=None, size=18):
    """斜面：左下角 (x0,y0) 为锐角顶点 O，斜面向右上升；返回 (底端点, 斜面顶点, 竖直边底点)。
    画出底边 + 斜边 + 竖直边，斜面下方斜线填充。"""
    a = math.radians(angle_deg)
    top = (x0 + length * math.cos(a), y0 - length * math.sin(a))
    foot = (top[0], y0)
    s.polygon([(x0, y0), top, foot], 1.8, "#000", "none")
    if hatch:
        s.hatch(x0, y0, foot[0], foot[1], max(4, int(length / 14)), 10, angle=-45, sw=1.1)
    if label_angle is not None:
        s.arc(x0, y0, 40, 0, angle_deg, 1.3)
        s.text(x0 + 56 * math.cos(a / 2), y0 - 56 * math.sin(a / 2) + 6, label_angle, size)
    return (x0, y0), top, foot


def block_on_incline(s, x0, y0, angle_deg, dist, w=46, h=30, label=None, size=18):
    """放在斜面上的木块（距斜面底端 O 沿斜面 dist 像素处）。返回木块中心。"""
    a = math.radians(angle_deg)
    bx, by = x0 + dist * math.cos(a), y0 - dist * math.sin(a)
    # 木块中心在斜面法向上抬高 h/2
    nx, ny = -math.sin(a), -math.cos(a)  # 斜面外法向（屏幕坐标，向上偏左）
    cx, cy = bx + nx * h / 2, by + ny * h / 2
    block(s, cx, cy, w, h, label, size, rot=-angle_deg)
    return (cx, cy)


def force(s, p, angle_deg, length, label=None, size=18, off=(0, 0), color="#000", sw=2.0, head=11, at_tail=False, dash=None, lpos=None):
    """从点 p 出发，沿数学角度 angle_deg 画长度 length 的受力箭头。
    label 默认放在箭头末端外侧；off 微调；lpos 直接指定标签坐标。"""
    q = polar(p[0], p[1], length, angle_deg)
    s.arrow(p[0], p[1], q[0], q[1], sw, color, head, dash=dash)
    if label:
        if lpos:
            lx, ly = lpos
        else:
            lx, ly = polar(q[0], q[1], size * 0.95, angle_deg)
            ly += size * 0.35
        s.text(lx + off[0], ly + off[1], label, size, color=color)
    return q


def spring(s, x1, y1, x2, y2, coils=8, amp=9, lead=14, sw=1.6):
    """弹簧（锯齿线）；两端各留 lead 的直线。"""
    L = math.hypot(x2 - x1, y2 - y1)
    ux, uy = unit(x2 - x1, y2 - y1)
    nx, ny = -uy, ux
    pts = [(x1, y1), (x1 + ux * lead, y1 + uy * lead)]
    body = L - 2 * lead
    n = coils * 2
    for i in range(1, n):
        t = lead + body * i / n
        sgn = 1 if i % 2 else -1
        pts.append((x1 + ux * t + nx * amp * sgn, y1 + uy * t + ny * amp * sgn))
    pts += [(x2 - ux * lead, y2 - uy * lead), (x2, y2)]
    s.polyline(pts, sw)


def pulley(s, cx, cy, r=18, sw=1.8, support=True):
    s.circle(cx, cy, r, sw)
    s.dot(cx, cy, 3)
    if support:
        s.line(cx, cy, cx, cy - r - 22, 1.6)
        s.line(cx - 22, cy - r - 22, cx + 22, cy - r - 22, 2.0)
        s.hatch(cx - 22, cy - r - 22, cx + 22, cy - r - 22, 7, 8, angle=45, sw=1.0)
        # 填充线在上方
    return (cx, cy)


def rope(s, pts, sw=1.4):
    s.polyline(pts, sw)


def pendulum_support(s, x, y, w=60):
    s.line(x - w / 2, y, x + w / 2, y, 2.0)
    s.hatch(x - w / 2, y, x + w / 2, y, 8, 9, angle=45, sw=1.0)


# =============================== 电路 ====================================
def _frame(p1, p2):
    L = math.hypot(p2[0] - p1[0], p2[1] - p1[1]) or 1
    ux, uy = (p2[0] - p1[0]) / L, (p2[1] - p1[1]) / L
    nx, ny = -uy, ux
    def T(t, d):
        return (p1[0] + ux * t + nx * d, p1[1] + uy * t + ny * d)
    return L, T, (ux, uy), (nx, ny)


def wire(s, pts, sw=1.6):
    s.polyline(pts, sw)


def junction(s, x, y, r=3.4):
    s.dot(x, y, r)


def lead(s, p1, p2, sw=1.6):
    s.line(p1[0], p1[1], p2[0], p2[1], sw)


def resistor(s, p1, p2, w=44, h=16, label=None, size=18, lab_off=24, sw=1.6):
    """电阻（矩形）。p1→p2 为接线端，元件居中。"""
    L, T, u, n = _frame(p1, p2)
    a, b = (L - w) / 2, (L + w) / 2
    s.polyline([p1, T(a, 0)], sw)
    s.polyline([T(b, 0), p2], sw)
    s.polygon([T(a, -h / 2), T(b, -h / 2), T(b, h / 2), T(a, h / 2)], sw, "#000", "#fff")
    if label:
        q = T(L / 2, -lab_off if abs(u[0]) > abs(u[1]) else -lab_off)
        if abs(u[0]) > abs(u[1]):
            s.text(q[0], q[1] + size * 0.3, label, size)
        else:
            s.text(q[0] - 4, q[1] + size * 0.3, label, size)
    return T(L / 2, 0)


def battery(s, p1, p2, n=1, label=None, size=18, sw=1.6, gap=9, long_h=26, short_h=14, plus_at_p1=True, lab_off=24):
    """电池组：n 个单体；长线为正极。p1 端为正极（plus_at_p1=True）。"""
    L, T, u, nrm = _frame(p1, p2)
    total = (2 * n - 1) * gap
    start = (L - total) / 2
    pts_pos = start
    s.polyline([p1, T(start, 0)], sw)
    s.polyline([T(start + total, 0), p2], sw)
    for i in range(2 * n):
        t = start + i * gap
        longer = (i % 2 == 0) if plus_at_p1 else (i % 2 == 1)
        h = long_h if longer else short_h
        if i == 2 * n - 1 and False:
            pass
        s.line(*T(t, -h / 2), *T(t, h / 2), 2.6 if not longer else 1.8)
    if label:
        q = T(L / 2, -lab_off)
        s.text(q[0], q[1] + size * 0.3, label, size)
    return T(L / 2, 0)


def cell(s, p1, p2, **kw):
    return battery(s, p1, p2, n=1, **kw)


def switch(s, p1, p2, closed=False, label="S", size=18, sw=1.6, gap=34, lab_off=24, open_angle=28):
    L, T, u, n = _frame(p1, p2)
    a, b = (L - gap) / 2, (L + gap) / 2
    s.polyline([p1, T(a, 0)], sw)
    s.polyline([T(b, 0), p2], sw)
    s.dot(*T(a, 0), 2.8)
    s.dot(*T(b, 0), 2.8)
    if closed:
        s.line(*T(a, 0), *T(b, 0), sw)
    else:
        e = T(a + gap * math.cos(math.radians(open_angle)), -gap * math.sin(math.radians(open_angle)))
        s.line(*T(a, 0), *e, sw)
    if label:
        q = T(L / 2, -lab_off - 8)
        s.text(q[0], q[1] + size * 0.3, label, size)
    return T(L / 2, 0)


def meter(s, cx, cy, label="A", r=16, size=18, sw=1.6):
    s.circle(cx, cy, r, sw, "#000", "#fff")
    s.text(cx, cy + size * 0.35, label, size, italic=False)


def bulb(s, cx, cy, r=16, label=None, size=18, sw=1.6, lab_off=26):
    s.circle(cx, cy, r, sw, "#000", "#fff")
    d = r * 0.7071
    s.line(cx - d, cy - d, cx + d, cy + d, sw)
    s.line(cx - d, cy + d, cx + d, cy - d, sw)
    if label:
        s.text(cx, cy - lab_off, label, size)


def rheostat(s, p1, p2, slider=0.5, w=70, h=18, label="R", size=18, sw=1.6, wiper_side=-1, wiper_len=34, lab_off=26, show_wiper=True):
    """滑动变阻器：矩形 + 滑片箭头（slider∈[0,1] 位置）。wiper_side=-1 滑片在元件一侧（法向负方向）。"""
    L, T, u, n = _frame(p1, p2)
    a, b = (L - w) / 2, (L + w) / 2
    s.polyline([p1, T(a, 0)], sw)
    s.polyline([T(b, 0), p2], sw)
    s.polygon([T(a, -h / 2), T(b, -h / 2), T(b, h / 2), T(a, h / 2)], sw, "#000", "#fff")
    if show_wiper:
        t = a + (b - a) * slider
        tip = T(t, wiper_side * h / 2)
        tail = T(t, wiper_side * (h / 2 + wiper_len))
        s.arrow(*tail, *tip, sw, head=10)
        if label:
            q = T(t + 16, wiper_side * (h / 2 + wiper_len))
            s.text(q[0], q[1], label, size)
    elif label:
        q = T(L / 2, -lab_off)
        s.text(q[0], q[1], label, size)
    return T(t if show_wiper else L / 2, wiper_side * (h / 2 + wiper_len) if show_wiper else 0)


def capacitor(s, p1, p2, label=None, size=18, sw=1.6, gap=10, h=28, lab_off=26):
    L, T, u, n = _frame(p1, p2)
    a, b = L / 2 - gap / 2, L / 2 + gap / 2
    s.polyline([p1, T(a, 0)], sw)
    s.polyline([T(b, 0), p2], sw)
    s.line(*T(a, -h / 2), *T(a, h / 2), 2.2)
    s.line(*T(b, -h / 2), *T(b, h / 2), 2.2)
    if label:
        q = T(L / 2, -lab_off)
        s.text(q[0], q[1], label, size)


def inductor(s, p1, p2, loops=4, label=None, size=18, sw=1.6, r=9, lab_off=26):
    L, T, u, n = _frame(p1, p2)
    body = loops * 2 * r
    a = (L - body) / 2
    s.polyline([p1, T(a, 0)], sw)
    s.polyline([T(a + body, 0), p2], sw)
    for i in range(loops):
        x0 = a + i * 2 * r
        d = "M%s,%s A%s,%s 0 0 1 %s,%s" % (_f(T(x0, 0)[0]), _f(T(x0, 0)[1]), _f(r), _f(r), _f(T(x0 + 2 * r, 0)[0]), _f(T(x0 + 2 * r, 0)[1]))
        s.path(d, sw)
    if label:
        q = T(L / 2, -lab_off)
        s.text(q[0], q[1], label, size)


def ac_source(s, cx, cy, r=18, sw=1.6, label=None, size=18):
    s.circle(cx, cy, r, sw, "#000", "#fff")
    pts = [(cx - r * 0.6 + r * 1.2 * i / 20, cy - math.sin(i / 20 * 2 * math.pi) * r * 0.32) for i in range(21)]
    s.polyline(pts, 1.4)
    if label:
        s.text(cx, cy - r - 8, label, size)


def diode(s, p1, p2, sw=1.6, size=18, label=None, w=22):
    L, T, u, n = _frame(p1, p2)
    a, b = L / 2 - w / 2, L / 2 + w / 2
    s.polyline([p1, T(a, 0)], sw)
    s.polyline([T(b, 0), p2], sw)
    s.polygon([T(a, -w / 2), T(a, w / 2), T(b, 0)], sw, "#000", "#fff")
    s.line(*T(b, -w / 2), *T(b, w / 2), 2.0)


# =============================== 场 ======================================
def field_marks(s, x, y, w, h, kind="cross", nx=6, ny=4, size=9, sw=1.3, label=None, lsize=19, frame=True):
    """匀强磁场区域：kind='cross'(×，垂直纸面向里) 或 'dot'(·，向外)。"""
    if frame:
        s.rect(x, y, w, h, 1.2, "#000", "none", dash="7,5")
    for i in range(nx):
        for j in range(ny):
            cx = x + w * (i + 0.5) / nx
            cy = y + h * (j + 0.5) / ny
            if kind == "cross":
                d = size * 0.5
                s.line(cx - d, cy - d, cx + d, cy + d, sw)
                s.line(cx - d, cy + d, cx + d, cy - d, sw)
            else:
                s.circle(cx, cy, size * 0.62, sw)
                s.dot(cx, cy, 1.8)
    if label:
        s.text(x + w + 12, y + lsize + 2, label, lsize, anchor="start")


def efield_lines(s, x, y, w, h, n=5, direction="right", sw=1.4, head=10):
    """匀强电场线（平行箭头线），direction ∈ right/left/up/down。"""
    for i in range(n):
        if direction in ("right", "left"):
            yy = y + h * (i + 0.5) / n
            a, b = (x, x + w) if direction == "right" else (x + w, x)
            s.arrow(a, yy, b, yy, sw, head=head)
        else:
            xx = x + w * (i + 0.5) / n
            a, b = (y + h, y) if direction == "up" else (y, y + h)
            s.arrow(xx, a, xx, b, sw, head=head)


def charge(s, cx, cy, sign="+", r=11, fill="#fff", size=16, sw=1.5):
    s.circle(cx, cy, r, sw, "#000", fill)
    d = r * 0.55
    s.line(cx - d, cy, cx + d, cy, 1.5)
    if sign == "+":
        s.line(cx, cy - d, cx, cy + d, 1.5)


def plates(s, x1, x2, y_top, y_bot, label_top=None, label_bot=None, sw=3.0, size=18):
    """水平放置的两块平行板：上板 y_top，下板 y_bot，水平范围 x1~x2。"""
    s.line(x1, y_top, x2, y_top, sw)
    s.line(x1, y_bot, x2, y_bot, sw)
    if label_top:
        s.text(x2 + 14, y_top + 6, label_top, size, anchor="start")
    if label_bot:
        s.text(x2 + 14, y_bot + 6, label_bot, size, anchor="start")


# =============================== 光学 ====================================
def lens(s, cx, cy, h=130, kind="convex", sw=2.0, focal=None, label_f=None, size=17, axis=None):
    """薄透镜（竖直放置）。focal：焦距像素（左右各画焦点 F、F′并标注）。axis=(x1,x2)画主光轴。"""
    if axis:
        s.line(axis[0], cy, axis[1], cy, 1.2, "#000", "9,3,2,3")
    s.line(cx, cy - h / 2, cx, cy + h / 2, sw)
    k = 11
    if kind == "convex":
        for sy in (-1, 1):
            e = cy + sy * h / 2
            s.polyline([(cx - k, e + (-sy) * k), (cx, e), (cx + k, e + (-sy) * k)], sw)
    else:
        for sy in (-1, 1):
            e = cy + sy * h / 2
            s.polyline([(cx - k, e + sy * k), (cx, e), (cx + k, e + sy * k)], sw)
    if focal:
        for sx, nm in ((-1, "F"), (1, "F′")):
            s.dot(cx + sx * focal, cy, 3.2)
            s.text(cx + sx * focal, cy + 22, nm, size)


def mirror_plane(s, x1, y1, x2, y2, hatch_n=10, length=9, sw=2.0):
    s.line(x1, y1, x2, y2, sw)
    s.hatch(x1, y1, x2, y2, hatch_n, length, angle=-45, sw=1.0)


def ray(s, pts, arrows=True, sw=1.6, dash=None, head=10, color="#000", arrow_at=0.5):
    """光线：折线，arrows=True 在每一段中点处加箭头。"""
    for a, b in zip(pts[:-1], pts[1:]):
        s.line(a[0], a[1], b[0], b[1], sw, color, dash)
        if arrows:
            mx, my = a[0] + (b[0] - a[0]) * arrow_at, a[1] + (b[1] - a[1]) * arrow_at
            ux, uy = unit(b[0] - a[0], b[1] - a[1])
            s.arrow(mx - ux * 1, my - uy * 1, mx + ux * 6, my + uy * 6, sw, color, head)


def slit_screen(s, x, y1, y2, slits, gap_h=10, sw=3.0):
    """带狭缝的挡板：slits 为缝中心 y 坐标列表。"""
    cur = y1
    for yc in sorted(slits):
        s.line(x, cur, x, yc - gap_h / 2, sw)
        cur = yc + gap_h / 2
    s.line(x, cur, x, y2, sw)
