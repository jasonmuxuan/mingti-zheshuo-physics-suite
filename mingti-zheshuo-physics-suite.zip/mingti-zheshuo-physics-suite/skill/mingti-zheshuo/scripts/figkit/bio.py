# -*- coding: utf-8 -*-
"""figkit.bio —— 生物学配图：系谱图、信号通路/调控图、凝胶电泳、基因结构与引物、食物网、细胞示意。"""
import math
from .core import Svg, polar, unit, _f

__all__ = ["pedigree", "pathway", "gel", "gene_map", "food_web", "cell_outline", "inhibit"]


def inhibit(s, p, q, sw=1.8, bar=9):
    """抑制符号（T 形线）：从 p 指向 q，末端画横杠。"""
    s.line(p[0], p[1], q[0], q[1], sw)
    ux, uy = unit(q[0] - p[0], q[1] - p[1])
    nx, ny = -uy, ux
    s.line(q[0] - nx * bar, q[1] - ny * bar, q[0] + nx * bar, q[1] + ny * bar, sw + 0.6)


def pedigree(s, people, couples, children, size=15, sym=24, sw=1.7, gen_labels=None, label_x=24):
    """系谱图。
    people={'I1':(x,y,'M'|'F', 状态)}  状态：0 正常 / 1 患者(涂黑) / 2 携带者(半涂) / None 未知('?')；可加第5项文本标签。
    couples=[('I1','I2')]            夫妻连线（同一行）。
    children={('I1','I2'):['II1','II2']}   子代：由夫妻连线中点下垂再分叉。
    gen_labels=[(y,'Ⅰ'),...] 在左侧标注代数。"""
    pos = {}
    for k, v in people.items():
        x, y, sex, st = v[0], v[1], v[2], v[3]
        pos[k] = (x, y)
        h = sym / 2
        if sex == "M":
            s.rect(x - h, y - h, sym, sym, sw, "#000", "#000" if st == 1 else "#fff")
            if st == 2:
                s.add('<rect x="%s" y="%s" width="%s" height="%s" fill="#000"/>' % (_f(x - h), _f(y - h), _f(h), _f(sym)))
                s.rect(x - h, y - h, sym, sym, sw)
        else:
            s.circle(x, y, h, sw, "#000", "#000" if st == 1 else "#fff")
            if st == 2:
                s.add('<path d="M%s,%s A%s,%s 0 0 0 %s,%s Z" fill="#000"/>' % (_f(x), _f(y - h), _f(h), _f(h), _f(x), _f(y + h)))
                s.circle(x, y, h, sw)
        if st is None:
            s.text(x, y + size * 0.35, "?", size, italic=False)
        lab = v[4] if len(v) > 4 else k
        if lab:
            s.text(x, y + h + size + 3, lab, size - 2, italic=False)
    for a, b in couples:
        (xa, ya), (xb, yb) = pos[a], pos[b]
        h = sym / 2
        s.line(min(xa, xb) + h, ya, max(xa, xb) - h, yb, sw)
    for (a, b), kids in children.items():
        (xa, ya), (xb, yb) = pos[a], pos[b]
        mx = (xa + xb) / 2
        ky = pos[kids[0]][1]
        drop = (ya + ky) / 2 + sym * 0.15
        s.line(mx, ya, mx, drop, sw)
        xs = [pos[k][0] for k in kids]
        s.line(min(xs + [mx]), drop, max(xs + [mx]), drop, sw)
        for k in kids:
            s.line(pos[k][0], drop, pos[k][0], pos[k][1] - sym / 2, sw)
    for (y, t) in (gen_labels or []):
        s.text(label_x, y + 6, t, size + 3, italic=False)
    return pos


def pathway(s, nodes, edges, size=17, sw=1.6, box=True):
    """信号通路/调控图。nodes={id:(cx,cy,'文字')}（可含 \\n）；edges=[(a,b,'->'|'-|', 可选标签, 可选虚线)]。
    '->' 促进/转化，'-|' 抑制（T 形）。文字框自动按字数估宽。"""
    dims = {}
    for nid, (cx, cy, txt) in nodes.items():
        parts = txt.split("\n")
        w = max(len(p) for p in parts) * size * 0.98 + 22
        h = len(parts) * (size + 5) + 12
        dims[nid] = (cx, cy, w, h)
        if box:
            s.rect(cx - w / 2, cy - h / 2, w, h, sw, "#000", "#fff", rx=5)
        for k, p in enumerate(parts):
            s.text(cx, cy + size * 0.33 + (k - (len(parts) - 1) / 2) * (size + 5), p, size, italic=False)

    def edge_pts(a, b):
        ax, ay, aw, ah = dims[a]
        bx, by, bw, bh = dims[b]
        dx, dy = bx - ax, by - ay
        if abs(dx) * ah > abs(dy) * aw:
            sx = 1 if dx > 0 else -1
            return (ax + sx * aw / 2, ay), (bx - sx * bw / 2, by)
        sy = 1 if dy > 0 else -1
        return (ax, ay + sy * ah / 2), (bx, by - sy * bh / 2)

    for e in edges:
        a, b, kind = e[0], e[1], e[2]
        lab = e[3] if len(e) > 3 else None
        dash = "6,4" if (len(e) > 4 and e[4]) else None
        p, q = edge_pts(a, b)
        if kind == "-|":
            inhibit(s, p, q, sw)
        else:
            s.arrow(p[0], p[1], q[0], q[1], sw, head=10, dash=dash)
        if lab:
            if abs(q[0] - p[0]) >= abs(q[1] - p[1]):
                s.text((p[0] + q[0]) / 2, (p[1] + q[1]) / 2 - 12, lab, size - 2, italic=False)
            else:
                s.text((p[0] + q[0]) / 2 + 10, (p[1] + q[1]) / 2 + 5, lab, size - 2, italic=False, anchor="start")


def gel(s, x, y, w, h, lanes, bands, size=16, well_h=8, marker_labels=None):
    """凝胶电泳示意。lanes=['M','1','2',...]；bands={lane_index:[位置0~1(0 靠近点样孔),…]}；
    marker_labels={位置:'文字'} 在左侧标注片段大小。"""
    s.rect(x, y, w, h, 1.6, "#000", "#222")
    n = len(lanes)
    lw = w / n
    for i, nm in enumerate(lanes):
        cx = x + lw * (i + 0.5)
        s.rect(cx - lw * 0.32, y + 6, lw * 0.64, well_h, 0, "none", "#fff")
        s.text(cx, y - 8, nm, size, italic=False)
        for pos in bands.get(i, []):
            by = y + 14 + well_h + (h - 34 - well_h) * pos
            s.rect(cx - lw * 0.3, by - 3, lw * 0.6, 6, 0, "none", "#fff")
    for pos, t in (marker_labels or {}).items():
        by = y + 14 + well_h + (h - 34 - well_h) * pos
        s.text(x - 8, by + size * 0.35, t, size - 1, anchor="end", italic=False)


def gene_map(s, x, y, w, parts, primers=None, size=17, h=26, scale=1.0, line_y=None):
    """基因结构示意：parts=[(宽度占比,'名称',填充)]，自左向右排列；
    primers=[(位置0~1,'F1','right'|'left', 上下偏移)] 在上方/下方画引物箭头。"""
    tot = float(sum(p[0] for p in parts))
    cx = x
    s.line(x - 14, y + h / 2, x + w + 14, y + h / 2, 1.6)
    for frac, name, fill in parts:
        pw = w * frac / tot
        s.rect(cx, y, pw, h, 1.6, "#000", fill)
        s.text(cx + pw / 2, y + h / 2 + size * 0.33, name, size - 1, italic=False, color="#fff" if fill in ("#000", "#333", "#444444") else "#000")
        cx += pw
    for pos, nm, direction, off in (primers or []):
        px = x + w * pos
        py = y - 20 if off <= 0 else y + h + 20
        L = 46
        if direction == "right":
            s.arrow(px, py, px + L, py, 1.8, head=10)
            s.text(px + L / 2, py + (-8 if off <= 0 else 20), nm, size - 1, italic=False)
        else:
            s.arrow(px, py, px - L, py, 1.8, head=10)
            s.text(px - L / 2, py + (-8 if off <= 0 else 20), nm, size - 1, italic=False)
        s.line(px, py, px, y if off <= 0 else y + h, 0.9, "#000", "3,3")


def food_web(s, nodes, edges, size=17):
    """食物网：nodes={'草':(x,y)}；edges=[('草','兔')] 箭头由被捕食者指向捕食者。文字用椭圆框。"""
    dims = {}
    for nm, (cx, cy) in nodes.items():
        w = len(nm) * size + 26
        dims[nm] = (cx, cy, w, size + 16)
        s.ellipse(cx, cy, w / 2, (size + 16) / 2, 1.5, "#000", "#fff")
        s.text(cx, cy + size * 0.33, nm, size, italic=False)
    for a, b in edges:
        ax, ay, aw, ah = dims[a]
        bx, by, bw, bh = dims[b]
        ux, uy = unit(bx - ax, by - ay)
        def edge_pt(cx, cy, w, h, ux, uy):
            t = 1.0 / math.sqrt((ux * 2 / w) ** 2 + (uy * 2 / h) ** 2)
            return cx + ux * t, cy + uy * t
        p = edge_pt(ax, ay, aw, ah, ux, uy)
        q = edge_pt(bx, by, bw, bh, -ux, -uy)
        s.arrow(p[0], p[1], q[0], q[1], 1.5, head=9)


def cell_outline(s, cx, cy, rx=120, ry=90, nucleus=True, membrane_w=3.0, label=None, size=17):
    """细胞轮廓 + 细胞核（用于简单示意；复杂细胞器请用 ellipse/path 自行添加）。"""
    s.ellipse(cx, cy, rx, ry, membrane_w, "#000", "#fff")
    if nucleus:
        s.ellipse(cx - rx * 0.1, cy, rx * 0.34, ry * 0.4, 1.8, "#000", "#e8e8e8")
        s.circle(cx - rx * 0.1, cy, 8, 1.4, "#000", "#999")
    if label:
        s.text(cx, cy + ry + size + 8, label, size, italic=False)
