# -*- coding: utf-8 -*-
"""figkit.math_ —— 数学/通用坐标图、隐函数曲线、立体几何、平面几何标注。
物理 v-t、x-t 图、化学/生物曲线也复用 Axes。
"""
import math
from .core import Svg, polar, unit, _f

NAN = float("nan")


def _nice_step(span, target=6):
    raw = span / float(target)
    mag = 10 ** math.floor(math.log10(raw))
    for m in (1, 2, 2.5, 5, 10):
        if raw <= m * mag:
            return m * mag
    return 10 * mag


class Axes:
    """数据坐标 → 像素的映射 + 坐标轴。

    ax = Axes(svg, left, top, width, height, xlim=(-3,3), ylim=(-2,4))
    left/top/width/height 为绘图区像素范围（不含轴标签空间）。
    """

    def __init__(self, svg, left, top, width, height, xlim, ylim, clip_pad=0.0):
        self.s, self.l, self.t, self.w, self.h = svg, left, top, width, height
        self.xlim, self.ylim = xlim, ylim
        self.clip_pad = clip_pad

    # ---- 映射 ----
    def px(self, x):
        return self.l + (x - self.xlim[0]) / (self.xlim[1] - self.xlim[0]) * self.w

    def py(self, y):
        return self.t + self.h - (y - self.ylim[0]) / (self.ylim[1] - self.ylim[0]) * self.h

    def P(self, x, y):
        return self.px(x), self.py(y)

    # ---- 坐标轴 ----
    def draw_axes(self, xlabel="x", ylabel="y", origin_label="O", xticks=None, yticks=None,
                  xtick_labels=None, ytick_labels=None, grid=False, cross=(0, 0), arrows=True,
                  tick_size=15, label_size=20, show_ticks=True, box=False, sw=1.6, tick_len=4,
                  xlabel_pos=None, ylabel_pos=None, ext=14, show_origin_label=True, xlabel_anchor="start"):
        """cross=轴交点（数据坐标，会被截入范围内）；box=True 画成外框坐标（化学/生物曲线常用）。
        xticks/yticks 为刻度值列表；xtick_labels 可传 {值:'文本'} 覆盖（如 π/2）。
        """
        s = self.s
        cx = min(max(cross[0], self.xlim[0]), self.xlim[1])
        cy = min(max(cross[1], self.ylim[0]), self.ylim[1])
        X0, X1, Y0, Y1 = self.l, self.l + self.w, self.t + self.h, self.t
        ax_x, ax_y = self.px(cx), self.py(cy)
        if box:
            s.rect(self.l, self.t, self.w, self.h, sw)
            ax_x, ax_y = X0, Y0
        # 网格
        xs = xticks if xticks is not None else self._auto_ticks(self.xlim, cross[0])
        ys = yticks if yticks is not None else self._auto_ticks(self.ylim, cross[1])
        if grid:
            for x in xs:
                s.line(self.px(x), Y1, self.px(x), Y0, 0.6, "#bbb")
            for y in ys:
                s.line(X0, self.py(y), X1, self.py(y), 0.6, "#bbb")
        # 轴线
        if not box:
            if arrows:
                s.arrow(X0 - (ext * 0.4 if cx == self.xlim[0] else 0), ax_y, X1 + ext, ax_y, sw, head=11)
                s.arrow(ax_x, Y0 + (ext * 0.4 if cy == self.ylim[0] else 0), ax_x, Y1 - ext, sw, head=11)
            else:
                s.line(X0, ax_y, X1, ax_y, sw)
                s.line(ax_x, Y0, ax_x, Y1, sw)
        # 刻度与数字
        if show_ticks:
            for x in xs:
                if abs(x - cx) < 1e-9 and not box and show_origin_label:
                    continue
                px = self.px(x)
                s.line(px, ax_y, px, ax_y - tick_len, 1.2)
                txt = (xtick_labels or {}).get(x, self._fmt(x))
                if txt != "":
                    s.text(px, ax_y + tick_size + 3, txt, tick_size, italic=False)
            for y in ys:
                if abs(y - cy) < 1e-9 and not box and show_origin_label:
                    continue
                py = self.py(y)
                s.line(ax_x, py, ax_x + tick_len, py, 1.2)
                txt = (ytick_labels or {}).get(y, self._fmt(y))
                if txt != "":
                    s.text(ax_x - 7, py + tick_size * 0.35, txt, tick_size, anchor="end", italic=False)
        if origin_label and not box and show_origin_label and abs(cx) < 1e9:
            s.text(ax_x - 12, ax_y + tick_size + 3, origin_label, label_size - 2)
        # 轴名
        if xlabel:
            xp = xlabel_pos or (X1 + ext + 8, ax_y + 6)
            s.text(xp[0], xp[1], xlabel, label_size, anchor=xlabel_anchor)
        if ylabel:
            yp = ylabel_pos or (ax_x + 14, Y1 - ext - 4)
            s.text(yp[0], yp[1], ylabel, label_size)
        return self

    @staticmethod
    def _fmt(v):
        if abs(v - round(v)) < 1e-9:
            return str(int(round(v)))
        return ("%.3g" % v)

    @staticmethod
    def _auto_ticks(lim, cross):
        step = _nice_step(lim[1] - lim[0], 6)
        k0 = math.ceil(lim[0] / step - 1e-9)
        k1 = math.floor(lim[1] / step + 1e-9)
        return [round(k * step, 10) for k in range(k0, k1 + 1)]

    # ---- 曲线 ----
    def _clip_y(self, pts):
        """将折线按 ylim 裁剪，返回若干段。pts: [(x,y)] 数据坐标，None 表示断点。"""
        y0, y1 = self.ylim
        pad = (y1 - y0) * self.clip_pad
        lo, hi = y0 - pad, y1 + pad
        segs, cur = [], []
        prev = None
        for p in pts:
            if p is None or p[1] != p[1] or math.isinf(p[1]):
                if cur:
                    segs.append(cur)
                cur, prev = [], None
                continue
            inside = lo <= p[1] <= hi
            if prev is not None:
                pin = lo <= prev[1] <= hi
                if pin and not inside:
                    yb = hi if p[1] > hi else lo
                    t = (yb - prev[1]) / (p[1] - prev[1])
                    cur.append((prev[0] + (p[0] - prev[0]) * t, yb))
                    segs.append(cur)
                    cur = []
                elif (not pin) and inside:
                    yb = hi if prev[1] > hi else lo
                    t = (yb - prev[1]) / (p[1] - prev[1])
                    cur = [(prev[0] + (p[0] - prev[0]) * t, yb)]
            if inside:
                cur.append(p)
            prev = p
        if cur:
            segs.append(cur)
        return [sg for sg in segs if len(sg) > 1]

    def plot(self, f, a=None, b=None, n=800, color="#000", sw=2.0, dash=None, jump=None, hole_at=None, label=None, label_at=None, label_off=(8, -8), size=18):
        """画 y=f(x)。jump：相邻点 |Δy| 超过 jump 时视为断点（渐近线/分段间断），默认取 ylim 跨度的 0.6 倍。
        label：曲线名；label_at：标注点 x。"""
        a = self.xlim[0] if a is None else a
        b = self.xlim[1] if b is None else b
        jump = jump if jump is not None else (self.ylim[1] - self.ylim[0]) * 0.6
        pts, prev = [], None
        for i in range(n + 1):
            x = a + (b - a) * i / n
            try:
                y = f(x)
                if isinstance(y, complex):
                    y = NAN
            except Exception:
                y = NAN
            if y == y and prev is not None and prev == prev and abs(y - prev) > jump:
                pts.append(None)
            pts.append((x, y) if y == y else None)
            prev = y
        self._emit(self._clip_y(pts), color, sw, dash)
        if label:
            x = label_at if label_at is not None else b
            try:
                yv = f(x)
                self.s.text(self.px(x) + label_off[0], self.py(yv) + label_off[1], label, size)
            except Exception:
                pass
        return self

    def parametric(self, fx, fy, t0, t1, n=600, color="#000", sw=2.0, dash=None):
        pts = []
        for i in range(n + 1):
            t = t0 + (t1 - t0) * i / n
            try:
                pts.append((fx(t), fy(t)))
            except Exception:
                pts.append(None)
        self._emit(self._clip_y(pts), color, sw, dash)
        return self

    def polyline_data(self, pts, color="#000", sw=2.0, dash=None, markers=False, r=3.5):
        """数据折线（实验数据、v-t 分段图）。"""
        self._emit([pts], color, sw, dash)
        if markers:
            for x, y in pts:
                self.s.dot(self.px(x), self.py(y), r, color)
        return self

    def _emit(self, segs, color, sw, dash):
        for sg in segs:
            self.s.polyline([self.P(x, y) for x, y in sg], sw, color, dash)

    def implicit(self, F, n=260, color="#000", sw=2.0, dash=None, xlim=None, ylim=None):
        """隐函数曲线 F(x,y)=0（marching squares），适合圆锥曲线、含绝对值曲线。"""
        xl = xlim or self.xlim
        yl = ylim or self.ylim
        nx = n
        ny = n
        xs = [xl[0] + (xl[1] - xl[0]) * i / nx for i in range(nx + 1)]
        ys = [yl[0] + (yl[1] - yl[0]) * j / ny for j in range(ny + 1)]
        V = [[F(x, y) for y in ys] for x in xs]
        d = []

        def interp(p, q, vp, vq):
            t = vp / (vp - vq) if vp != vq else 0.5
            return (p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t)

        for i in range(nx):
            for j in range(ny):
                c = [(xs[i], ys[j]), (xs[i + 1], ys[j]), (xs[i + 1], ys[j + 1]), (xs[i], ys[j + 1])]
                v = [V[i][j], V[i + 1][j], V[i + 1][j + 1], V[i][j + 1]]
                idx = sum((1 << k) for k in range(4) if v[k] > 0)
                if idx in (0, 15):
                    continue
                edges = {}
                for k in range(4):
                    k2 = (k + 1) % 4
                    if (v[k] > 0) != (v[k2] > 0):
                        edges[k] = interp(c[k], c[k2], v[k], v[k2])
                keys = list(edges.keys())
                if len(keys) == 2:
                    pairs = [(keys[0], keys[1])]
                elif len(keys) == 4:
                    pairs = [(0, 3), (1, 2)] if (sum(v) / 4.0 > 0) == (v[0] > 0) else [(0, 1), (2, 3)]
                else:
                    continue
                for a, b in pairs:
                    (x1, y1), (x2, y2) = self.P(*edges[a]), self.P(*edges[b])
                    d.append("M%s,%sL%s,%s" % (_f(x1), _f(y1), _f(x2), _f(y2)))
        self.s.path("".join(d), sw, color, "none", dash)
        return self

    def fill_between(self, f, g, a, b, n=300, fill="#000", opacity=0.12):
        up = [self.P(a + (b - a) * i / n, f(a + (b - a) * i / n)) for i in range(n + 1)]
        dn = [self.P(a + (b - a) * i / n, g(a + (b - a) * i / n)) for i in range(n, -1, -1)]
        self.s.polygon(up + dn, 0, "none", fill, opacity=opacity)
        return self

    def fill_polygon(self, pts, fill="#000", opacity=0.12):
        self.s.polygon([self.P(x, y) for x, y in pts], 0, "none", fill, opacity=opacity)
        return self

    # ---- 点线标注 ----
    def point(self, x, y, label=None, dx=8, dy=-8, hollow=False, r=3.6, size=18, italic=True, color="#000"):
        px, py = self.P(x, y)
        if hollow:
            self.s.circle(px, py, r + 0.6, 1.6, color, "#fff")
        else:
            self.s.dot(px, py, r, color)
        if label:
            self.s.text(px + dx, py + dy, label, size, italic=italic)
        return self

    def hline(self, y, x0=None, x1=None, dash="6,4", sw=1.2, label=None, label_side="left", size=17, color="#000"):
        x0 = self.xlim[0] if x0 is None else x0
        x1 = self.xlim[1] if x1 is None else x1
        self.s.line(self.px(x0), self.py(y), self.px(x1), self.py(y), sw, color, dash)
        if label:
            if label_side == "left":
                self.s.text(self.px(self.xlim[0]) - 6 if x0 == self.xlim[0] else self.px(x0) - 6, self.py(y) + 6, label, size, anchor="end", italic=False)
            else:
                self.s.text(self.px(x1) + 6, self.py(y) + 6, label, size, anchor="start")
        return self

    def vline(self, x, y0=None, y1=None, dash="6,4", sw=1.2, label=None, size=17, color="#000", label_dy=20):
        y0 = self.ylim[0] if y0 is None else y0
        y1 = self.ylim[1] if y1 is None else y1
        self.s.line(self.px(x), self.py(y0), self.px(x), self.py(y1), sw, color, dash)
        if label:
            self.s.text(self.px(x), self.py(self.ylim[0] if y0 == self.ylim[0] else y0) + label_dy, label, size, italic=False)
        return self

    def drop_lines(self, x, y, xlabel=None, ylabel=None, size=17):
        """从点 (x,y) 向两轴作虚线垂线，并标注。"""
        self.s.line(self.px(x), self.py(y), self.px(x), self.py(0 if self.ylim[0] <= 0 <= self.ylim[1] else self.ylim[0]), 1.1, "#000", "5,4")
        self.s.line(self.px(x), self.py(y), self.px(0 if self.xlim[0] <= 0 <= self.xlim[1] else self.xlim[0]), self.py(y), 1.1, "#000", "5,4")
        if xlabel:
            self.s.text(self.px(x), self.py(0 if self.ylim[0] <= 0 <= self.ylim[1] else self.ylim[0]) + 22, xlabel, size)
        if ylabel:
            self.s.text(self.px(0 if self.xlim[0] <= 0 <= self.xlim[1] else self.xlim[0]) - 8, self.py(y) + 6, ylabel, size, anchor="end")
        return self

    def segment(self, p, q, sw=1.8, color="#000", dash=None):
        self.s.line(*self.P(*p), *self.P(*q), sw, color, dash)
        return self

    def arrow_data(self, p, q, sw=1.8, color="#000", head=11):
        self.s.arrow(*self.P(*p), *self.P(*q), sw, color, head)
        return self


# --------------------------------------------------------------------------
# 立体几何：斜二测（cabinet）投影
# --------------------------------------------------------------------------
class Solid3D:
    """斜二测画法：x 向右、y 向"屏幕内"（画成 45° 且缩短）、z 向上。
    s3 = Solid3D(svg, ox, oy, unit=70, depth=0.5, angle=45)
    s3.v('A',0,0,0); s3.v('B',3,0,0) ...
    s3.edge('A','B'); s3.edge('A','D',hidden=True)   # hidden=True 画虚线
    s3.label('A', dx, dy)   # 标点名（偏移像素）
    """

    def __init__(self, svg, ox, oy, unit=70, depth=0.5, angle=45):
        self.s, self.ox, self.oy, self.u = svg, ox, oy, unit
        self.k, self.a = depth, math.radians(angle)
        self.V = {}

    def pt(self, x, y, z):
        return (self.ox + self.u * (x + self.k * y * math.cos(self.a)),
                self.oy - self.u * (z + self.k * y * math.sin(self.a)))

    def v(self, name, x, y, z):
        self.V[name] = (x, y, z)
        return self

    def P(self, name):
        if isinstance(name, str):
            return self.pt(*self.V[name])
        return self.pt(*name)

    def edge(self, a, b, hidden=False, sw=1.7, color="#000"):
        p, q = self.P(a), self.P(b)
        self.s.line(p[0], p[1], q[0], q[1], sw, color, "6,4" if hidden else None)
        return self

    def edges(self, pairs, hidden_pairs=()):
        hid = {tuple(sorted(h)) for h in hidden_pairs}
        for a, b in pairs:
            self.edge(a, b, hidden=tuple(sorted((a, b))) in hid)
        return self

    def face(self, names, fill="#000", opacity=0.10):
        self.s.polygon([self.P(n) for n in names], 0, "none", fill, opacity=opacity)
        return self

    def label(self, name, dx=0, dy=0, text=None, size=20, italic=True):
        x, y = self.P(name)
        self.s.text(x + dx, y + dy, text or name, size, italic=italic)
        return self

    def point(self, name, x, y, z, label=None, dx=8, dy=-8, r=3.2, size=20):
        """加一个辅助点（线段中点、交点等）并作标记。"""
        self.V[name] = (x, y, z)
        px, py = self.P(name)
        self.s.dot(px, py, r)
        if label is not None:
            self.s.text(px + dx, py + dy, label, size)
        return self

    def axes(self, length=3.3, labels=("x", "y", "z"), size=20):
        o = self.pt(0, 0, 0)
        for (vec, lab) in zip([(length, 0, 0), (0, length, 0), (0, 0, length)], labels):
            e = self.pt(*vec)
            self.s.arrow(o[0], o[1], e[0], e[1], 1.7, head=11)
            self.s.text(e[0] + 12, e[1] + 6, lab, size)
        return self

    # ---- 常用几何体 ----
    @staticmethod
    def box(s3, a, b, c, names="ABCD-A1B1C1D1", hidden=True, labels=True, size=20):
        """长方体：底面 ABCD（A 在前左下，B 前右下，C 后右下，D 后左下），上底 A1B1C1D1。a=x 向，b=y 向（深度），c=z 向。"""
        n = ["A", "B", "C", "D", "A_1", "B_1", "C_1", "D_1"]
        coords = [(0, 0, 0), (a, 0, 0), (a, b, 0), (0, b, 0), (0, 0, c), (a, 0, c), (a, b, c), (0, b, c)]
        for nm, co in zip(n, coords):
            s3.v(nm, *co)
        front = [("A", "B"), ("B", "B_1"), ("B_1", "A_1"), ("A_1", "A"), ("B_1", "C_1"), ("C_1", "D_1"), ("D_1", "A_1"), ("B", "C"), ("C", "C_1")]
        back = [("A", "D"), ("D", "C"), ("D", "D_1")]
        for p, q in front:
            s3.edge(p, q)
        for p, q in back:
            s3.edge(p, q, hidden=hidden)
        if labels:
            off = {"A": (-14, 14), "B": (14, 16), "C": (14, 2), "D": (-14, 2), "A_1": (-16, -6), "B_1": (-4, -12), "C_1": (14, -8), "D_1": (-12, -10)}
            for nm in n:
                s3.label(nm, *off[nm], size=size)
        return s3


# --------------------------------------------------------------------------
# 平面几何小工具
# --------------------------------------------------------------------------
def label_vertices(s, pts, center=None, off=18, size=20, italic=True):
    """给多边形/点标字母：字母放在"远离中心"一侧。pts={'A':(x,y),...}。"""
    if center is None:
        center = (sum(p[0] for p in pts.values()) / len(pts), sum(p[1] for p in pts.values()) / len(pts))
    for name, (x, y) in pts.items():
        ux, uy = unit(x - center[0], y - center[1])
        s.text(x + ux * off, y + uy * off + size * 0.33, name, size, italic=italic)


def polygon_labeled(s, pts, names=None, sw=1.8, fill="none", off=18, size=20, dots=False):
    """画多边形并标顶点。pts 为坐标列表，names 为对应字母（如 'ABC'）。返回 {名:点}。"""
    s.polygon(pts, sw, "#000", fill)
    names = names or [chr(65 + i) for i in range(len(pts))]
    d = dict(zip(names, pts))
    label_vertices(s, d, off=off, size=size)
    if dots:
        for p in pts:
            s.dot(*p, 3)
    return d


def midpoint(p, q):
    return ((p[0] + q[0]) / 2.0, (p[1] + q[1]) / 2.0)


def foot_of_perpendicular(p, a, b):
    """点 p 到直线 ab 的垂足。"""
    ax, ay = a
    bx, by = b
    dx, dy = bx - ax, by - ay
    t = ((p[0] - ax) * dx + (p[1] - ay) * dy) / float(dx * dx + dy * dy)
    return (ax + t * dx, ay + t * dy)


def mark_equal(s, p, q, n=1, size=7, sw=1.4):
    """在线段 pq 中点处画等长记号（n 道短斜线）。"""
    mx, my = midpoint(p, q)
    ux, uy = unit(q[0] - p[0], q[1] - p[1])
    nx, ny = -uy, ux
    for i in range(n):
        k = (i - (n - 1) / 2.0) * 5
        cx, cy = mx + ux * k, my + uy * k
        s.line(cx - nx * size + ux * 3, cy - ny * size + uy * 3, cx + nx * size - ux * 3, cy + ny * size - uy * 3, sw)
