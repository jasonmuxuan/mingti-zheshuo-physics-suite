# -*- coding: utf-8 -*-
"""figkit.chem —— 化学配图：结构式(骨架式)、仪器、工艺流程、能量图、晶胞、电化学装置。"""
import math
from .core import Svg, polar, unit, _f
from .math_ import Axes, Solid3D

__all__ = ["Mol", "benzene_ring", "beaker", "conical_flask", "round_flask", "test_tube", "alcohol_lamp", "glass_tube",
           "gas_bottle", "trough", "funnel_filter", "burette", "stopper", "process_flow", "energy_profile", "cube_cell",
           "galvanic_cell", "electrolytic_cell", "liquid_level", "flask_stand"]


# ============================ 结构式 =====================================
class Mol:
    """骨架式结构式（键线式）。键长单位 = bond 像素。
    m = Mol(s, bond=46)
    m.atom('a', x, y)                     # 省略标签 = 碳
    m.atom('o', x, y, 'O')                # 杂原子/官能团文字
    m.bond('a','o', order=2)
    m.ring('r', cx, cy)                   # 苯环：生成 r0..r5 六个顶点（r0 在正上方）
    m.chain('r3', [(-30, None, 1), (30, 'O', 1)])   # 从 r3 出发，依次 (键的数学角度, 标签, 键级)
    m.render()
    """

    def __init__(self, s, bond=46, size=20, sw=1.8):
        self.s, self.b, self.size, self.sw = s, bond, size, sw
        self.atoms = {}
        self.bonds = []
        self.centers = {}

    def atom(self, name, x, y, label=None):
        self.atoms[name] = [x, y, label]
        return name

    def bond(self, a, b, order=1, kind="plain", inner=None):
        """kind: plain/wedge/dash；inner: 环心坐标，双键副线画在环内侧；order=2 且 inner=None 时居中双线（用于 C=O）。"""
        self.bonds.append((a, b, order, kind, inner))

    def ring(self, name, cx, cy, n=6, r=None, start=90, aromatic=True, label_map=None):
        r = r or self.b
        names = []
        for i in range(n):
            x, y = polar(cx, cy, r, start - 360.0 * i / n)
            nm = "%s%d" % (name, i)
            self.atom(nm, x, y, (label_map or {}).get(i))
            names.append(nm)
        for i in range(n):
            a, b = names[i], names[(i + 1) % n]
            order = 2 if (aromatic and i % 2 == 0) else 1
            self.bond(a, b, order, inner=(cx, cy))
        self.centers[name] = (cx, cy)
        return names

    def chain(self, frm, steps, prefix=None):
        """steps: [(角度, 标签, 键级[, 名称])...] 返回新建原子名列表。"""
        cur = frm
        out = []
        for i, st in enumerate(steps):
            ang, lab, order = st[0], st[1], st[2]
            nm = st[3] if len(st) > 3 else "%s_%s%d" % (frm, prefix or "c", i)
            x, y, _ = self.atoms[cur]
            nx, ny = polar(x, y, self.b, ang)
            self.atom(nm, nx, ny, lab)
            self.bond(cur, nm, order)
            out.append(nm)
            cur = nm
        return out

    def _end(self, a, b, shrink_a, shrink_b):
        xa, ya, _ = self.atoms[a]
        xb, yb, _ = self.atoms[b]
        ux, uy = unit(xb - xa, yb - ya)
        return (xa + ux * shrink_a, ya + uy * shrink_a, xb - ux * shrink_b, yb - uy * shrink_b, ux, uy)

    def render(self):
        s, size = self.s, self.size
        for a, b, order, kind, inner in self.bonds:
            la, lb = self.atoms[a][2], self.atoms[b][2]
            sa = size * (0.40 + 0.22 * max(0, len(la) - 1) if la else 0) if la else 0
            sb = size * (0.40 + 0.22 * max(0, len(lb) - 1) if lb else 0) if lb else 0
            # 多字符标签：以第一个字符为键连接点，缩短量取半个字符宽
            sa = size * 0.62 if la else 0
            sb = size * 0.62 if lb else 0
            x1, y1, x2, y2, ux, uy = self._end(a, b, sa, sb)
            nx, ny = -uy, ux
            d = self.sw * 2.1
            if kind == "wedge":
                s.polygon([(x1, y1), (x2 + nx * 4.5, y2 + ny * 4.5), (x2 - nx * 4.5, y2 - ny * 4.5)], 1, "#000", "#000")
                continue
            if kind == "dash":
                for i in range(1, 7):
                    t = i / 7.0
                    px, py = x1 + (x2 - x1) * t, y1 + (y2 - y1) * t
                    w = 1.2 + 4.0 * t
                    s.line(px - nx * w, py - ny * w, px + nx * w, py + ny * w, 1.3)
                continue
            if order == 1:
                s.line(x1, y1, x2, y2, self.sw)
            elif order == 2 and inner is not None:
                s.line(x1, y1, x2, y2, self.sw)
                mx, my = (x1 + x2) / 2, (y1 + y2) / 2
                sign = 1 if ((inner[0] - mx) * nx + (inner[1] - my) * ny) > 0 else -1
                k = 0.14
                s.line(x1 + (x2 - x1) * k + nx * d * sign, y1 + (y2 - y1) * k + ny * d * sign, x2 - (x2 - x1) * k + nx * d * sign, y2 - (y2 - y1) * k + ny * d * sign, self.sw)
            elif order == 2:
                for sg in (-0.5, 0.5):
                    s.line(x1 + nx * d * sg, y1 + ny * d * sg, x2 + nx * d * sg, y2 + ny * d * sg, self.sw)
            elif order == 3:
                s.line(x1, y1, x2, y2, self.sw)
                for sg in (-1, 1):
                    s.line(x1 + nx * d * sg, y1 + ny * d * sg, x2 + nx * d * sg, y2 + ny * d * sg, self.sw)
        for nm, (x, y, lab) in self.atoms.items():
            if lab:
                s.text(x, y + size * 0.35, lab, size, italic=False)


def benzene_ring(s, cx, cy, r=40, circle=False, sw=1.8):
    """独立的苯环（可选内切圆表示）。返回六个顶点坐标，r0 在正上方，顺时针。"""
    pts = [polar(cx, cy, r, 90 - 60 * i) for i in range(6)]
    s.polygon(pts, sw, "#000", "none")
    if circle:
        s.circle(cx, cy, r * 0.62, 1.4)
    else:
        for i in (0, 2, 4):
            a, b = pts[i], pts[(i + 1) % 6]
            mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
            ux, uy = unit(b[0] - a[0], b[1] - a[1])
            nx, ny = -uy, ux
            sign = 1 if ((cx - mx) * nx + (cy - my) * ny) > 0 else -1
            d = 6.5
            s.line(a[0] + (b[0] - a[0]) * 0.14 + nx * d * sign, a[1] + (b[1] - a[1]) * 0.14 + ny * d * sign,
                   b[0] - (b[0] - a[0]) * 0.14 + nx * d * sign, b[1] - (b[1] - a[1]) * 0.14 + ny * d * sign, 1.6)
    return pts


# ============================ 仪器 =======================================
def liquid_level(s, x1, x2, y, color="#000", opacity=0.10, depth=0, sw=1.2):
    """画液面线（波浪略）；depth>0 时向下填充淡灰。"""
    s.line(x1, y, x2, y, sw)
    if depth:
        s.rect(x1, y, x2 - x1, depth, 0, "none", "#000", opacity=opacity)


def beaker(s, cx, y_bottom, w=110, h=120, liquid=0.55, label=None, size=18, sw=1.8, lip=True):
    x1, x2 = cx - w / 2, cx + w / 2
    top = y_bottom - h
    s.polyline([(x1 - (6 if lip else 0), top), (x1, top), (x1, y_bottom), (x2, y_bottom), (x2, top), (x2 + (6 if lip else 0), top)], sw)
    if liquid:
        ly = y_bottom - h * liquid
        s.rect(x1 + 1, ly, w - 2, y_bottom - ly - 1, 0, "none", "#000", opacity=0.12)
        s.line(x1, ly, x2, ly, 1.3)
    if label:
        s.text(cx, y_bottom + size + 6, label, size, italic=False)
    return (x1, x2, top, y_bottom)


def conical_flask(s, cx, y_bottom, w=120, h=120, neck_w=34, neck_h=36, liquid=0.35, sw=1.8, label=None, size=18):
    top = y_bottom - h
    nt = top + neck_h
    pts = [(cx - neck_w / 2 - 4, top), (cx - neck_w / 2, top), (cx - neck_w / 2, nt), (cx - w / 2, y_bottom), (cx + w / 2, y_bottom), (cx + neck_w / 2, nt), (cx + neck_w / 2, top), (cx + neck_w / 2 + 4, top)]
    s.polyline(pts, sw)
    if liquid:
        ly = y_bottom - (h - neck_h) * liquid
        t = (ly - nt) / (y_bottom - nt)
        xl = cx - (neck_w / 2 + (w / 2 - neck_w / 2) * t)
        s.polygon([(xl, ly), (2 * cx - xl, ly), (cx + w / 2, y_bottom), (cx - w / 2, y_bottom)], 1.2, "#000", "#000", opacity=0.12)
    if label:
        s.text(cx, y_bottom + size + 6, label, size, italic=False)
    return (cx, top)


def round_flask(s, cx, cy, r=52, neck_w=30, neck_h=60, liquid=0.35, sw=1.8, label=None, size=18):
    """圆底烧瓶（瓶颈朝上）。返回瓶口中心 (x,y)。"""
    half = neck_w / 2
    ang = math.degrees(math.asin(half / r))
    a0, a1 = 90 + ang, 90 - ang + 360
    p_start = polar(cx, cy, r, 90 + ang)
    p_end = polar(cx, cy, r, 90 - ang)
    top = p_start[1] - neck_h
    d = "M%s,%s A%s,%s 0 1 0 %s,%s" % (_f(p_start[0]), _f(p_start[1]), _f(r), _f(r), _f(p_end[0]), _f(p_end[1]))
    s.path(d, sw)
    s.line(p_start[0], p_start[1], p_start[0], top, sw)
    s.line(p_end[0], p_end[1], p_end[0], top, sw)
    if liquid:
        ly = cy + r - 2 * r * liquid
        dx = math.sqrt(max(r * r - (ly - cy) ** 2, 0))
        s.add('<path d="M%s,%s A%s,%s 0 %d 0 %s,%s Z" fill="#000" opacity="0.12"/>' % (_f(cx - dx), _f(ly), _f(r), _f(r), 1 if liquid > 0.5 else 0, _f(cx + dx), _f(ly)))
        s.line(cx - dx, ly, cx + dx, ly, 1.2)
    if label:
        s.text(cx, cy + r + size + 8, label, size, italic=False)
    return (cx, top)


def test_tube(s, x, y, w=30, h=130, angle=0, liquid=0.4, sw=1.8, label=None, size=18):
    """试管：口在 (x,y)（口的中心），向下延伸 h；angle>0 表示逆时针倾斜（口朝右上）。"""
    g = []
    r = w / 2
    path = "M%s,%s L%s,%s A%s,%s 0 0 0 %s,%s L%s,%s" % (_f(-r), 0, _f(-r), _f(h - r), _f(r), _f(r), _f(r), _f(h - r), _f(r), 0)
    ly = h - r - (h - r) * liquid
    liq = '<path d="M%s,%s L%s,%s A%s,%s 0 0 0 %s,%s L%s,%s Z" fill="#000" opacity="0.12"/>' % (_f(-r + 0.8), _f(ly), _f(-r + 0.8), _f(h - r), _f(r - 0.8), _f(r - 0.8), _f(r - 0.8), _f(h - r), _f(r - 0.8), _f(ly)) if liquid else ""
    s.add('<g transform="translate(%s %s) rotate(%s)"><path d="%s" fill="#fff" stroke="#000" stroke-width="%s" stroke-linejoin="round"/>%s<line x1="%s" y1="0" x2="%s" y2="0" stroke="#000" stroke-width="%s"/></g>' % (
        _f(x), _f(y), _f(-angle), path, _f(sw), liq, _f(-r - 3), _f(r + 3), _f(sw)))


def alcohol_lamp(s, cx, y_bottom, w=60, h=56, sw=1.8):
    s.polygon([(cx - w / 2, y_bottom), (cx - w / 2 + 6, y_bottom - h * 0.62), (cx + w / 2 - 6, y_bottom - h * 0.62), (cx + w / 2, y_bottom)], sw, "#000", "#fff")
    s.rect(cx - 9, y_bottom - h * 0.62 - 12, 18, 12, 1.6)
    s.path("M%s,%s q-7,-10 0,-20 q7,10 0,20" % (_f(cx), _f(y_bottom - h * 0.62 - 12)), 1.4)


def glass_tube(s, pts, outer=9, inner=5.6):
    """玻璃导管：沿折线画'空心'管（先黑粗线、再白细线）。"""
    d = "M" + " L".join("%s,%s" % (_f(x), _f(y)) for x, y in pts)
    s.add('<path d="%s" fill="none" stroke="#000" stroke-width="%s" stroke-linejoin="round" stroke-linecap="butt"/>' % (d, _f(outer)))
    s.add('<path d="%s" fill="none" stroke="#fff" stroke-width="%s" stroke-linejoin="round" stroke-linecap="butt"/>' % (d, _f(inner)))


def stopper(s, cx, cy, w_top=40, w_bot=30, h=16, sw=1.6):
    s.polygon([(cx - w_top / 2, cy - h / 2), (cx + w_top / 2, cy - h / 2), (cx + w_bot / 2, cy + h / 2), (cx - w_bot / 2, cy + h / 2)], sw, "#000", "#555", opacity=None)


def gas_bottle(s, cx, y_bottom, w=84, h=120, neck_w=36, neck_h=14, liquid=0.0, sw=1.8, label=None, size=18, lid=False, invert=False):
    """集气瓶（广口瓶）。invert=True：瓶口朝下（排水法收集气体时倒置），y_bottom 此时是瓶口所在的 y 坐标的\"瓶底侧\"——
    即倒置后瓶底在上方 y_bottom-h 处，瓶口在 y_bottom。返回瓶口中心。"""
    if invert:
        start = len(s.body)
        r = gas_bottle(s, cx, y_bottom, w, h, neck_w, neck_h, liquid, sw, None, size, lid, False)
        seg = s.body[start:]
        del s.body[start:]
        yc = y_bottom - h / 2
        s.add('<g transform="translate(0 %s) scale(1 -1)">%s</g>' % (_f(2 * yc), "".join(seg)))
        if label:
            s.text(cx, y_bottom + size + 6, label, size, italic=False)
        return (cx, y_bottom)
    top = y_bottom - h
    sh = top + h * 0.18
    s.polyline([(cx - neck_w / 2, top), (cx - neck_w / 2, top + neck_h), (cx - w / 2, sh), (cx - w / 2, y_bottom), (cx + w / 2, y_bottom), (cx + w / 2, sh), (cx + neck_w / 2, top + neck_h), (cx + neck_w / 2, top)], sw)
    s.line(cx - neck_w / 2 - 5, top, cx + neck_w / 2 + 5, top, sw)
    if liquid:
        ly = y_bottom - (y_bottom - sh) * liquid
        s.rect(cx - w / 2 + 1, ly, w - 2, y_bottom - ly - 1, 0, "none", "#000", opacity=0.12)
        s.line(cx - w / 2, ly, cx + w / 2, ly, 1.3)
    if lid:
        s.rect(cx - neck_w / 2 - 8, top - 6, neck_w + 16, 8, 1.6, "#000", "#fff")
    if label:
        s.text(cx, y_bottom + size + 6, label, size, italic=False)
    return (cx, top)


def trough(s, x, y_bottom, w=220, h=70, water=0.6, sw=1.8):
    top = y_bottom - h
    s.polyline([(x, top), (x, y_bottom), (x + w, y_bottom), (x + w, top)], sw)
    ly = y_bottom - h * water
    s.rect(x + 1, ly, w - 2, y_bottom - ly - 1, 0, "none", "#000", opacity=0.12)
    s.line(x, ly, x + w, ly, 1.3)
    return ly


def funnel_filter(s, cx, y_top, w=110, h=80, tube=60, sw=1.8, paper=True):
    """漏斗（含滤纸）：口在 y_top，管在下。"""
    s.polyline([(cx - w / 2, y_top), (cx - 5, y_top + h), (cx - 5, y_top + h + tube)], sw)
    s.polyline([(cx + w / 2, y_top), (cx + 5, y_top + h), (cx + 5, y_top + h + tube)], sw)
    if paper:
        s.polyline([(cx - w / 2 + 12, y_top + 4), (cx, y_top + h * 0.92), (cx + w / 2 - 12, y_top + 4)], 1.2, dash="4,3")
    s.line(cx - w / 2, y_top, cx + w / 2, y_top, 1.0, "#fff")
    return (cx, y_top + h + tube)


def burette(s, cx, y_top, h=210, w=18, liquid_top=0.25, sw=1.8, label=None, size=18):
    s.polyline([(cx - w / 2, y_top), (cx - w / 2, y_top + h)], sw)
    s.polyline([(cx + w / 2, y_top), (cx + w / 2, y_top + h)], sw)
    s.line(cx - w / 2, y_top, cx + w / 2, y_top, 1.0, "#fff")
    ly = y_top + h * liquid_top
    s.rect(cx - w / 2 + 1, ly, w - 2, y_top + h - ly, 0, "none", "#000", opacity=0.12)
    for i in range(10):
        yy = y_top + 20 + i * (h - 60) / 10
        s.line(cx + w / 2 - (8 if i % 5 == 0 else 5), yy, cx + w / 2, yy, 1.0)
    # 活塞与尖嘴
    s.polygon([(cx - 10, y_top + h), (cx + 10, y_top + h), (cx + 5, y_top + h + 16), (cx - 5, y_top + h + 16)], 1.6, "#000", "#fff")
    s.line(cx, y_top + h + 16, cx, y_top + h + 44, sw)
    s.line(cx - 14, y_top + h + 8, cx + 14, y_top + h + 8, 2.4)


def flask_stand(s, x, y_bottom, h=300, base_w=110, arm_y=None, arm_len=70, sw=3.0):
    """铁架台：底座 + 立杆 + 一根横夹臂。"""
    s.rect(x - base_w / 2, y_bottom - 10, base_w, 10, 1.6, "#000", "#ddd")
    s.line(x - base_w / 2 + 16, y_bottom - 10, x - base_w / 2 + 16, y_bottom - h, sw)
    if arm_y is not None:
        s.line(x - base_w / 2 + 16, arm_y, x - base_w / 2 + 16 + arm_len, arm_y, 2.2)


# ============================ 工艺流程 ===================================
def process_flow(s, steps, x0, y0, box_w=120, box_h=46, gap=56, inputs=None, outputs=None, size=18, in_gap=44, out_gap=44, sw=1.6, in_size=None, start_label=None, end_label=None, line_h=22):
    """主流程一行：steps=['酸溶','氧化','沉铁',...] 方框 + 箭头。
    inputs={idx:[文本,...]}：在第 idx 个方框上方进料（向下箭头）；outputs={idx:[文本]}：下方出料；
    start_label/end_label：最左原料、最右产品（无框文字）。返回各框中心。"""
    in_size = in_size or size - 2
    centers = []
    x = x0
    if start_label:
        s.arrow(x0 - 34, y0 + box_h / 2, x0, y0 + box_h / 2, sw, head=10)
        s.text(x0 - 40, y0 + box_h / 2 + 6, start_label, size, anchor="end", italic=False)
    for i, t in enumerate(steps):
        s.rect(x, y0, box_w, box_h, sw, "#000", "#fff", rx=3)
        parts = t.split("\n")
        for k, ptxt in enumerate(parts):
            s.text(x + box_w / 2, y0 + box_h / 2 + 6 + (k - (len(parts) - 1) / 2) * line_h, ptxt, size, italic=False)
        centers.append((x + box_w / 2, y0 + box_h / 2))
        if i < len(steps) - 1:
            s.arrow(x + box_w, y0 + box_h / 2, x + box_w + gap, y0 + box_h / 2, sw, head=10)
        x += box_w + gap
    last_right = x - gap
    if end_label:
        s.arrow(last_right, y0 + box_h / 2, last_right + gap * 0.9, y0 + box_h / 2, sw, head=10)
        s.text(last_right + gap * 0.9 + 6, y0 + box_h / 2 + 6, end_label, size, anchor="start", italic=False)
    for idx, texts in (inputs or {}).items():
        cx = centers[idx][0]
        for k, t in enumerate(reversed(texts)):
            ty = y0 - in_gap - k * (in_size + 6)
            s.text(cx, ty - 4, t, in_size, italic=False)
        s.arrow(cx, y0 - in_gap + 4, cx, y0, sw, head=10)
    for idx, texts in (outputs or {}).items():
        cx = centers[idx][0]
        s.arrow(cx, y0 + box_h, cx, y0 + box_h + out_gap - 8, sw, head=10)
        for k, t in enumerate(texts):
            s.text(cx, y0 + box_h + out_gap + 14 + k * (in_size + 6), t, in_size, italic=False)
    return centers


# ============================ 能量图 =====================================
def energy_profile(s, left, top, w, h, levels, labels=None, ts=None, dH=True, ylabel="能量", xlabel="反应过程", size=18, ea_label=None):
    """反应能量图。levels=[反应物能量, 产物能量]，0~1 相对高度；ts=过渡态相对高度（None 则无峰）。
    labels=(反应物文字, 产物文字)。"""
    s.arrow(left, top + h, left, top - 10, 1.8, head=11)
    s.arrow(left, top + h, left + w + 16, top + h, 1.8, head=11)
    s.text(left - 10, top - 18, ylabel, size, anchor="middle", italic=False)
    s.text(left + w + 10, top + h + 28, xlabel, size, anchor="end", italic=False)
    yr = top + h * (1 - levels[0])
    yp = top + h * (1 - levels[1])
    x1, x2 = left + w * 0.12, left + w * 0.88
    seg = w * 0.22
    s.line(x1, yr, x1 + seg, yr, 2.2)
    s.line(x2 - seg, yp, x2, yp, 2.2)
    if ts is not None:
        yt = top + h * (1 - ts)
        xm = (x1 + seg + x2 - seg) / 2
        s.path("M%s,%s C%s,%s %s,%s %s,%s S%s,%s %s,%s" % (_f(x1 + seg), _f(yr), _f(xm - w * 0.12), _f(yr), _f(xm - w * 0.12), _f(yt), _f(xm), _f(yt), _f(xm + w * 0.12), _f(yp), _f(x2 - seg), _f(yp)), 1.8)
        if ea_label:
            s.arrow(x1 + seg - 6, yr, x1 + seg - 6, yt, 1.4, head=9)
            s.text(x1 + seg - 14, (yr + yt) / 2 + 6, ea_label, size - 1, anchor="end")
    else:
        s.line(x1 + seg, yr, x2 - seg, yp, 1.8)
    if labels:
        s.text(x1 + seg / 2, yr + size + 8, labels[0], size, italic=False)
        s.text(x2 - seg / 2, yp + size + 8, labels[1], size, italic=False)
    if dH:
        xx = x2 + 6
        s.line(x2 - seg, yr, xx + 8, yr, 1.0, "#000", "5,4")
        s.arrow(xx + 8, yr, xx + 8, yp, 1.5, head=9)
        s.text(xx + 14, (yr + yp) / 2 + 6, "ΔH", size, anchor="start")


# ============================ 晶胞 =======================================
def cube_cell(s3, atoms, size=20, r=9, label_offsets=None, hidden=True):
    """立方晶胞：在 Solid3D 上画单位立方体 + 原子。
    atoms=[(x,y,z,fill,label)]，坐标 0~L（单位立方体边长 L=s3 的 unit 决定，坐标用 0~1）。"""
    pts = {"A": (0, 0, 0), "B": (1, 0, 0), "C": (1, 1, 0), "D": (0, 1, 0), "E": (0, 0, 1), "F": (1, 0, 1), "G": (1, 1, 1), "H": (0, 1, 1)}
    for k, v in pts.items():
        s3.v(k, *v)
    for a, b in [("A", "B"), ("B", "F"), ("F", "E"), ("E", "A"), ("F", "G"), ("G", "H"), ("H", "E"), ("B", "C"), ("C", "G")]:
        s3.edge(a, b)
    for a, b in [("A", "D"), ("D", "C"), ("D", "H")]:
        s3.edge(a, b, hidden=hidden)
    for (x, y, z, fill, lab) in atoms:
        px, py = s3.pt(x, y, z)
        s3.s.circle(px, py, r, 1.4, "#000", fill)
        if lab:
            s3.s.text(px, py + size * 0.33, lab, size * 0.7, italic=False, color="#fff" if fill in ("#000", "#333", "black") else "#000")


# ============================ 电化学装置 =================================
def galvanic_cell(s, x, y, left="Zn", right="Cu", left_sol="ZnSO₄溶液", right_sol="CuSO₄溶液", w=130, h=120, gap=70, salt_bridge=True, load="A", size=18):
    """双液原电池：两只烧杯 + 盐桥 + 外电路（电流计/用电器）。(x,y)=左烧杯底部中心。"""
    xl, xr = x, x + w + gap
    b1 = beaker(s, xl, y, w, h, 0.62)
    b2 = beaker(s, xr, y, w, h, 0.62)
    top = y - h
    ly = y - h * 0.62
    for cx, name, side in ((xl, left, -1), (xr, right, 1)):
        s.rect(cx - 9, top - 60, 18, 60 + h * 0.5, 1.4, "#000", "#eee")
        s.text(cx + side * 18, ly - 8, name, size, italic=False, anchor="end" if side < 0 else "start")
    s.text(xl, y + size + 8, left_sol, size - 3, italic=False)
    s.text(xr, y + size + 8, right_sol, size - 3, italic=False)
    if salt_bridge:
        bx1, bx2 = xl + w / 2 - 20, xr - w / 2 + 20
        d = "M%s,%s L%s,%s L%s,%s L%s,%s" % (_f(bx1), _f(ly + 28), _f(bx1), _f(top - 24), _f(bx2), _f(top - 24), _f(bx2), _f(ly + 28))
        s.add('<path d="%s" fill="none" stroke="#000" stroke-width="9" stroke-linejoin="round"/>' % d)
        s.add('<path d="%s" fill="none" stroke="#fff" stroke-width="5.6" stroke-linejoin="round"/>' % d)
        s.text((bx1 + bx2) / 2, top - 32, "盐桥", size - 2, italic=False)
    ytop = top - 90
    s.polyline([(xl, top - 60), (xl, ytop), (xr, ytop), (xr, top - 60)], 1.6)
    s.circle((xl + xr) / 2, ytop, 17, 1.6, "#000", "#fff")
    s.text((xl + xr) / 2, ytop + size * 0.35, load, size, italic=False)
    return (xl, xr, ytop)


def electrolytic_cell(s, cx, y_bottom, w=210, h=130, anode_label="石墨", cathode_label="石墨", sol_label="CuCl₂溶液", source_y=None, size=18):
    """电解池：一只烧杯 + 两个电极 + 直流电源（左极为负：接阴极；右极为正：接阳极）。"""
    beaker(s, cx, y_bottom, w, h, 0.65)
    top = y_bottom - h
    xa, xc = cx + w * 0.22, cx - w * 0.22
    for x in (xa, xc):
        s.rect(x - 8, top - 50, 16, 50 + h * 0.5, 1.4, "#000", "#eee")
    ly = y_bottom - h * 0.65
    s.text(xc - 14, ly - 8, cathode_label, size - 1, italic=False, anchor="end")
    s.text(xa + 14, ly - 8, anode_label, size - 1, italic=False, anchor="start")
    s.text(cx, y_bottom + size + 8, sol_label, size - 2, italic=False)
    yt = top - 100 if source_y is None else source_y
    s.polyline([(xc, top - 50), (xc, yt), (cx - 22, yt)], 1.6)
    s.polyline([(xa, top - 50), (xa, yt), (cx + 22, yt)], 1.6)
    # 电源：左为负(短粗)，右为正(长细)
    s.line(cx - 22, yt - 8, cx - 22, yt + 8, 3.2)
    s.line(cx + 22, yt - 14, cx + 22, yt + 14, 1.6)
    s.text(cx - 34, yt - 12, "−", size + 4, italic=False)
    s.text(cx + 36, yt - 12, "+", size + 4, italic=False)
    return (xc, xa, yt)
