# -*- coding: utf-8 -*-
"""figkit.charts —— 通用统计图：柱状图/折线图/饼图/流程框图/日程表等（生物、政治、英语、数学统计通用）。"""
import math
from .core import Svg, polar, unit, _f
from .math_ import Axes, _nice_step

__all__ = ["bar_chart", "line_chart", "pie_chart", "flow_boxes", "legend", "PATTERNS"]

# 黑白打印友好的填充：灰度 + 斜线/点
PATTERNS = ["#ffffff", "#9a9a9a", "#444444", "#d0d0d0", "#6e6e6e", "#bdbdbd"]


def legend(s, x, y, items, size=17, box=18, gap=10, vertical=False, line=False, markers=None):
    """图例。items=[(名称, 填充色)]；line=True 画线段图例（用于折线图，markers 与之对应）。"""
    cx, cy = x, y
    for i, (name, col) in enumerate(items):
        if line:
            s.line(cx, cy, cx + 30, cy, 2.0, col)
            if markers:
                _marker(s, cx + 15, cy, markers[i % len(markers)], col)
            s.text(cx + 38, cy + size * 0.35, name, size, anchor="start", italic=False)
            w = 38 + size * len(name) * 0.95
        else:
            s.rect(cx, cy - box / 2, box, box * 0.8, 1.2, "#000", col)
            s.text(cx + box + 8, cy + size * 0.33, name, size, anchor="start", italic=False)
            w = box + 8 + size * len(name) * 0.95
        if vertical:
            cy += size + gap
        else:
            cx += w + gap + 14


def _marker(s, x, y, kind, color="#000", r=4.5):
    if kind == "o":
        s.circle(x, y, r, 1.6, "#000", "#fff")
    elif kind == "s":
        s.rect(x - r, y - r, 2 * r, 2 * r, 1.6, "#000", "#000")
    elif kind == "^":
        s.polygon([(x, y - r - 1), (x - r - 1, y + r), (x + r + 1, y + r)], 1.6, "#000", "#fff")
    elif kind == "d":
        s.polygon([(x, y - r - 1), (x - r - 1, y), (x, y + r + 1), (x + r + 1, y)], 1.6, "#000", "#000")
    else:
        s.dot(x, y, r - 1, color)


def bar_chart(s, left, top, w, h, categories, series, ymax=None, ylabel="", series_names=None, errors=None,
              stars=None, yticks=None, size=17, colors=None, bar_w=0.62, gap_group=0.5, xlabel=None, legend_at=None, values=False, ymin=0, tick_fmt=None):
    """柱状图（分组）。categories=['对照','处理1',...]；series=[[v...]...]（每个系列一行，长度同 categories）。
    errors 同形状（误差棒）；stars={(系列,类别):'*'} 在柱顶标显著性；返回 Axes。"""
    ns = len(series)
    ymax = ymax or (max(max(r) for r in series) * 1.2)
    ax = Axes(s, left, top, w, h, (0, len(categories)), (ymin, ymax))
    colors = colors or PATTERNS
    s.line(left, top + h, left + w, top + h, 1.8)
    s.arrow(left, top + h, left, top - 12, 1.8, head=11)
    ticks = yticks or Axes._auto_ticks((ymin, ymax), 0)
    for t in ticks:
        py = ax.py(t)
        s.line(left - 5, py, left, py, 1.3)
        s.text(left - 9, py + size * 0.35, (tick_fmt or Axes._fmt)(t), size, anchor="end", italic=False)
    if ylabel:
        s.text(left - 52, top + h / 2, ylabel, size + 1, rotate=-90, italic=False)
    group_w = 1.0
    bw = bar_w / ns
    for ci, cat in enumerate(categories):
        x_center = ci + 0.5
        x_start = x_center - bar_w / 2
        for si in range(ns):
            v = series[si][ci]
            x0 = ax.px(x_start + si * bw)
            x1 = ax.px(x_start + (si + 1) * bw)
            y = ax.py(v)
            s.rect(x0, y, x1 - x0, ax.py(ymin) - y, 1.4, "#000", colors[si % len(colors)])
            cxp = (x0 + x1) / 2
            if errors:
                e = errors[si][ci]
                if e:
                    s.line(cxp, ax.py(v - e), cxp, ax.py(v + e), 1.4)
                    s.line(cxp - 5, ax.py(v + e), cxp + 5, ax.py(v + e), 1.4)
                    s.line(cxp - 5, ax.py(v - e), cxp + 5, ax.py(v - e), 1.4)
            top_y = ax.py(v + (errors[si][ci] if errors and errors[si][ci] else 0))
            if values:
                s.text(cxp, top_y - 6, Axes._fmt(v), size - 2, italic=False)
            if stars and (si, ci) in stars:
                s.text(cxp, top_y - 6, stars[(si, ci)], size + 2, italic=False)
        s.text(ax.px(x_center), top + h + size + 6, cat, size, italic=False)
    if xlabel:
        s.text(left + w / 2, top + h + size * 2 + 14, xlabel, size, italic=False)
    if series_names:
        lx, ly = legend_at or (left + 8, top - 18)
        legend(s, lx, ly, [(n, colors[i % len(colors)]) for i, n in enumerate(series_names)], size - 1, vertical=False)
    return ax


def line_chart(s, left, top, w, h, xs, series, xlim=None, ylim=None, series_names=None, markers=("o", "s", "^", "d"), xlabel="", ylabel="",
               xticks=None, yticks=None, size=17, errors=None, colors=None, dashes=None, legend_at=None, xtick_labels=None, smooth=False):
    """折线图。xs 为 x 值；series=[[y...]...]；dashes=[None,'6,4',...]。返回 Axes。"""
    xlim = xlim or (min(xs) - (max(xs) - min(xs)) * 0.04, max(xs) + (max(xs) - min(xs)) * 0.04)
    ymax = max(max(r) for r in series)
    ymin = min(0, min(min(r) for r in series))
    ylim = ylim or (ymin, ymax * 1.15)
    ax = Axes(s, left, top, w, h, xlim, ylim)
    ax.draw_axes(xlabel=xlabel, ylabel=ylabel, xticks=xticks if xticks is not None else list(xs), yticks=yticks, box=False, cross=(xlim[0], ylim[0]), show_origin_label=False,
                 xtick_labels=xtick_labels, tick_size=size - 1, label_size=size + 1,
                 xlabel_pos=(left + w / 2, top + h + size * 2 + 12), xlabel_anchor="middle")
    colors = colors or ["#000"] * len(series)
    for i, ys in enumerate(series):
        pts = list(zip(xs, ys))
        s.polyline([ax.P(x, y) for x, y in pts], 2.0, colors[i % len(colors)], (dashes or [None] * 9)[i % len(dashes or [None] * 9)])
        for j, (x, y) in enumerate(pts):
            _marker(s, ax.px(x), ax.py(y), markers[i % len(markers)], colors[i % len(colors)])
            if errors:
                e = errors[i][j]
                if e:
                    s.line(ax.px(x), ax.py(y - e), ax.px(x), ax.py(y + e), 1.3)
                    s.line(ax.px(x) - 4, ax.py(y + e), ax.px(x) + 4, ax.py(y + e), 1.3)
                    s.line(ax.px(x) - 4, ax.py(y - e), ax.px(x) + 4, ax.py(y - e), 1.3)
    if series_names:
        lx, ly = legend_at or (left + 8, top - 18)
        legend(s, lx, ly, [(n, colors[i % len(colors)]) for i, n in enumerate(series_names)], size - 1, vertical=False, line=True, markers=markers)
    return ax


def pie_chart(s, cx, cy, r, values, labels, size=17, start=90, fills=None, show_pct=True):
    tot = float(sum(values))
    fills = fills or PATTERNS
    a = start
    for i, v in enumerate(values):
        da = 360.0 * v / tot
        p0, p1 = polar(cx, cy, r, a), polar(cx, cy, r, a - da)
        large = 1 if da > 180 else 0
        s.add('<path d="M%s,%s L%s,%s A%s,%s 0 %d 1 %s,%s Z" fill="%s" stroke="#000" stroke-width="1.4"/>' % (_f(cx), _f(cy), _f(p0[0]), _f(p0[1]), _f(r), _f(r), large, _f(p1[0]), _f(p1[1]), fills[i % len(fills)]))
        mid = a - da / 2
        lx, ly = polar(cx, cy, r + 26, mid)
        txt = labels[i] + ("  %.0f%%" % (100 * v / tot) if show_pct else "")
        s.text(lx, ly + size * 0.3, txt, size, anchor="middle", italic=False)
        a -= da


def flow_boxes(s, nodes, edges, size=17, sw=1.6, rx=4, pad=14, dash_edges=()):
    """通用流程/关系框图。nodes={id:(cx,cy,w,h,'文字')}；edges=[(from,to[,label])]，自动连接最近的边中点。
    shape 可用 id 前缀：'o:' 椭圆，其余矩形。"""
    for nid, (cx, cy, w, h, txt) in nodes.items():
        if nid.startswith("o:"):
            s.ellipse(cx, cy, w / 2, h / 2, sw, "#000", "#fff")
        else:
            s.rect(cx - w / 2, cy - h / 2, w, h, sw, "#000", "#fff", rx=rx)
        parts = txt.split("\n")
        for k, ptxt in enumerate(parts):
            s.text(cx, cy + size * 0.33 + (k - (len(parts) - 1) / 2) * (size + 4), ptxt, size, italic=False)

    def anchor(a, b):
        ax, ay, aw, ah, _ = nodes[a]
        bx, by, bw, bh, _ = nodes[b]
        dx, dy = bx - ax, by - ay
        if abs(dx) * ah > abs(dy) * aw:
            sx = 1 if dx > 0 else -1
            return (ax + sx * aw / 2, ay), (bx - sx * bw / 2, by)
        sy = 1 if dy > 0 else -1
        return (ax, ay + sy * ah / 2), (bx, by - sy * bh / 2)

    for e in edges:
        a, b = e[0], e[1]
        p, q = anchor(a, b)
        s.arrow(p[0], p[1], q[0], q[1], sw, head=10, dash="6,4" if (a, b) in dash_edges else None)
        if len(e) > 2 and e[2]:
            s.text((p[0] + q[0]) / 2 + 8, (p[1] + q[1]) / 2 - 6, e[2], size - 2, italic=False, anchor="start")
