# -*- coding: utf-8 -*-
"""figkit：命题者说 Skill 的试题配图工具箱（纯 Python，零依赖）。
用法：  import sys; sys.path.insert(0, '<skill>/scripts');  from figkit import *
"""
from .core import Svg, polar, unit, lerp, rich, SERIF, SANS
from .math_ import Axes, Solid3D, label_vertices, polygon_labeled, midpoint, foot_of_perpendicular, mark_equal
try:
    from .physics import *   # noqa
except ImportError:
    pass
try:
    from .chem import *      # noqa
except ImportError:
    pass
try:
    from .bio import *       # noqa
except ImportError:
    pass
try:
    from .charts import *    # noqa
except ImportError:
    pass
