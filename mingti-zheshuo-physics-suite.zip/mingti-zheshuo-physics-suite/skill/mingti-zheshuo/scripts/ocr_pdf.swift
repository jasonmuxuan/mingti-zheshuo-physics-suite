import Foundation
import PDFKit
import Vision
import AppKit

// usage: ocr <pdf> <outdir> [start end] (1-based inclusive)
let args = CommandLine.arguments
let pdfPath = args[1], outDir = args[2]
guard let doc = PDFDocument(url: URL(fileURLWithPath: pdfPath)) else { print("open fail"); exit(1) }
let n = doc.pageCount
let s = args.count > 3 ? Int(args[3])! : 1
let e = args.count > 4 ? min(Int(args[4])!, n) : n
try? FileManager.default.createDirectory(atPath: outDir, withIntermediateDirectories: true)
for i in s...e {
    let outFile = "\(outDir)/p\(String(format: "%03d", i)).txt"
    if FileManager.default.fileExists(atPath: outFile) { continue }
    autoreleasepool {
        guard let page = doc.page(at: i-1) else { return }
        let b = page.bounds(for: .mediaBox)
        let scale: CGFloat = 3.0
        let w = Int(b.width*scale), h = Int(b.height*scale)
        let cs = CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
        ctx.setFillColor(NSColor.white.cgColor); ctx.fill(CGRect(x:0,y:0,width:w,height:h))
        ctx.scaleBy(x: scale, y: scale)
        page.draw(with: .mediaBox, to: ctx)
        guard let img = ctx.makeImage() else { return }
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.recognitionLanguages = ["zh-Hans","en-US"]
        req.usesLanguageCorrection = true
        let handler = VNImageRequestHandler(cgImage: img, options: [:])
        try? handler.perform([req])
        var items: [(CGRect,String)] = []
        for o in (req.results ?? []) { if let c = o.topCandidates(1).first { items.append((o.boundingBox, c.string)) } }
        // sort top-to-bottom, then left-to-right (Vision origin bottom-left)
        items.sort { a, b in
            if abs(a.0.midY - b.0.midY) > 0.008 { return a.0.midY > b.0.midY }
            return a.0.minX < b.0.minX
        }
        var out = ""
        var lastY: CGFloat = -1
        for (r, t) in items {
            if lastY >= 0 && abs(r.midY - lastY) <= 0.008 { out += " " + t } else { out += (out.isEmpty ? "" : "\n") + t }
            lastY = r.midY
        }
        try? out.write(toFile: outFile, atomically: true, encoding: .utf8)
    }
}
print("done \(pdfPath) \(s)-\(e)")
