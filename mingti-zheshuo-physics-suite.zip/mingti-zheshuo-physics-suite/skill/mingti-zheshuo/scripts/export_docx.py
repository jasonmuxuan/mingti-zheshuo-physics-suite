#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HTML → Word(.docx)。内联 SVG 会先用 Chrome 渲染成 PNG 再交给 pandoc，所以图能进 Word。
用法：python3 export_docx.py exam.html [out.docx]
依赖：pandoc（brew install pandoc）+ Chrome/Edge（render_svg.py 同款）。
注意：pandoc 不保留复杂 CSS 版式；Word 中请按需再调字体/页边距。需要精确版式请用 PDF（render_svg.py page.html out.pdf）。
"""
import os, re, subprocess, sys, tempfile, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from render_svg import find_browser  # noqa


def render_png(svg_text, png_path, scale=2):
    m = re.search(r'width="([\d.]+)"[^>]*height="([\d.]+)"', svg_text)
    w, h = (int(float(m.group(1))), int(float(m.group(2)))) if m else (800, 600)
    if "xmlns=" not in svg_text[:200]:
        svg_text = svg_text.replace("<svg ", '<svg xmlns="http://www.w3.org/2000/svg" ', 1)
    svg_path = png_path[:-4] + ".svg"
    # style="max-width..." 可能含 width:100%，去掉以免渲染尺寸异常
    svg_text = re.sub(r'style="max-width:[^"]*"', "", svg_text)
    with open(svg_path, "w", encoding="utf-8") as fh:
        fh.write(svg_text)
    cmd = [find_browser(), "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-sandbox", "--default-background-color=FFFFFFFF",
           "--force-device-scale-factor=%s" % scale, "--screenshot=" + png_path, "--window-size=%d,%d" % (w, h), "file://" + svg_path]
    subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    return os.path.exists(png_path)


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    src = os.path.abspath(sys.argv[1])
    out = os.path.abspath(sys.argv[2]) if len(sys.argv) > 2 else os.path.splitext(src)[0] + ".docx"
    if not shutil.which("pandoc"):
        raise SystemExit("未找到 pandoc。可改用 PDF：python3 render_svg.py %s out.pdf" % src)
    html = open(src, encoding="utf-8").read()
    html = re.sub(r"<style.*?</style>", "", html, flags=re.S)
    tmp = tempfile.mkdtemp(prefix="docx_")
    n = [0]

    def sub(m):
        n[0] += 1
        png = os.path.join(tmp, "fig%02d.png" % n[0])
        ok = render_png(m.group(0), png)
        return '<img src="%s" />' % png if ok else ""
    html = re.sub(r"<svg\b.*?</svg>", sub, html, flags=re.S)
    tmp_html = os.path.join(tmp, "in.html")
    open(tmp_html, "w", encoding="utf-8").write(html)
    r = subprocess.run(["pandoc", tmp_html, "-f", "html", "-t", "docx", "-o", out, "--resource-path=" + tmp], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if r.returncode != 0:
        sys.stderr.write(r.stderr.decode("utf-8", "ignore"))
        raise SystemExit("pandoc 失败")
    print(out, "（含 %d 张图）" % n[0])


if __name__ == "__main__":
    main()
