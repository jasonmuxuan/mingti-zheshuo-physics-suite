#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""命题蓝图（双向细目表）自检。
输入：JSON 文件
{
  "subject": "物理", "total": 100, "minutes": 90,
  "difficulty_target": {"基础": 0.5, "中等": 0.35, "难": 0.15},     # 可选，按分值占比
  "items": [
    {"no": 1, "type": "选择", "score": 3, "topic": "共点力平衡", "level": "基础", "ability": "A1", "answer": "B", "figure": true},
    {"no": "15(1)", "type": "实验", "score": 4, ...}
  ]
}
检查：总分、各题型小计、难度占比、选择题答案分布、缺失字段、同一 topic 重复、图题清单。
用法：python3 blueprint_check.py blueprint.json
"""
import json, sys, collections


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    bp = json.load(open(sys.argv[1], encoding="utf-8"))
    items = bp["items"]
    warn, ok = [], []
    tot = sum(float(i.get("score", 0)) for i in items)
    if bp.get("total") is not None:
        (ok if abs(tot - bp["total"]) < 1e-6 else warn).append("总分 %.1f（目标 %s）" % (tot, bp["total"]))
    by_type = collections.OrderedDict()
    for i in items:
        by_type[i.get("type", "?")] = by_type.get(i.get("type", "?"), 0) + float(i.get("score", 0))
    print("题型小计：", dict(by_type))
    lv = collections.Counter()
    for i in items:
        lv[i.get("level", "?")] += float(i.get("score", 0))
    print("难度分值占比：", {k: "%.0f%%" % (100 * v / tot) for k, v in lv.items()} if tot else lv)
    tgt = bp.get("difficulty_target")
    if tgt and tot:
        for k, v in tgt.items():
            real = lv.get(k, 0) / tot
            (ok if abs(real - v) <= 0.06 else warn).append("难度[%s] 实际 %.0f%% vs 目标 %.0f%%" % (k, real * 100, v * 100))
    ans = [i.get("answer") for i in items if i.get("type", "").startswith("选择") and i.get("answer")]
    if ans:
        cnt = collections.Counter("".join(str(a) for a in ans))
        print("选择题答案字母分布：", dict(sorted(cnt.items())))
        if max(cnt.values()) - min(cnt.values()) > max(2, len(ans) // 3):
            warn.append("选择题答案分布不均衡：%s" % dict(cnt))
        run = 1
        for a, b in zip(ans, ans[1:]):
            run = run + 1 if a == b else 1
            if run >= 4:
                warn.append("选择题连续 4 题以上答案相同（%s）" % a)
                break
    need = ["no", "type", "score", "topic", "level"]
    for i in items:
        miss = [k for k in need if k not in i]
        if miss:
            warn.append("第 %s 题缺字段：%s" % (i.get("no", "?"), "、".join(miss)))
    dup = [k for k, v in collections.Counter(i.get("topic") for i in items).items() if k and v > 1]
    if dup:
        print("提示：以下 topic 出现多次（若非有意做“交叉确认”请调整）：", dup)
    figs = [str(i["no"]) for i in items if i.get("figure")]
    if figs:
        print("需配图的题：", "、".join(figs))
    print("\n✔ " + "\n✔ ".join(ok) if ok else "")
    if warn:
        print("\n⚠ " + "\n⚠ ".join(warn))
        sys.exit(1)
    print("\n蓝图自检通过。")


if __name__ == "__main__":
    main()
