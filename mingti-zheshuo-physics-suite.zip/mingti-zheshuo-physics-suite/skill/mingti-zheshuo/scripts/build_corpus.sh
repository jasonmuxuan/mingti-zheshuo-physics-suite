#!/bin/bash
# 把扫描版 PDF（如六本《命题者说》）OCR 成逐页文字并合并，便于 grep 检索。仅 macOS（调用系统 Vision，免安装、中文效果好）。
# 用法：bash build_corpus.sh <书.pdf> <输出目录> [起始页 结束页]
#   生成：<输出目录>/p001.txt …（逐页）与 <输出目录>/ALL.txt（带"【PDF第NNN页】"页标记）
# 速度：约 0.7–1 秒/页；170–200 页的一本书约 3 分钟。
# 说明：OCR 对数学公式/化学式有错字，引用公式务必回看原 PDF 页面图像。
set -e
PDF="$1"; OUT="$2"; S="$3"; E="$4"
[ -z "$PDF" ] || [ -z "$OUT" ] && { sed -n 2,8p "$0"; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"
BIN="$HERE/.ocr_pdf_bin"
if [ ! -x "$BIN" ] || [ "$HERE/ocr_pdf.swift" -nt "$BIN" ]; then
  echo "编译 OCR 工具…"; swiftc -O "$HERE/ocr_pdf.swift" -o "$BIN"
fi
mkdir -p "$OUT"
"$BIN" "$PDF" "$OUT" $S $E
: > "$OUT/ALL.txt"
for f in "$OUT"/p*.txt; do n=$(basename "$f" .txt); echo "【PDF第${n#p}页】" >> "$OUT/ALL.txt"; cat "$f" >> "$OUT/ALL.txt"; echo >> "$OUT/ALL.txt"; done
echo "完成：$OUT/ALL.txt"
