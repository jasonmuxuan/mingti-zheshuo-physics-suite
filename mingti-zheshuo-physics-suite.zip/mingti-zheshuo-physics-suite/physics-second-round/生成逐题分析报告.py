# -*- coding: utf-8 -*-
"""为《高三物理二轮模拟卷》生成逐题“命题者说”视角分析报告。"""
import os, re, sys, json, math
from collections import Counter, defaultdict
HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = "/Users/xuanhuijing/.tikuagent/agent/skills/mingti-zheshuo"
sys.path.insert(0, os.path.join(SKILL, "scripts"))
from htmlkit import CSS_ANALYSIS, p, h3, ul, callout, table, esc
from 报告补充数据 import OPTIONS, SUBQUESTIONS, LINKS

EXAM = os.path.join(HERE, "高三物理二轮模拟卷.html")
exam_html = open(EXAM, encoding="utf-8").read()
svg_list = re.findall(r'<svg\b.*?</svg>', exam_html, re.S)
figmap = {1:0,2:1,3:2,5:3,7:4,8:5,9:6,10:7,11:8,12:9,13:10,14:11,15:12,16:13,17:14,18:15,19:16,20:17}
blueprint = json.load(open(os.path.join(HERE, '命题蓝图.json'), encoding='utf-8'))

def extract_questions(source):
    """从学生卷按嵌套 div 边界提取题面，保留题图、选项、表格和小问。"""
    blocks = []
    for match in re.finditer(r'<div class="q">', source):
        depth = 0
        for tag in re.finditer(r'</?div\b[^>]*>', source[match.start():], re.I):
            depth += -1 if tag.group().startswith('</') else 1
            if depth == 0:
                blocks.append(source[match.start():match.start()+tag.end()])
                break
    if len(blocks) != len(blueprint['items']):
        raise ValueError('学生卷题目数量与蓝图不一致：%d' % len(blocks))
    return blocks

questions = extract_questions(exam_html)

# 下面的“命题设计/出题思路”均为根据成题作出的合理重建，不是官方命题说明；无真实作答数据。
D = [
(1,"v–t图像中的斜率、面积与符号","B","基础｜A1 观察记忆","运动与相互作用；科学思维（表征转换）",
 "<b>学习探索类、基本层面</b>情境。图像把匀加速、匀速、匀减速三段过程置于同一坐标系；四个选项分别落在斜率、面积、平均速度和加速度方向上。图像是唯一关键信息，数据设置为整值，难点不在运算。",
 "分段读图：0～2 s 的斜率为 2 m/s²；0～5 s 的位移为三角形面积 4 m 加长方形面积 12 m，合为 16 m；0～6 s 位移为 18 m，平均速度为 3 m/s；5～6 s 加速度为 −4 m/s²，方向与前段相反。因此选 B。",
 "本题可能对应“从图像获取信息”的要求，主要测 A1，并以面积意义向 B1 过渡。A 干扰“把速度变化量当加速度”；C 干扰“平均速度未用总位移除总时间”；D 干扰“只看加速度大小、不看符号”。",
 "未提供真实作答数据。可能误区是把 v–t 图线的高度当位移，或把图线与横轴围成的面积漏算为一个三角形。检查办法：每次先在图旁写“斜率→a，面积→x”。",
 "把三段图线拆成“斜率卡、面积卡、符号卡”，要求学生每段都写出 a 与 Δx；再把末段改为速度从 4 m/s 增至 6 m/s，辨析加速度大小与方向。",
 "合理重建：先用分段图像建立低门槛入口，再让四个选项分别承担四种读图动作。陷阱是<b>图像量错配</b>：诱因是图线直观形状强；避坑是先标明纵轴物理量和所求量，再决定用斜率还是面积。"),
(2,"竖直墙面静摩擦力","C","基础｜B1 分析推理","物理观念（相互作用）；科学思维（受力分析）",
 "<b>生活实践类、基本层面</b>情境。墙、推力、重力和“保持静止”构成完整的平衡模型；图中刻意不画摩擦力，要求学生自主补全受力。",
 "物块静止，竖直方向合力为零；重力向下，墙的静摩擦力只能向上，且 f=mg。增大水平推力只增大最大静摩擦力上限，不改变平衡所需的实际摩擦力。因此选 C。",
 "主要测 B1：由平衡状态建立受力关系。A 指向把摩擦力误认为总是“反向于推力”；B 混同静摩擦力与最大静摩擦力；D 混同摩擦力的实际值和最大值。",
 "可能错误是未区分“实际静摩擦力”与“最大静摩擦力”，直接写 f=μN；另一误区是把摩擦力方向判为水平。检查时应问：若没有摩擦，物块相对墙的运动趋势是什么？",
 "训练“对象—状态—受力—方程”四步：先画重力，再根据相对运动趋势补摩擦力。变式：逐渐减小 F，追问何时开始下滑；再给 μ，要求写出保持静止的 F 的范围。",
 "合理重建：用简单图形压缩文字信息，把诊断点放在摩擦力的性质上。陷阱是<b>套用 f=μN</b>；避坑是先判静/滑，再判实际摩擦力由谁决定。"),
(3,"平抛运动的分解模型","A","基础｜B1 分析推理","物理观念（运动）；科学思维（模型建构）",
 "<b>学习探索类、基本层面</b>情境。水平抛射、给 h、v₀、g，问题只问水平位移，促使学生识别水平与竖直运动的独立性。",
 "竖直方向 h=½gt²，得 t=√(2h/g)；水平方向 x=v₀t，所以 x=v₀√(2h/g)，选 A。",
 "主要测 B1 的模型调用。B、C 是量纲或关系式拼接造成的干扰；D 是把落地速度的结构误作水平位移。",
 "可能误区：在水平方向也写加速度 g，或不先求飞行时间。可用量纲检查：位移表达式必须有长度量纲。",
 "先用“同一高度自由落体与水平抛射同时落地”的演示建立独立性；再把设问改为落地速度方向，推动学生建立全过程表征。",
 "合理重建：把 H 与 v₀ 分别放入竖直、水平两个方程，避免复杂轨迹计算。陷阱是<b>分解轴混淆</b>；避坑是列出 x、y 两列运动表再代入。"),
(4,"匀速下坡中的功能关系","D","基础｜A2 概括关联","物理观念（能量）",
 "<b>生活实践类、基本层面</b>情境。没有给具体数据，要求从“匀速”关联合外力功、动能和机械能变化。",
 "匀速意味着 ΔE<sub>k</sub>=0、合外力做功为零；重力做正功，阻力做负功，二者大小相等。因此重力势能减少量等于克服阻力做的功，选 D。",
 "主要测 A2：把牛顿定律的运动状态与功能关系关联。A 把“匀速”误成“不做功”；B 忽略阻力造成机械能转化；C 误解合力功。",
 "可能误区是把“速度不变”误读成“各力不做功”。检查办法：分别问重力、阻力的方向与位移方向夹角。",
 "用能量条形图表示势能减少、内能增加，明确“机械能不守恒不等于能量不守恒”。变式：改为加速下坡，要求比较两种功的大小。",
 "合理重建：不设图、不设数，突出一句“匀速”的信息价值。陷阱是<b>守恒条件遗漏</b>；避坑是先列系统中非保守力是否做功。"),
(5,"竖直圆周最低点的向心力","C","基础｜B1 分析推理","物理观念（运动与相互作用）；科学思维（模型）",
 "<b>生活实践类、基本层面</b>情境。图明确内轨道、最低点和受力方向；题目只考最低点的径向牛顿第二定律。",
 "在最低点向心方向竖直向上，N−mg=mv²/R，故 N=mg+mv²/R，选 C。",
 "主要测 B1：确定向心方向并投影列式。A、B、D 分别对应漏重力、方向取反和把向心力当作额外实在力。",
 "可能误区是另画一个“向心力”，或只写 N=mv²/R。检查：圈出圆心，箭头统一投到指向圆心的方向。",
 "将最低点、最高点、侧点并列作图，比较 N 的表达式；追问“何时最低点恰不脱轨”，让公式回到物理条件。",
 "合理重建：最低点的重力与支持力共线，降低受力投影负担。陷阱是<b>向心力实体化</b>；避坑是只画真实力，向心力写成合力的径向分量。"),
(6,"完全非弹性碰撞中的系统选择","B","中等｜B2 综合应用","科学思维（推理论证）",
 "<b>学习探索类、综合层面</b>情境。题干用“质量相等、光滑、完全非弹性”压缩三个模型条件，考查学生能否为不同物理量选对守恒规律。",
 "碰撞短时内 A、B 系统水平方向外力冲量为零，动量守恒；完全非弹性碰撞中动能不守恒。两球动量变化量大小相等、方向相反。因此选 B。",
 "主要测 B2：区分“系统动量守恒”与“机械能守恒”。A 忽略初动量；C 忽略非弹性条件；D 混淆作用力与动量变化量方向。",
 "可能误区是见“光滑”就判断动能守恒，或忘记系统初动量不为零。检查办法：把碰撞前后总动量写成符号式，不凭口号判断。",
 "安排“弹性—非弹性—爆炸”三类过程对照表，分别填写守恒量；变式：改变两球质量，让学生算碰后速度并判断损失的机械能。",
 "合理重建：用单选筛查三类常见守恒误用。陷阱是<b>守恒条件错配</b>；避坑是每次先写研究对象、过程和外力冲量。"),
(7,"匀强电场中的电势与功","D","基础｜A1 观察记忆","物理观念（相互作用）",
 "<b>学习探索类、基本层面</b>情境。平行板和箭头给定电场方向，P、Q 在同一电场线上，考查电势沿场强方向降低及电场力做功。",
 "电场方向向下，故 φ<sub>P</sub>＞φ<sub>Q</sub>；电子受力方向向上；正电荷从 P 到 Q 沿电场方向移动，电势能减小、电场力做正功。因此选 D。",
 "主要测 A1：从图中读出方向关系。A、B、C 分别诊断电势方向、负电荷受力方向和电势能变化的混淆。",
 "可能误区是机械记“电场方向就是正电荷运动方向”，却不能迁移到电子；检查时分别写 F=qE 和 ΔE<sub>p</sub>=−W<sub>电</sub>。",
 "用同一张图先问正、负试探电荷受力，再问从 P 到 Q 的功与势能，促成符号统一；变式改为粒子由 Q 向 P。",
 "合理重建：让 P、Q 上下排列，减少几何干扰。陷阱是<b>方向链断裂</b>；避坑顺序为 E→F→W→ΔE<sub>p</sub>。"),
(8,"U-I图像中的电源模型","A","中等｜B1 分析推理","科学思维（表征转换）",
 "<b>学习探索类、综合层面</b>情境。用 U-I 图替代直接给 E、r，要求完成图像—方程—物理量的转换。",
 "由 U=E−Ir，纵截距为 E=6 V，斜率绝对值为 r=1 Ω；I=2 A 时 U=4 V，输出功率 UI=8 W；断路时 U=E。因此选 A。",
 "主要测 B1 的表征转换。B 把横截距或斜率误认内阻；C 混淆电源功率与输出功率；D 忽略断路时 I=0。",
 "可能误区是只背“斜率是内阻”却忽略斜率为负，或把 E I 当作输出功率。检查：在图上读出 I=2 A 对应 U 后再算 UI。",
 "让学生从数据表画 U-I 图，再反向由图写出方程；变式加入非理想仪表，讨论图线偏差。",
 "合理重建：截距、斜率、图上定点各测一种行为，形成交叉确认。陷阱是<b>图像参数的物理归属</b>；避坑是先写标准式再一一对应。"),
(9,"带电粒子在匀强磁场中的偏转","B","中等｜B2 综合应用","物理观念（相互作用）；科学思维（模型建构）",
 "<b>学习探索类、综合层面</b>情境。入射速度、磁场方向和轨迹方向三种表征同时给出，要求用洛伦兹力反推电性。",
 "粒子从 O 向右射入，轨迹初始向上弯，所受洛伦兹力向上；由 qv×B 判断粒子带正电。qvB=mv²/r，故 r=mv/(qB)。磁场力不做功，速率不变，选 B。",
 "主要测 B2：方向判断与圆周模型联立。A 为电性反判；C、D 诊断“磁场力做功”误解。",
 "可能误区是右手定则中 B 的“向里”翻转，或只看轨迹弯向不看初速度。检查：先在 O 点单独画 v、B、F 三矢量。",
 "先训练单点三矢量判断，再训练由轨迹判圆心与半径；变式改为负粒子或 B 向外，要求不画完整圆直接判断。",
 "合理重建：轨迹从 O 点开始的切线和弯曲方向足够明确。陷阱是<b>三维方向表征</b>；避坑用右手定则并以“力始终指向圆心”复核。"),
(10,"安培力方向","C","中等｜B1 分析推理","物理观念（相互作用）",
 "<b>科技应用类、基本层面</b>情境。直导线、电流方向、磁场方向均由图给出，任务单一，诊断右手定则是否会用。",
 "电流向右、磁场垂直纸面向里，依据左手定则或 I×B 方向，安培力竖直向上，选 C。",
 "主要测 B1。A、B、D 代表把安培力错误放在电流方向、磁场方向或反向。",
 "可能误区是把右手螺旋定则用于安培力，或未把“×”读成向里。检查时要求在纸面上写出三个两两垂直方向。",
 "把“导线受力、正电荷受力、负电荷受力”放在同一表格对比；变式：交换电流或磁场方向，要求只用反向关系快速判断。",
 "合理重建：只保留一个空间方向任务，避免公式计算干扰。陷阱是<b>定则适用对象混淆</b>；避坑先说清“求安培力，用左手定则”。"),
(11,"楞次定律中的阻碍对象","D","中等｜B2 综合应用","科学思维（推理论证）",
 "<b>学习探索类、综合层面</b>情境。线框“刚进入”磁场，磁通量变化明确；题目要求从磁通量变化推导感应电流方向。",
 "线框内向里的磁通量增大，感应磁场应阻碍该增大，即方向向外；由右手螺旋定则知感应电流逆时针，选 D。",
 "主要测 B2：不是背诵方向，而是完成“原磁通量变化→感应磁场→电流”三步。A 是把阻碍理解成“反向于原磁场”；B 忽略磁通量在变；C 是凭过程想象而非判据。",
 "可能误区是只看外磁场方向、不说“增大还是减小”。检查句式：原磁通量（方向、增减）→感应磁场（方向）→电流。",
 "采用“进入、完全在内、离开”三帧图训练，强调中间帧无磁通量变化；变式改变磁场方向或线框运动方向。",
 "合理重建：选择“刚进入”避免面积变化与 B 变化叠加。陷阱是<b>把阻碍对象错当原磁场</b>；避坑始终补全“阻碍磁通量的变化”。"),
(12,"理想变压器的变比与功率","A","中等｜A2 概括关联","科学态度与责任（能源利用）",
 "<b>生活实践类、综合层面</b>情境。家用交流供电模型引出降压变压器，图中原副线圈和电阻负载构成完整回路。",
 "理想变压器 U₁/U₂=n₁/n₂=5，故 U₂=44 V。降压时 I₂>I₁（有负载）；直流不能形成稳定磁通变化，副边无稳定输出；R 增大使输出、输入功率减小。因此选 A。",
 "主要测 A2：把变比、功率守恒和交流条件关联。B、C、D 分别诊断电流变比、交直流条件和负载变化的误解。",
 "可能误区是只记电压变比，未与功率关系联动；也可能把“变压器”视为任意电源。检查：同时写 U₁/U₂=n₁/n₂、P₁=P₂。",
 "让学生画出“升压/降压”时 U、I 的反向变化表；加入输电线电阻，讨论升压输电减少损耗。",
 "合理重建：变比取5∶1、220 V，结果44 V利于降低算术负担。陷阱是<b>孤立套变比</b>；避坑将变比、功率和交流条件三项一起核对。"),
(13,"弹簧回弹与完全非弹性碰撞","C","难｜B2 综合应用","科学思维（系统与过程）",
 "<b>学习探索类、综合层面</b>情境。一个题干串联“理想弹簧过程”和“完全非弹性碰撞过程”，关键在于不同阶段选不同守恒规律。",
 "轻弹簧和光滑面使 A 回到原长度时速度大小仍为 v₀；碰撞前 A 的动能为½mv₀²，碰后两物块速度为v₀/2，动能为mv₀²/4，损失mv₀²/4。因此选 C。",
 "主要测 B2 的过程切分。A 诊断对弹性势能完全恢复的忽略；B 诊断把弹簧过程的机械能守恒搬到非弹性碰撞；D 诊断动量守恒计算遗漏总质量。",
 "可能误区是整段过程只写一个守恒式，或把“弹簧在前”误认为碰撞时仍影响系统。检查：在时间轴上标出“接触弹簧、脱离弹簧、碰撞瞬间”。",
 "训练多过程题的“每段对象—外力—守恒量”三列表；变式：将碰撞改为弹性碰撞，比较速度与机械能损失。",
 "合理重建：两块质量相等使碰后速度和能量损失简洁，难度集中在模型切换。陷阱是<b>跨过程误用守恒</b>；避坑是一段一段列方程。"),
(14,"B-t图像、感应电动势与焦耳热","B","难｜C1 新知获取","科学思维（证据推理）",
 "<b>科技应用类、综合层面</b>情境。B-t 图使磁场变化率可视化，线框参数 S、R 给定，要求从图线斜率获取感应电动势并联系能量。",
 "0～t₀ 内 |ΔB/Δt|=B₀/t₀，ε=B₀S/t₀，I=ε/R，Q=I²Rt₀=B₀²S²/(Rt₀)。t₀～3t₀ 内 B 不变，无感应电流；3t₀～5t₀ 内 B 减小，仍有感应电流且方向与前段相反。因此选 B。",
 "主要测 C1：从陌生呈现的图像中提取变化率，并迁移到 ε、I、Q。A 把 B 值误当变化率；C 忽略平台段无感应电流；D 忽略减小阶段磁通量仍在变。",
 "可能误区是见 B 非零就判断有感应电流，或把三角形面积用于本题。检查：先在每一时段写 ΔB/Δt，而非写 B。",
 "进行“B-t、Φ-t、ε-t、I-t”四图互译；让学生把上升、平台、下降分段用不同颜色标记。",
 "合理重建：先给单一均匀线框，减小几何变量；难点来自变化率与能量链。陷阱是<b>状态量与变化率混淆</b>；避坑是把楞次定律和法拉第定律的入口都写成“磁通量变化”。"),
(15,"光电门测重力加速度","分问给分","基础｜B1 分析推理","科学探究（证据与解释）",
 "<b>学习探索类、基本层面</b>实验情境。光电门把难直接测的瞬时速度转化为“遮光片长度/遮光时间”，再用匀变速关系连接两门间距离。",
 "v<sub>A</sub>=d/Δt<sub>A</sub>，v<sub>B</sub>=d/Δt<sub>B</sub>；由v<sub>B</sub>²−v<sub>A</sub>²=2gh得 g=[(d/Δt<sub>B</sub>)²−(d/Δt<sub>A</sub>)²]/(2h)。若作纵轴为v<sub>B</sub>²−v<sub>A</sub>²、横轴为h的图，斜率k=2g，故g=k/2；多组作图可减小偶然误差。",
 "主要测 B1 与科学探究的“测量量—间接量—数据处理”链条。第（1）问保基础入口，第（2）问测原始方程，第（3）问测线性化和证据表达。",
 "无真实数据。可能错误包括把 d 写成 h、把遮光时间当飞行时间、漏平方，或把斜率直接当 g。检查表应分列“直接测量量”和“待求量”。",
 "先让学生用单位判断 d/Δt 的物理量；实验讲评中要求注明图像横纵坐标、斜率单位和斜率物理意义。变式：以v²为纵轴、释放点到门的距离为横轴。",
 "合理重建：两门模型减少释放点和初速度的控制难度。陷阱是<b>直接量/间接量混淆</b>；避坑是每写一个公式都写清每个字母从何测得。"),
(16,"伏安法测电源电动势和内阻","分问给分","中等｜B2 综合应用","科学探究（方案、数据处理与交流）",
 "<b>学习探索类、综合层面</b>实验情境。电路、数据表、U-I图像和误差操作共同构成任务链；电表理想化避免仪表内阻带来的额外模型。",
 "闭合前滑动变阻器应接最大阻值；由U=E−Ir，数据落在U=6.0−I的直线上，纵截距E=6.0 V、斜率绝对值r=1.0 Ω。为减小误差，应短时闭合、及时读数等。",
 "主要测 B2：从电路到数据、从数据到图像、从图像到模型参数。第（1）问测操作安全，第（2）（3）问测表征转换，第（4）问测实验规范。",
 "可能误区是滑片置最小造成过大电流；图像纵截距错读为额定电压；把斜率写成E。检查：先写U=E−Ir，再决定截距与斜率。",
 "让学生先预测图线方向和两个截距，再画图；实操时记录“开关接通时间”，讨论电池极化和发热。",
 "合理重建：数据严格共线，初稿重点放在图像解释而非作图散差。陷阱是<b>公式参数与图像参数错配</b>；避坑是标准式与图像点逐一对应。"),
(17,"滑轨—平抛的分段功能模型","分问给分","中等｜B2 综合应用","科学思维（建模与推理）",
 "<b>生活实践类、综合层面</b>情境。轨道下降、水平抛出、实际有阻力三个阶段依次出现，图使H、h与水平位移的物理归属清晰。",
 "（1）光滑段m gH=½mv²，v=5.0 m/s；（2）h=½gt²得t=0.40 s，x=vt=2.0 m；（3）实际x′=1.60 m，v′=x′/t=4.0 m/s，阻力功W<sub>f</sub>=½mv′²−mgH=−0.90 J。",
 "主要测 B2 的分段建模和能量观点。题目三问由理想轨道、平抛时间、加入阻力依次提升，不要求复杂联立。",
 "可能误区是把H与h混用，或在有阻力问仍直接用m gH=½mv′²。检查：每段先标系统初末状态和非保守力。",
 "让学生画“状态点能量图”，用不同颜色标出H（轨道能量差）和h（平抛竖直位移）；变式改为由落点反求轨道段的摩擦功。",
 "合理重建：H=1.25 m、h=0.80 m使v、t、x均为整洁数值。陷阱是<b>高度符号跨过程混用</b>；避坑是按过程分段，不能把全图当成一个守恒过程。"),
(18,"弹簧释放、完全非弹性碰撞与摩擦","分问给分","中等｜B2 综合应用","科学思维（系统与过程）",
 "<b>学习探索类、综合层面</b>情境。三个过程各有唯一主规律：弹簧释放用机械能守恒，碰撞用动量守恒，粗糙面滑行用动能定理。",
 "（1）½kx₀²=½mv²，v=2.0 m/s；（2）mv=(m+m)v′，v′=1.0 m/s；（3）μ(2m)gs=½(2m)v′²，s=0.50 m。",
 "主要测 B2 的模型切换，三问是标准的“原型→变式→全过程”阶梯。参数使每段运算轻，思维重点为系统与规律选择。",
 "可能误区是全程机械能守恒，或摩擦力仍写μmg而遗漏碰后总质量。检查：每问开头明确“研究对象”和“过程起止”。",
 "可让学生完成“过程—系统—守恒/定理—初末状态”表；变式给B不同质量，比较粘连后的速度和滑行距离。",
 "合理重建：把三种规律串联但不在同一问强行联立。陷阱是<b>系统质量遗漏与守恒滥用</b>；避坑是碰后立即把质量更新为2m。"),
(19,"速度选择器与磁偏转","分问给分","中等｜B2 综合应用","物理观念；科学思维（模型建构）",
 "<b>科技应用类、综合层面</b>情境。速度选择器后接磁偏转区，图中E、B方向和轨迹共同给定，体现两种场模型的衔接。",
 "（1）直线通过说明qE=qvB，v=E/B；（2）右区qvB=mv²/r，r=mE/(qB²)；（3）半圆返回边界，r=d/2=0.040 m，q/m=E/(rB²)=2.0×10⁶ C/kg。",
 "主要测 B2：先用复合场平衡获得速度，再迁移到单磁场圆周模型。第（3）问以图形“半圆、d=2r”连接几何和物理。",
 "可能误区是速度选择器中把电场力和磁场力写成同向，或把d误作r。检查：在选择器画两力反向箭头，在右区标出圆心与直径。",
 "对比正、负粒子的可通过条件；把右区磁场方向反转，要求重画轨迹而不重算速度。",
 "合理重建：电场与磁场方向使正粒子受两力恰相反；d=8.0 cm使半径和比荷计算可控。陷阱是<b>复合场/单场模型混用</b>；避坑是用区域边界分开列方程。"),
(20,"非匀强磁场中的电磁感应新情境","分问给分","难｜C2 新知应用","科学思维（迁移创新）；物理观念（能量）",
 "<b>学习探索类、综合层面</b>新情境。题面明确给出 ε=B(x)lv，降低陌生模型的知识门槛；B(x)=B₀(1+x/L)让安培力随位置变化，最后一问要求把瞬时关系积累为总功。",
 "（1）x=0时ε=B₀lv₀，I=B₀lv₀/R；向里磁通量增加，感应电流逆时针，棒中由Q到P。（2）x=L/2时B=3B₀/2，F<sub>A</sub>=B²l²v₀/R=9B₀²l²v₀/(4R)，方向向左，a=9B₀²l²v₀/(4mR)，方向向左。（3）匀速时F<sub>外</sub>=B²l²v₀/R，积分得W=∫₀ᴸF<sub>外</sub>dx=7B₀²l²v₀L/(3R)。",
 "主要测 C2：从题设新信息抽取电动势关系，连接欧姆定律、安培力和功的定义。小问梯度为特例代入→瞬时动力学→变量力做功，难度不靠冗长计算。",
 "可能误区是把B始终取B₀；用恒力公式W=FL且遗漏F随x变；把“磁通量增加”对应的棒中电流方向判反。检查：每一问先写B(x)的具体值或函数，再写下一条规律。",
 "教学上先用匀强场导体棒复习 ε=Blv、F=BIl，再只改变B为B(x)，让学生比较“公式不变、量变为函数”的区别；训练∫F(x)dx与电功—焦耳热的能量核对。",
 "合理重建：先给出新关系而不要求从磁通量定义推导，确保入口可达；最后才要求积分，承担区分度。陷阱是<b>把变量当常量</b>；避坑是把每一个B都标成B(x)，并在全程检查方向与能量去向。")
]

def fig(no):
    if no not in figmap: return ""
    return '<figure class="diagram reportfig">'+svg_list[figmap[no]]+'</figure>'

def module(name, body):
    return '<div class="module"><h3>%s</h3><p>%s</p></div>' % (name, body)

def breakdown(n):
    if n in OPTIONS:
        entries = ''.join('<div class="detail-row"><b>%s</b><span>%s</span></div>' % (letter, esc(content))
                          for letter, content in zip('ABCD', OPTIONS[n]))
        return '<div class="module"><h3>选项逐项分析</h3><p class="muted">错误原因是可能解释；无法唯一推断时只说明物理依据。</p>%s</div>' % entries
    entries = ''.join('<div class="subdetail"><h4>%s</h4><p><b>知识与设计：</b>%s</p><p><b>依据与易错：</b>%s</p><p><b>讲评：</b>%s</p></div>' % tuple(esc(x) for x in row)
                      for row in SUBQUESTIONS[n])
    return '<div class="module"><h3>分小题拆解</h3>%s</div>' % entries

CHART_COLORS = ('#276dcc', '#62a3eb', '#a9c9f1', '#17498d', '#82b2dd', '#c5daf3')

def ring_chart(title, groups, center_label):
    """分值环图直接使用 SVG，图例同时展示题数、分值和分值占比。"""
    total = sum(group[2] for group in groups)
    circumference = 2 * math.pi * 72
    offset = 0.0
    arcs, legends = [], []
    for index, (label, count, score) in enumerate(groups):
        share = score / total if total else 0
        length = circumference * share
        color = CHART_COLORS[index % len(CHART_COLORS)]
        arcs.append(f'<circle cx="100" cy="100" r="72" fill="none" stroke="{color}" stroke-width="25" stroke-dasharray="{length:.5f} {circumference-length:.5f}" stroke-dashoffset="{-offset:.5f}"/>')
        offset += length
        legends.append(f'<li><span class="legend-label"><i style="background:{color}"></i>{esc(label)}</span><span><b>{score} 分</b> · {share:.0%} <small>／{count} 题</small></span></li>')
    description = '；'.join(f'{label}：{score} 分、{count} 题，占总分 {score/total:.0%}' for label,count,score in groups)
    return (f'<section class="chart-card"><h3>{esc(title)}</h3><p class="chart-caption">按分值占比 · 图例同时列出题数</p>'
            f'<div class="chart-layout"><svg class="ring-svg" viewBox="0 0 200 200" role="img" aria-label="{esc(title)}：{esc(description)}">'
            f'<circle cx="100" cy="100" r="72" fill="none" stroke="#edf3fb" stroke-width="25"/>'
            f'<g transform="rotate(-90 100 100)">{"".join(arcs)}</g>'
            f'<text x="100" y="94" text-anchor="middle" class="ring-value">{total}</text>'
            f'<text x="100" y="117" text-anchor="middle" class="ring-label">{esc(center_label)}</text></svg>'
            f'<ul class="chart-legend">{"".join(legends)}</ul></div></section>')

def ability_chart(groups, total):
    """按蓝图代码展示分值；横条的比例基准为全卷总分。"""
    rows = []
    for label, count, score in groups:
        width = 430 * score / total if total else 0
        rows.append(f'<div class="ability-row"><span class="ability-name">{esc(label)}</span>'
                    f'<svg viewBox="0 0 430 16" preserveAspectRatio="none" aria-hidden="true"><rect width="430" height="16" rx="8" fill="#eaf1fa"/><rect width="{width:.3f}" height="16" rx="8" fill="#367bd5"/></svg>'
                    f'<span class="ability-value"><b>{score} 分</b> · {count} 题</span></div>')
    return ('<section class="chart-card ability-card"><h3>预设能力分布</h3>'
            '<p class="chart-caption">横条长度按全卷总分计算；能力为蓝图预设，并非实测水平</p>'
            +''.join(rows)+'</section>')

def statistics():
    items = blueprint['items']
    if sum(x['score'] for x in items) != blueprint['total']:
        raise ValueError('蓝图各题分值之和与总分不一致')
    rows = []
    for label in ('选择', '实验', '计算'):
        group = [x for x in items if x['type'] == label]
        rows.append([label, str(len(group)), '、'.join(str(x['no']) for x in group), str(sum(x['score'] for x in group))+' 分'])
    levels = []
    for level in ('基础', '中等', '难'):
        group = [x for x in items if x['level'] == level]
        score = sum(x['score'] for x in group)
        levels.append([level, str(len(group)), str(score)+' 分', f'{score / blueprint["total"]:.0%}', '、'.join(str(x['no']) for x in group)])
    abilities = defaultdict(lambda: [0, 0])
    for item in items:
        abilities[item['ability']][0] += 1
        abilities[item['ability']][1] += item['score']
    ability_rows = [[esc(k), str(v[0]), str(v[1])+' 分'] for k,v in sorted(abilities.items())]
    type_groups = [(label, sum(x['type'] == label for x in items), sum(x['score'] for x in items if x['type'] == label)) for label in ('选择', '实验', '计算')]
    level_groups = [(label, sum(x['level'] == label for x in items), sum(x['score'] for x in items if x['level'] == label)) for label in ('基础', '中等', '难')]
    ability_groups = [(label, value[0], value[1]) for label,value in sorted(abilities.items())]
    topic_rows = [[str(x['no']), esc(x['topic']), esc(x['level']), str(x['score'])] for x in items]
    return ('<section class="panel" id="overview"><h2>整卷数据与知识分布</h2>'
            '<p class="muted">数据来自随卷命题蓝图；难度和能力为命题预设，不是实测结果。题目按蓝图的主要知识主题逐题列示，跨主题关系见逐题分析。</p>'
            '<div class="chart-grid">'+ring_chart('题型与分值', type_groups, '试卷总分')+ring_chart('预估难度分布', level_groups, '试卷总分')+'</div>'
            +ability_chart(ability_groups, blueprint['total'])+
            '<p class="muted">A1、A2、B1、B2、C1、C2 为本卷蓝图沿用的分类代码，不代表经过实测的能力水平。代码具体定义需由命题方另行提供。</p>'
            '<details class="chart-details"><summary>展开查看题型、难度及能力的统计明细</summary>'
            '<h3>题型与分值明细</h3>'+table(rows,['题型','题数','题号','分值'])+
            '<h3>预估难度明细</h3>'+table(levels,['层级','题数','分值','分值占比','题号'])+
            '<h3>预设能力明细</h3>'+table(ability_rows,['蓝图代码','题数','分值'])+'</details>'
            '<h3>逐题知识索引</h3>'+table(topic_rows,['题号','主要知识主题','预估难度','分值'])+'</section>')

parts=[]
parts.append('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>高三物理二轮模拟卷｜逐题命题分析报告</title><style>'+CSS_ANALYSIS+'''
.chart-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin:22px 0 16px}.chart-card{border:1px solid #dbe8f7;border-radius:14px;background:#fbfdff;padding:19px 20px;break-inside:avoid}.chart-card h3{margin:0;color:#163e70;font-size:17px}.chart-caption{margin:3px 0 14px;color:#768ca6;font-size:12px}.chart-layout{display:grid;grid-template-columns:minmax(115px,155px) minmax(0,1fr);gap:14px;align-items:center}.ring-svg{width:100%;max-width:155px}.ring-value{font:700 30px -apple-system,BlinkMacSystemFont,sans-serif;fill:#163e70}.ring-label{font:12px -apple-system,BlinkMacSystemFont,sans-serif;fill:#7186a0}.chart-legend{list-style:none;padding:0;margin:0}.chart-legend li{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 0;margin:0;border-bottom:1px solid #e8eff8;font-size:12px;white-space:nowrap}.chart-legend li:last-child{border:0}.legend-label{display:flex;align-items:center;gap:7px;color:#45617f}.legend-label i{width:9px;height:9px;border-radius:50%;display:inline-block;flex:none}.chart-legend b{color:#234e83;font-size:13px}.chart-legend small{color:#8194a9}.ability-card{margin:0 0 14px}.ability-row{display:grid;grid-template-columns:34px minmax(80px,1fr) 110px;align-items:center;gap:12px;margin:10px 0;font-size:13px}.ability-name{font-weight:700;color:#345b8a}.ability-row svg{width:100%;height:12px}.ability-value{text-align:right;color:#7186a0;white-space:nowrap}.ability-value b{color:#234e83}.chart-details{margin:20px 0;border:1px solid #dfe9f4;border-radius:9px;padding:10px 15px}.chart-details summary{cursor:pointer;color:#2f65a6;font-weight:700}.chart-details[open] summary{margin-bottom:14px}@media(max-width:750px){.chart-grid{grid-template-columns:1fr}}@media print{.chart-card,.chart-legend i{-webkit-print-color-adjust:exact;print-color-adjust:exact}.chart-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.chart-card{break-inside:avoid}.chart-details:not([open]){display:none}}
.report-meta{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:16px 0}.report-meta div{background:#eef4fc;border-radius:8px;padding:10px 13px;font-size:14px}.qhead{border-bottom:2px solid #345b9e;padding-bottom:9px;margin-bottom:8px}.qhead .ans{margin:0 0 0 12px;padding:2px 10px}.module{border-top:1px solid #dfe7f1;padding-top:5px;margin-top:14px}.module h3{font-size:17px;margin:10px 0 4px}.module p{margin:0}.toc2{columns:2;column-gap:25px;padding-left:22px}.toc2 li{break-inside:avoid}.toc2 a{color:#345b9e;text-decoration:none}.summary td{text-align:left}.original{background:#f4f8fe;border-left:4px solid #5489cf;padding:14px 18px;border-radius:7px;margin:15px 0}.original .q{line-height:1.8}.original .opts{display:grid;grid-template-columns:1fr 1fr;gap:4px 18px}.original .score{float:right;color:#68809c}.original svg{max-width:100%;height:auto}.detail-row{display:grid;grid-template-columns:32px 1fr;gap:10px;border-top:1px solid #e6edf6;padding:8px 0}.detail-row b{color:#2164af}.subdetail{padding:12px 15px;margin:9px 0;border:1px solid #dfe9f4;border-radius:8px;break-inside:avoid}.subdetail h4{margin:0 0 5px;color:#245da0}.subdetail p{margin:4px 0}.knowledge-map{background:#edf5ff;color:#23588c;border-radius:7px;padding:12px 14px;margin-top:10px}.toolbar{position:fixed;right:18px;top:15px;z-index:5;background:#245ea9;color:white;border:0;border-radius:8px;padding:10px 15px;cursor:pointer}@media(max-width:650px){.report-meta{grid-template-columns:1fr}.original .opts{grid-template-columns:1fr}.panel{padding:20px;overflow-x:auto}}@media print{.toolbar{display:none}.toc2{columns:2}.panel{break-inside:auto}.original figure,.detail-row{break-inside:avoid}}'''+'</style></head><body><button class="toolbar" onclick="window.print()">打印 / 导出 PDF</button><main class="wrap">')
parts.append('<header class="hero"><div class="eyebrow">命题者视角 · 物理 · 逐题分析</div><h1>高三物理二轮模拟卷<br>逐题命题分析报告</h1><p>对象：〈2026届高三物理二轮原创模拟卷（力学＋电磁学）〉</p><span class="tag">北京等级考风格</span><span class="tag">100 分 / 90 分钟</span><span class="tag">20 题逐题六模块</span></header>')
parts.append('<section class="panel"><h2>报告说明</h2>'+callout("note","本报告借鉴《命题者说》的“试题解读—思路分析—学生表现—教学改进建议”分析框架，并结合物理试题增加命题设计、出题思路和题目陷阱。题面所显示的命题过程是合理重建，并非官方说明；本卷未经试测，“学生表现”均为可能误区，不是统计事实。")+callout('warn','<b>使用前须审校：</b>第 13 题的初速度与弹簧位置、题述过程不一致；第 16 题电路图中电流表可能被导线短接；第 15 题光电门测速为近似；第 20 题末问现用积分，须确认教学适配性。')+'<div class="report-meta"><div><b>卷面结构</b><br>选择42分｜实验18分｜计算40分</div><div><b>分值口径的难度预估</b><br>基础26%｜中等56%｜难18%</div><div><b>数据边界</b><br>蓝图预设，未提供真实作答</div></div></section>')
parts.append(statistics())
parts.append('<section class="panel"><h2>目录</h2><ol class="toc2">'+''.join('<li><a href="#q%d">第%d题｜%s</a></li>'%(n,n,title) for n,title,*_ in D)+'</ol></section>')
for n,title,ans,ability,literacy,interpret,solution,design,performance,teach,construct in D:
    warning = ''
    if n == 13:
        ans = '待修题后复核（原拟 C）'
        warning = callout('warn','<b>题图与过程冲突：</b>图中弹簧在 A 左侧，A 的初速度却向右；若题述“先压缩弹簧、被弹回后与 B 碰撞”成立，须重新布置初始方向、位置及碰撞过程。下列计算仅说明修正模型后、碰前速度大小为 v₀ 时的条件性结果。')
        solution = '若先修正运动过程，并满足碰撞前速度大小为 v₀、碰撞时弹簧不作用，则动量守恒得共同速度大小 v₀/2，动能损失 ½mv₀²−½(2m)(v₀/2)²=mv₀²/4。原题未经修正，不宜判定唯一答案。'
    if n == 16:
        warning = callout('warn','<b>电路图待修正：</b>图 14 中主导线直接连接电流表两端，电流表可能被旁路；应移除并联短接导线，再核验实际接线。下面的 U–I 参数为根据题给数据与理想模型计算。')
    if n == 15:
        warning = callout('warn','<b>模型近似：</b>d/Δt 是遮光过程的平均速度；作为门处瞬时速度需遮光时间足够短、球足够小等近似条件。本题宜补充近似条件。')
        solution = solution.replace('v<sub>A</sub>=d/', 'v<sub>A</sub>≈d/').replace('v<sub>B</sub>=d/', 'v<sub>B</sub>≈d/').replace('得 g=[', '近似得 g≈[').replace('斜率k=2g，故g=k/2', '斜率k≈2g，故g≈k/2')
    if n == 20:
        warning = callout('note','<b>教学适配：</b>第（3）问为位置相关的变力做功，当前参考解法使用定积分；应结合学校教学进度，考虑补充积分关系或调整设问。')
    if n == 10:
        interpret = interpret.replace('诊断右手定则是否会用', '诊断安培力左手定则是否会用')
    if n == 5:
        design = '主要测 B1：确定向心方向并投影列式。A 误置重力项符号，B 颠倒径向合力方向，D 漏掉重力贡献。'
        teach = '将最低点、最高点、侧点并列作图，比较 N 的表达式；追问最低点的受力如何随速度改变。'
    content = (warning+'<h3>原题与参考信息</h3><div class="original">'+questions[n-1]+'</div>'
               +module('一、试题解读',interpret)+module('二、思路分析',solution)
               +module('三、命题设计（物理）',design)+module('四、学生表现（可能误区）',performance)
               +module('五、教学改进建议',teach)+module('六、出题思路与题目陷阱',construct)
               +breakdown(n)+'<div class="module"><h3>知识点关联</h3><div class="knowledge-map">'+esc(LINKS[n])+'</div></div>')
    parts.append('<section class="panel" id="q%d"><div class="qhead"><h2>第 %d 题｜%s <span class="ans">答案：%s</span></h2><p class="muted">能力定位：%s　｜　素养指向：%s</p></div>%s</section>' % (n,n,title,ans,ability,literacy,content))
parts.append('<section class="panel"><h2>整卷复盘与使用建议</h2>'+ul([
"<b>讲评顺序建议：</b>先按“图像表征（1、8、14）—方向判断（7、9、10、11）—多过程建模（13、17、18）—实验（15、16）—新情境迁移（19、20）”重组讲评，不必完全按题号推进。",
"<b>数据使用建议：</b>若在班级实施，可记录每题得分、选择题选项分布和计算题采分点，分别验证本报告的“可能误区”；不能把本报告中的预判当成真实学情。",
"<b>二次命题建议：</b>对薄弱项可采用“换情境保任务”的锚题复测；对掌握较好学生，可将第14或20题的B(x)关系换成图像或数据表，提升信息提取任务。",
"<b>审校边界：</b>本报告随卷提供的是命题初稿分析。教师使用前仍应复核题目唯一性、配图方向、实验器材适配性、评分尺度和本校复习进度。"
])+'</section><div class="foot">原创模拟卷分析报告｜未经试测｜使用前请教师逐题审校</div></main></body></html>')
out=os.path.join(HERE,"高三物理二轮模拟卷_逐题命题分析报告.html")
open(out,"w",encoding="utf-8").write(''.join(parts))
print(out)
