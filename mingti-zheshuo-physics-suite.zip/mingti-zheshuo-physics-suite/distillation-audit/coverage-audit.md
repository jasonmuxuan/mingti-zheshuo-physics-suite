# 覆盖审计｜阶段 1.5

| 任务 | 关键候选 | 验证结论 | 最终预定去向 | 缺口/限制 |
|---|---|---|---|---|
| T01 物理题预审 | f01/c01/c02/c03/c05/ce01 | verified | cap-physics-preflight-audit → mingti-zheshuo | 无法代替课标与教师盲做 |
| T02 六模块分析 | f02/p01/ce02 | verified | cap-physics-six-module-analysis → mingti-zheshuo | 无数据不输出统计结论 |
| T03 选项诊断 | p02/c04 | verified | cap-physics-choice-distractor-diagnosis → mingti-zheshuo | 错因是推测，非学生心理事实 |
| T04 表征/过程路由 | f03/p03/p05/ce03/ce04 | verified | cap-physics-representation-and-process-router → mingti-zheshuo | 依赖完整题面与清晰图 |
| T05 实验审校 | p04/c02/c03 | verified | cap-physics-experiment-data-review → mingti-zheshuo | 仪器规格和安全规范需另核 |
| T06 二轮蓝图/讲评 | f04/p01 | verified | cap-physics-second-round-feedback-loop → mingti-zheshuo | 难度必须经本校试测校准 |
| T07 教学回流 | f04 + 各题教学建议 | verified | cap-physics-second-round-feedback-loop → mingti-zheshuo | 没有学情数据仅能给预设方案 |

结论：阶段 0 的 7 项关键任务均有 verified 能力去向；没有被未解释遗漏的关键任务。
