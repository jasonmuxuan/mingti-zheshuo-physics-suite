# 阶段 1｜案例候选（均为报告中的原创演示题，不是实测案例）

- id: c01
  title: 图文过程冲突的弹簧—碰撞题
  type: case
  example_kind: worked_example
  source_chapter: 第13题
  source_quote: |
    “题图与过程冲突：图中弹簧在 A 左侧，A 的初速度却向右。”
  summary: 原拟多过程选择题在图、初速度和“先压缩再弹回”的叙述之间不自洽，报告因此把答案由确定项改为待修后复核。
  bound_to: [f01, p03]
  outcome: 说明预审应先于选项分析；未修正不可作为唯一答案题使用。
  tags: [case, diagram-text-conflict, multi-process]

- id: c02
  title: 光电门测速的近似边界
  type: case
  example_kind: worked_example
  source_chapter: 第15题
  source_quote: |
    “d/Δt 是遮光过程的平均速度；作为门处瞬时速度需遮光时间足够短。”
  summary: 以两个光电门求 g 的题，展示“平均速度近似瞬时速度”必须写出近似条件，并在图像斜率解释中保留近似符号。
  bound_to: [p04, f01]
  outcome: 形成“测量链＋近似条件”审校表。
  tags: [case, experiment, approximation]

- id: c03
  title: 电源内阻实验的电流表旁路风险
  type: case
  example_kind: worked_example
  source_chapter: 第16题
  source_quote: |
    “图14中主导线直接连接电流表两端，电流表可能被旁路。”
  summary: 同一题的数据拟合可得 E、r，但接线图有拓扑风险；说明结果数值正确不能代替实验电路审校。
  bound_to: [p04, f01]
  outcome: 先修正接线再接受实验题。
  tags: [case, circuit, topology, experiment]

- id: c04
  title: B-t图像中的变化率与焦耳热
  type: case
  example_kind: worked_example
  source_chapter: 第14题
  source_quote: |
    “先在每一时段写 ΔB/Δt，而非写 B。”
  summary: 报告用上升—平台—下降三段图像，展示状态量 B 与变化率 ΔB/Δt 的区分，以及由 ε→I→Q 的证据链。
  bound_to: [f03, p02]
  outcome: 形成图像题的斜率/变化率检查动作。
  tags: [case, graph, electromagnetic-induction]

- id: c05
  title: 非匀强磁场中的变量力做功
  type: case
  example_kind: worked_example
  source_chapter: 第20题
  source_quote: |
    “不能用末位置力乘全程代替变力做功。”
  summary: 给定 B(x) 与 ε=B(x)lv，题目从特例电流到瞬时加速度再到变力做功；报告同时提示定积分是否符合教学进度需要审校。
  bound_to: [p05, f03, f01]
  outcome: 形成新情境题的支架设计与教学适配检查。
  tags: [case, new-situation, variable-force, curriculum-fit]
