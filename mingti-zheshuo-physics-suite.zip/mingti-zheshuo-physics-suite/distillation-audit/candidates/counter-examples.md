# 阶段 1｜反例与失败模式候选

- id: ce01
  title: 先分析后审校导致“无唯一答案”
  type: counter-example
  source_chapter: 第13、16题审校提示
  source_quote: |
    “原题未经修正，不宜判定唯一答案。”
  failure_mode: 在图文、拓扑或过程条件尚冲突时，直接给出答案和命题说明。
  mechanism: 解题推导建立在未核验的隐含模型上，局部计算即使正确，也可能不是原题的唯一解释。
  warning_signs: [图中方向与文字相反, 元件两端被导线并联, 过程叙述无法按时间发生]
  bound_to: [f01, f02]
  tags: [counter-example, validity, preflight]

- id: ce02
  title: 将可能误区写成真实学情
  type: counter-example
  source_chapter: 报告说明；整卷复盘“数据使用建议”
  source_quote: |
    “不能把本报告中的预判当成真实学情。”
  failure_mode: 无作答数据时虚构正确率、选项率或考生心理原因。
  mechanism: 命题者可预见的干扰不等于学生实际选择路径；不同班级可能有不同原因。
  warning_signs: [出现具体得分率但无来源, 用“学生都”概括, 无数据却断言错误原因]
  bound_to: [f02, f04, p01]
  tags: [counter-example, evidence, student-data]

- id: ce03
  title: 跨过程套用同一守恒规律
  type: counter-example
  source_chapter: 第13、17、18题
  source_quote: |
    “每发生……过程转换，就重新写过程边界、研究对象、外力与可用规律。”
  failure_mode: 把机械能守恒套到完全非弹性碰撞，或用碰撞前质量处理碰撞后摩擦。
  mechanism: 系统、外力和能量损失条件在过程边界处已改变。
  warning_signs: [整题只有一个方程, 碰撞前后质量不变, 未标注过程起止]
  bound_to: [p03, f03]
  tags: [counter-example, conservation, multi-process]

- id: ce04
  title: 将变量当作常量
  type: counter-example
  source_chapter: 第20题
  source_quote: |
    “把 B 始终取 B₀；用恒力公式 W=FL 且遗漏 F 随 x 变。”
  failure_mode: 在 B(x)、F(x) 或图线变化问题中直接代常量公式。
  mechanism: 学生只提取了初态数值，没有把函数关系带入后续方程。
  warning_signs: [变量函数只在第一步出现, 用末态力乘全程, 未写瞬时/区间条件]
  bound_to: [p05, f03]
  tags: [counter-example, variable, new-situation]
