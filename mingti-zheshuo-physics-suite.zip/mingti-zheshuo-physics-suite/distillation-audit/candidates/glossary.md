# 阶段 1｜术语候选

- id: g01
  term: 命题蓝图
  type: term
  source_chapter: 报告说明、整卷数据与知识分布
  author_definition: 题号、知识主题、难度、分值、能力、素养和配图的事前职责表。
  key_distinction: 不等于事后考点目录；难度和能力是预设，不是实测。
  why_it_matters: 是出卷与整卷审校的输入约束。
- id: g02
  term: 六模块
  type: term
  source_chapter: 第1—20题共同标题
  author_definition: 试题解读、思路分析、命题设计、学生表现、教学改进、出题思路与陷阱。
  key_distinction: 不是只给“考点＋答案”。
  why_it_matters: 是物理命题分析的稳定交付格式。
- id: g03
  term: 可能误区
  type: term
  source_chapter: 报告说明；各题第四模块
  author_definition: 无真实数据时，依据具体题设列出的可检验错误路径。
  key_distinction: 不等于真实选项率、得分率或学生心理事实。
  why_it_matters: 约束证据语言。
- id: g04
  term: 过程切分
  type: term
  source_chapter: 第13、17、18、19、20题
  author_definition: 按受力、系统或运动模型变化划分过程，并各自选择规律。
  key_distinction: 不等于按题目小问机械分段。
  why_it_matters: 防止多过程题守恒误用。
- id: g05
  term: 表征转换
  type: term
  source_chapter: 第1、8、14、15、16题
  author_definition: 在文字、图像、数据、方程和物理图之间提取并验证同一关系。
  key_distinction: 不只是读坐标或代公式。
  why_it_matters: 决定图像和实验题的推理入口。
- id: g06
  term: 审校
  type: term
  source_chapter: 报告说明；第13/15/16/20题
  author_definition: 对图文、条件、拓扑、近似、答案唯一性和教学适配做前置核验。
  key_distinction: 不等于文字校对或版式检查。
  why_it_matters: 是成题前质量门。
- id: g07
  term: 新情境支架
  type: term
  source_chapter: 第20题命题设计
  author_definition: 在陌生模型中先给可用新关系和特例，再逐级迁移到更一般任务。
  key_distinction: 不等于直接抛出陌生公式要求套用。
  why_it_matters: 用于 C1/C2 题的可达性设计。
