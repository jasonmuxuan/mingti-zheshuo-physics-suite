# 阶段 1｜框架候选

- id: f01
  title: 物理题“先预审、再解析”质量门
  type: troubleshooting
  source_chapter: 报告说明；第13、15、16、20题的审校/教学适配提示
  source_quote: |
    “使用前须审校：第13题……过程不一致；第16题电路图中电流表可能被导线短接；第15题光电门测速为近似；第20题末问现用积分，须确认教学适配性。”
  inputs: [完整题干, 选项/小问, 图表, 课程进度或教材版本（如涉及）]
  outputs: [可用/待修/待补信息判定, 风险清单, 修正或停用建议]
  steps: [核对文字-图示-运动/电路拓扑, 核对单位/符号/方向/模型条件, 核对答案唯一性与解法依赖, 标出近似与教学适配, 通过后才进入命题分析]
  missing_conditions: [课程标准或教材版本未随来源提供, 不能替代教师盲做]
  tags: [physics, preflight, quality-gate, troubleshooting]

- id: f02
  title: 物理六模块命题分析闭环
  type: framework
  source_chapter: 第1—20题的共同结构
  source_quote: |
    “试题解读—思路分析—命题设计（物理）—学生表现（可能误区）—教学改进建议—出题思路与题目陷阱。”
  inputs: [完整题目, 图表, 已知答案（可选）, 作答数据（可选）]
  outputs: [六模块分析, 答案依据, 证据边界, 教学/命题反馈]
  steps: [独立求解, 识别情境与对象, 写条件到目标证据链, 标注能力/素养及干扰, 有数据才写实测表现, 无数据改写可能误区, 给可执行教学反馈与变式, 重建出题思路并声明推测]
  missing_conditions: [无真实作答数据时不可输出正确率/选项率]
  tags: [physics, item-analysis, six-modules, evidence-boundary]

- id: f03
  title: 按物理表征类型选择证据链
  type: framework
  source_chapter: 第1/8/14题图像；第7/9/10/11题方向；第15/16题实验；第13/17—20题多过程/新情境；整卷复盘
  source_quote: |
    “先按‘图像表征—方向判断—多过程建模—实验—新情境迁移’重组讲评。”
  inputs: [题型与题面表征, 图/表/实验信息]
  outputs: [题型路由, 对应证据链, 必查条件]
  steps: [判定主表征, 图像题查斜率/面积/变化率, 方向题查对象-场/速度-力, 实验题查直接量/近似/拓扑/斜率, 多过程题逐段定系统与规律, 新情境题先抽取给定新信息再迁移]
  missing_conditions: [跨类型综合题需允许多条链并行，不能只选一种]
  tags: [physics, representation, routing, reasoning]

- id: f04
  title: 二轮卷“蓝图—诊断—讲评—变式”回流
  type: procedure
  source_chapter: 报告说明、整卷数据与知识分布、整卷复盘与使用建议
  source_quote: |
    “若在班级实施，可记录每题得分、选择题选项分布和计算题采分点，分别验证本报告的‘可能误区’。”
  inputs: [命题蓝图, 试卷, 作答数据（可选）, 复习进度]
  outputs: [调整后的蓝图, 按能力重组的讲评方案, 锚题/变式清单]
  steps: [用蓝图分配题目职责, 实施后收集真实数据, 用数据验证或否定先验误区, 按能力而非题号组织讲评, 采用换情境保任务的锚题或变式复测]
  missing_conditions: [没有作答数据时仅能产出预设讲评，不能声称诊断已验证]
  tags: [physics, blueprint, feedback-loop, second-round]
