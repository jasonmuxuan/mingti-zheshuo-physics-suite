# 阶段 1｜原则、规则、计算候选

- id: p01
  title: 无数据时把“学生表现”降格为可能误区
  type: principle
  source_chapter: 报告说明；各题“学生表现（可能误区）”
  source_quote: |
    “本卷未经试测，‘学生表现’均为可能误区，不是统计事实。”
  summary: 没有正确率、选项率、得分点或作答样例时，只能写与题设绑定的可能错误及检查办法；不得虚构统计或心理结论。
  tags: [evidence, boundary, student-performance]

- id: p02
  title: 选择题错项必须映射到可检验的错误认知
  type: rule
  source_chapter: 第1—14题“选项逐项分析”
  source_quote: |
    “错误原因是可能解释；无法唯一推断时只说明物理依据。”
  summary: 逐项判断正确性；错项应对应一种明确的概念/模型/方向/计算错误，并给出一个检查动作。无法唯一归因时不编造考生心理。
  tags: [multiple-choice, distractor, diagnosis]

- id: p03
  title: 多过程题每段重新定义系统与规律
  type: rule
  source_chapter: 第13、17、18、19、20题
  source_quote: |
    “三个过程各有唯一主规律：弹簧释放用机械能守恒，碰撞用动量守恒，粗糙面滑行用动能定理。”
  summary: 每发生碰撞、脱离弹簧、进入/离开场区、受力变化或运动状态转换，就重新写过程边界、研究对象、外力与可用规律；禁止全程一个守恒式。
  tags: [multi-process, system, conservation]

- id: p04
  title: 实验题必须显式核验测量链和近似
  type: checklist
  source_chapter: 第15、16题及审校提示
  source_quote: |
    “d/Δt 是遮光过程的平均速度；作为门处瞬时速度需遮光时间足够短、球足够小等近似条件。”
  summary: 逐一列直接测量量、间接量、公式、单位、近似条件、接线拓扑、图像横纵轴和斜率物理意义；发现旁路或条件缺失则先待修。
  tags: [experiment, measurement, approximation, circuit]

- id: p05
  title: 新情境题先给新信息和特例，再迁移到一般关系
  type: principle
  source_chapter: 第20题“命题设计（物理）”
  source_quote: |
    “小问梯度为特例代入→瞬时动力学→变量力做功，难度不靠冗长计算。”
  summary: 新情境题要把新关系、适用范围和低门槛特例写进题面；后续再要求变量关系、极限/积分或能量迁移，并审校教学进度。
  tags: [new-situation, scaffold, c2, item-design]
